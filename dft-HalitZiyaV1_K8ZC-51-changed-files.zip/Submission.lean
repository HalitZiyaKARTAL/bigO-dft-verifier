/-
Entry point for the Big O Speedrun exact-DFT target (all positive lengths).
Saving 13762761/10000000000 (HalitZiyaV1_K8ZC: Jeremy Kothe's k8 provider word WITHOUT source copies, with x-scale
shears; the new zero-copy scalar replay GS.ZC lets x roles read the mutable source registers).
DFTProgram, ConvProgram, paperTime, nlogn and the charged RAM model are OpenAI's
unchanged definitions from OAI.Computability.FourierTransform.Goal.

Credits (see also the preserved headers and notices of every module):
* Problem, exact RAM model and all-length Fourier reduction: OpenAI (openai/math problem #130).
* Framework: the Kothe–Shea complex588 development (Jeremy Kothe, Ryan Shea; including the
  source-copy conversion that the zero-copy replay replaces); Jacob Sussman's formal engine and
  checkers; Dugongue's and jacklightChen's #401/#377 geometry; Nil Mamano's gauged extension.
* C588AT pipeline: canghaimeng (Euler; Astra and GPT-6.1 Sol), with the provider packaged by
  Dmitri Arkhipov, and the rate retune published by fringewidth (Hrishik Sai Bojnal).
* Local word: Jeremy Kothe's seven-slot k8 word (CrocSwap/integer-mult-bounds PR1074, commit
  052afc128954f7b6a2b3c409eb4d72248e4020f2); its seven-slot step comes from PR1018 and credits
  Rohan Arun's PR987 search. Word file as packaged by Ali Romman (research/r480-owner-optimum).
  Earlier ancestry and notices of that word: gauge44 (icekylinx), the PR635 K-triangle and
  porting machinery, PR601/PR604 (jeremykothe2, DreamingOfClouds), PR568-PR583 (incl. chafreaky).
* New in this submission: the zero-copy provider replay and its soundness proofs
  (Submission/Work/GCert/Scalar/ZeroCopy*.lean), the HalitZiyaV1_K8ZC conversion (no source copies, x-scale
  shears, tagged renormalising replay), its bank table and generated data modules.
  Author and supervisor: Halit Ziya KARTAL (https://github.com/HalitZiyaKARTAL,
  https://halitziyakartal.github.io).
  LLM credits(2)↓
  Gemini 4 Argon: during ai development chat i was posting stuff about what happened
    including integer multiplication,
    and since its relatively new model at the time i asked its proposals too,
    which made it suggest few prompts and back and forths that i gave it a try
    especially when considering claude code had its container with available compute(although low ram)
    (i was using argon in ai studio
    which that session didn't had container (code execution was very primitive too))
    which basically started claude code chat but proposal of argon failed
    but process made me open claude code and give initial prompts semi designed with argon,
    and that chat had failed integer multiplication optimization attempts
    which triggered order of me to check other similar stuff.
  Claude (Anthropic), as Claude Code agents:
    basically handled chores including part of these credits(which kinda nearly took more time than development itself),
    lean, checking repo, handling bureaucracy, making zip so i can push easier from phone browser,
    reducing file number(annoying 100 limits in GitHub etc),
    making an html for me to read better(diffs etc),
    spawning subagents etc
    and also checking things in the algorithm for improvements in summary(like correlation extraction,
    reorganizing creation phase to allow more packing
    and other stuff i guided during integer multiplication checks)

in its own words: the code, Lean proofs, data generation, builds
  and testing; spotting openings (which circuit to port, and that the source copies were
  never needed) and following them through; and the cross-checks (independent
  re-derivations, the verifier's statement check and its official Comparator). -/
import Submission.Work.Fourier_HalitZiyaV1_K8ZC.Main

open OAI.PowerSaving Filter Asymptotics

theorem Race.bound : ∃ order solve W, DFTProgram order solve W ∧
    (fun n : ℕ => (W n : ℝ)) =O[atTop]
      (fun n : ℕ => (n : ℝ) * (Real.log (n : ℝ)) ^
        (1 - (13762761 : ℝ) / 10000000000)) := by
  obtain ⟨order, solve, W, hprogram, htime⟩ := transform_main_HalitZiyaV1_K8ZC
  refine ⟨order, solve, W, hprogram, ?_⟩
  have hexp : decimalExponent_HalitZiyaV1_K8ZC = 1 - (13762761 : ℝ) / 10000000000 := by
    norm_num [decimalExponent_HalitZiyaV1_K8ZC]
  have htime_eq : decimalTime_HalitZiyaV1_K8ZC =
      (fun n : ℕ => (n : ℝ) * (Real.log (n : ℝ)) ^ (1 - (13762761 : ℝ) / 10000000000)) := by
    funext n
    simp only [decimalTime_HalitZiyaV1_K8ZC, hexp]
  rw [← htime_eq]
  exact htime.2.1

#print axioms Race.bound
