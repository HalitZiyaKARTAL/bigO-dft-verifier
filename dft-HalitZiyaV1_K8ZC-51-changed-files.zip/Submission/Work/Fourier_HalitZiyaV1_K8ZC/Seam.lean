-- Packaging change: local imports prefixed with Submission; mathematical declarations preserved.
import Submission.Work.GCert.Data.HalitZiyaV1_K8ZC_Ginv
import Submission.Work.GCert.Data.Inst_HalitZiyaV1_K8ZC
import Submission.Work.Bridge401.End

/-!
HalitZiyaV1_K8ZC tensor program for the all-length Fourier reduction.

This instantiates the unchanged #401 engine with the actual HalitZiyaV1_K8ZC invocation,
its checked 3933-bank schedule, and the proved finite-fill moment inequality.
The local invocation retains eight initialized copies and all correction work;
the unit invoice includes the pad blocks and both idle terms of the engine.

The proof follows the attributed Work/FourierC588/Seam.lean in the pinned
Kothe–Shea source. Sussman's engine, Dugongue's and jacklightChen's #401/#377
geometry, Mamano's gauged extension, and OpenAI's Fourier interfaces retain
their original notices and licenses. The new source-replay soundness and
HalitZiyaV1_K8ZC certificate are proved in the imported modules.
-/

namespace OAI.PowerSaving
noncomputable section

/-- Tensor exponent, leaving a saving gap of 1/10000000000 before Fourier transfer. -/
def alpha_HalitZiyaV1_K8ZC : ℝ := 1 - 13762762 / (10 : ℝ)^10

theorem alpha_HalitZiyaV1_K8ZC_pos : 0 < alpha_HalitZiyaV1_K8ZC := by norm_num [alpha_HalitZiyaV1_K8ZC]
theorem alpha_HalitZiyaV1_K8ZC_lt : alpha_HalitZiyaV1_K8ZC < 1 := by norm_num [alpha_HalitZiyaV1_K8ZC]

lemma envelope_mono_HalitZiyaV1_K8ZC (z : ℝ) (hz : 0 ≤ z) {a b : ℕ} (h : a ≤ b) :
    envelope z a ≤ envelope z b := by
  unfold envelope
  gcongr

lemma envelope_mono_exp_HalitZiyaV1_K8ZC {z z' : ℝ} (h : z ≤ z') (k : ℕ) :
    envelope z k ≤ envelope z' k := by
  unfold envelope
  exact Nat.ceil_le_ceil (Real.rpow_le_rpow_of_exponent_le (by simp) h)

def hills_HalitZiyaV1_K8ZC (k : ℕ) := Nat.ceil (((k : ℝ) + 1)^alpha_HalitZiyaV1_K8ZC)

lemma hills_HalitZiyaV1_K8ZC_eq_envelope : hills_HalitZiyaV1_K8ZC = envelope alpha_HalitZiyaV1_K8ZC := rfl
lemma hills_HalitZiyaV1_K8ZC_pos (k : ℕ) : 1 ≤ hills_HalitZiyaV1_K8ZC k := envelope_pos alpha_HalitZiyaV1_K8ZC k
lemma hills_HalitZiyaV1_K8ZC_mono {a b : ℕ} (h : a ≤ b) : hills_HalitZiyaV1_K8ZC a ≤ hills_HalitZiyaV1_K8ZC b :=
  envelope_mono_HalitZiyaV1_K8ZC alpha_HalitZiyaV1_K8ZC alpha_HalitZiyaV1_K8ZC_pos.le h
lemma hills_HalitZiyaV1_K8ZC_le (k : ℕ) : hills_HalitZiyaV1_K8ZC k ≤ k + 1 :=
  envelope_le alpha_HalitZiyaV1_K8ZC alpha_HalitZiyaV1_K8ZC_lt.le k
lemma hills_HalitZiyaV1_K8ZC_real (k : ℕ) : (hills_HalitZiyaV1_K8ZC k : ℝ) ≤ 2 * ((k : ℝ) + 1)^alpha_HalitZiyaV1_K8ZC :=
  envelope_real alpha_HalitZiyaV1_K8ZC alpha_HalitZiyaV1_K8ZC_pos.le k

namespace Seam_HalitZiyaV1_K8ZC
open Binary Matrix Finset RAM RAM.Ty
universe U

theorem h9 : Fintype.card (Fin GXD.HalitZiyaV1_K8ZC.aux.p.h) = 9 := by
  rw [Fintype.card_fin]
  decide

/-- The actual invocation and schedule realize the full proposed unit list. -/
theorem unit_invoice (φ : ℕ → ℝ) :
    72 * GXD.HalitZiyaV1_K8ZC.ginv.cost φ +
        (Fintype.card (Fin GXD.HalitZiyaV1_K8ZC.raw.v) : ℝ) * GX.bankPrice377 φ +
        ∑ b, CB.bcost φ (GXD.HalitZiyaV1_K8ZC.sched.pad b) =
      listCost φ BlockAccounting.blocks_HalitZiyaV1_K8ZC := by
  rw [GXD.HalitZiyaV1_K8ZC.ginv_cost]
  exact GXD.HalitZiyaV1_K8ZC.invoice φ

/-- Every colour, both modes, and every batch, with the engine's full charges. -/
theorem engine_HalitZiyaV1_K8ZC (cl : Paint) (m : Bool) {ι : Type U} (k : ι → ℕ)
    (v : ∀ i, Bits (k i) → ℂ) :
    Can m (fun i => 2^k i) (simIn cl) (bundle cl)
      (fun i => givenBits cl (k i) (v i)) (fun i => (bits (k i)).tape (ripple (k i) (v i)))
      (fun i => 2^k i * envelope alpha_HalitZiyaV1_K8ZC (k i)) :=
  GX.engine_of_ginv_401 GXD.HalitZiyaV1_K8ZC.ginv h9 GXD.HalitZiyaV1_K8ZC.sched GXD.HalitZiyaV1_K8ZC.ginv_fits
    73 11101 rfl GXD.HalitZiyaV1_K8ZC.width (by norm_num) BlockAccounting.blocks_HalitZiyaV1_K8ZC
    unit_invoice 40 alpha_HalitZiyaV1_K8ZC alpha_HalitZiyaV1_K8ZC_pos.le alpha_HalitZiyaV1_K8ZC_lt.le
    BlockAccounting.fold_HalitZiyaV1_K8ZC cl m k v

end Seam_HalitZiyaV1_K8ZC

namespace RAM
open Binary Matrix Ty Finset
universe U

/-- OpenAI's tensor-program interface, realized by the checked HalitZiyaV1_K8ZC engine. -/
theorem hills_HalitZiyaV1_K8ZC_program (cl : Paint) (m : Bool) {ι : Type U} (k : ι → ℕ)
    (v : ∀ i, Bits (k i) → ℂ) :
    Can m (fun i => 2^k i) (simIn cl) (bundle cl)
      (fun i => givenBits cl (k i) (v i)) (fun i => (bits (k i)).tape (ripple (k i) (v i)))
      (fun i => 2^k i * hills_HalitZiyaV1_K8ZC (k i)) :=
  Seam_HalitZiyaV1_K8ZC.engine_HalitZiyaV1_K8ZC cl m k v

theorem envelope_program_ge_HalitZiyaV1_K8ZC (z : ℝ) (hz : alpha_HalitZiyaV1_K8ZC ≤ z) (cl : Paint) (m : Bool)
    {ι : Type U} (k : ι → ℕ) (v : ∀ i, Bits (k i) → ℂ) :
    Can m (fun i => 2^k i) (simIn cl) (bundle cl)
      (fun i => givenBits cl (k i) (v i)) (fun i => (bits (k i)).tape (ripple (k i) (v i)))
      (fun i => 2^k i * envelope z (k i)) :=
  (hills_HalitZiyaV1_K8ZC_program cl m k v).mono fun i =>
    Nat.mul_le_mul_left _ (envelope_mono_exp_HalitZiyaV1_K8ZC hz (k i))

end RAM

namespace Seam_HalitZiyaV1_K8ZC

def targetExponent_HalitZiyaV1_K8ZC : ℝ := 1 - (13762761 : ℝ) / 10000000000

lemma tensor_fourier_slack :
    targetExponent_HalitZiyaV1_K8ZC - alpha_HalitZiyaV1_K8ZC = 1 / (10000000000 : ℝ) := by
  norm_num [targetExponent_HalitZiyaV1_K8ZC, alpha_HalitZiyaV1_K8ZC]

lemma alpha_HalitZiyaV1_K8ZC_lt_target : alpha_HalitZiyaV1_K8ZC < targetExponent_HalitZiyaV1_K8ZC := by
  norm_num [targetExponent_HalitZiyaV1_K8ZC, alpha_HalitZiyaV1_K8ZC]

end Seam_HalitZiyaV1_K8ZC
end
end OAI.PowerSaving

#print axioms OAI.PowerSaving.Seam_HalitZiyaV1_K8ZC.unit_invoice
#print axioms OAI.PowerSaving.Seam_HalitZiyaV1_K8ZC.engine_HalitZiyaV1_K8ZC
#print axioms OAI.PowerSaving.RAM.hills_HalitZiyaV1_K8ZC_program
