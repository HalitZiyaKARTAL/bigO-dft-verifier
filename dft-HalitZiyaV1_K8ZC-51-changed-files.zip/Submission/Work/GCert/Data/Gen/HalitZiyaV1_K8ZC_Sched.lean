import Submission.Work.GCert.Data.Gen.HalitZiyaV1_K8ZC_Rows
import Submission.Work.Bridge401.SchedK
set_option maxRecDepth 100000
namespace GXD.HalitZiyaV1_K8ZC
open OAI.PowerSaving
noncomputable def schedRows : List (List Nat) := bankRows0 ++ bankRows1 ++ bankRows2 ++ bankRows3 ++ bankRows4 ++ bankRows5 ++ bankRows6 ++ bankRows7 ++ bankRows8 ++ bankRows9 ++ bankRows10 ++ bankRows11 ++ bankRows12 ++ bankRows13 ++ bankRows14 ++ bankRows15 ++ bankRows16 ++ bankRows17
def schedPad : List Nat := List.replicate 3456 0 ++ List.replicate 477 1
def schedRes : List Nat := [9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 8, 9, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 8, 9, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 9, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 9, 8, 8, 8, 9, 9, 9, 9, 8, 8, 8, 8, 8, 8, 8, 8, 9, 8, 9, 8, 8, 8, 8, 8, 8, 8, 9, 8, 9, 8, 9, 9, 9, 9, 8, 8, 8, 8, 9, 9, 9, 9, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 5, 8, 5, 5, 5, 8, 8, 8, 4, 8, 4, 4, 4, 8, 8, 8, 4, 8, 4, 4, 4, 8, 8, 8, 4, 8, 4, 4, 4, 8, 8, 8, 4, 8, 4, 4, 4, 8, 8, 8, 4, 8, 4, 4, 4, 8, 8, 8, 5, 8, 5, 5, 5, 8, 8, 8, 4, 8, 4, 4, 4, 8, 8, 8, 5, 8, 5, 5, 5, 8, 8, 8, 5, 8, 5, 5, 5, 8, 8, 8, 5, 8, 5, 5, 5, 8, 8, 8, 5, 8, 5, 5, 5, 8, 8, 8, 5, 8, 5, 5, 5, 8, 8, 8, 5, 8, 5, 5, 5, 9, 9, 9, 9, 9]
theorem sched_ok : GX.schedK 3933 raw.R schedRows schedPad schedRes = true := by
  decide +kernel
end GXD.HalitZiyaV1_K8ZC
#print axioms GXD.HalitZiyaV1_K8ZC.sched_ok
