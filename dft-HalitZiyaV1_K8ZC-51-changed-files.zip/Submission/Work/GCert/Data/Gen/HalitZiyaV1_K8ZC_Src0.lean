import Submission.Work.GCert.Scalar.ZeroCopyFDef
import Submission.Work.GCert.Data.Gen.HalitZiyaV1_K8ZC
/-! Finite structural facts of the zero-copy certificate `GXD.HalitZiyaV1_K8ZC.raw`. -/
set_option maxRecDepth 100000
namespace GXD.HalitZiyaV1_K8ZC
open GXD
theorem aNoY_ok : GS.aNoYK raw = true := by decide +kernel
theorem kinds_ok : GS.ZC.kindsK raw = true := by decide +kernel
end GXD.HalitZiyaV1_K8ZC
#print axioms GXD.HalitZiyaV1_K8ZC.aNoY_ok
