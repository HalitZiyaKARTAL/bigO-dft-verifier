import Submission.Work.GCert.Scalar.Seg
import Submission.Work.GCert.Data.Gen.HalitZiyaV1_K8ZC
/-! Kernel check (the y -> y adds, E4) of `GXD.HalitZiyaV1_K8ZC.raw`. -/
set_option maxRecDepth 100000
namespace GXD.HalitZiyaV1_K8ZC
open GXD
theorem ychk_ok : GS.yCheck raw ⟨10, 34, 4, 8, 8⟩ 0 112 = true := by decide +kernel
end GXD.HalitZiyaV1_K8ZC
#print axioms GXD.HalitZiyaV1_K8ZC.ychk_ok
