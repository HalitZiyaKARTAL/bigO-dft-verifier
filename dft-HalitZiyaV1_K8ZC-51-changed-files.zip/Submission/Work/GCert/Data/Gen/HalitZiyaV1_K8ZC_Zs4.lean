import Submission.Work.GCert.Scalar.ZeroCopyFDef
import Submission.Work.GCert.Data.Gen.HalitZiyaV1_K8ZC_Ren
/-! Zero-copy slot-column replay (`GS.ZC.sCheckLF`, the s-mode) of `GXD.HalitZiyaV1_K8ZC.raw`, slot registers `slb4`
(98 ungauged slots). -/
set_option maxRecDepth 100000
namespace GXD.HalitZiyaV1_K8ZC
theorem zs4_ok : GS.ZC.sCheckLF raw ⟨10, 34, 32, 32, 32⟩ slb4 false rls = true := by
  decide +kernel
end GXD.HalitZiyaV1_K8ZC
#print axioms GXD.HalitZiyaV1_K8ZC.zs4_ok
