import Submission.Work.GCert.Scalar.ZeroCopyFDef
import Submission.Work.GCert.Data.Gen.HalitZiyaV1_K8ZC_Ren
/-! Zero-copy x-column replay (`GS.ZC.xCheckLF`, the targets of every item renormalised after it) of `GXD.HalitZiyaV1_K8ZC.raw`, sources 0 .. 111. -/
set_option maxRecDepth 100000
namespace GXD.HalitZiyaV1_K8ZC
theorem zx0_ok : GS.ZC.xCheckLF raw ⟨10, 40, 65536, 65536, 65536⟩ 0 112 rls = true := by
  decide +kernel
end GXD.HalitZiyaV1_K8ZC
#print axioms GXD.HalitZiyaV1_K8ZC.zx0_ok
