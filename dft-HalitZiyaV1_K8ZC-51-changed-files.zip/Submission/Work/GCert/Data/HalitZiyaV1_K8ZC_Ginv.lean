import Submission.Work.Gauge.Inv
import Submission.Work.GCert.Data.Glue
import Submission.Work.GCert.Data.HalitZiyaV1_K8ZC_SrcOK
import Submission.Work.GCert.Data.HalitZiyaV1_K8ZC_Banks

/-!
HalitZiyaV1_K8ZC gauged invocation: the zero-copy scalar half `GS.ZC.SourceOKR` (x-column and slot-column replays,
x roles read slots), its gauged scalar half (E7 from the slot batches replayed with the y test), the
unchanged label half `GLab.ValidE.glab` and `GX.GLab.inv`.
-/

set_option maxRecDepth 100000
set_option linter.unusedSectionVars false
set_option linter.unusedVariables false

namespace GXD.HalitZiyaV1_K8ZC
open GXD OAI.PowerSaving OAI.PowerSaving.CB OAI.PowerSaving.CR Matrix Finset

noncomputable section

noncomputable def gscal : GX.GScal (Fin raw.v) (Fin raw.R) (Fin raw.ret.length) :=
  srcOK.gscal (univ.filter (fun q : Fin raw.R => 2 * raw.v + q.val ∈ gl)) (fun q hq =>
    gauged_run q (Finset.mem_filter.mp hq).2)

/-- Gauges of the label list `gl` are gauged in the scalar half. -/
theorem glab_hg (q : Fin raw.R) (hq : 2 * raw.v + q.val ∈ gl) : q ∈ gscal.gauged :=
  Finset.mem_filter.mpr ⟨Finset.mem_univ _, hq⟩

noncomputable def glab : GX.GLab (Fin aux.p.h) gscal :=
  validE.glab gscal (roles raw srcOK.hv) GS.toCoef
    (scalOf_MA raw srcOK.hv srcOK.hAi srcOK.hBi srcOK.hx srcOK.hy srcOK.hid)
    (scalOf_MAi raw srcOK.hv srcOK.hAi srcOK.hBi srcOK.hx srcOK.hy srcOK.hid)
    (scalOf_MB raw srcOK.hv srcOK.hAi srcOK.hBi srcOK.hx srcOK.hy srcOK.hid)
    (scalOf_MBi raw srcOK.hv srcOK.hAi srcOK.hBi srcOK.hx srcOK.hy srcOK.hid)
    (reg raw) (reg_slot raw srcOK.hv srcOK.hAi srcOK.hBi srcOK.hx srcOK.hy srcOK.hid) (reg_mem raw)
    glab_hg

noncomputable def ginv : GX.GInvE (Fin aux.p.h) (Fin raw.v) (Fin raw.R) (Fin raw.ret.length) :=
  glab.inv

theorem ginv_cost (φ : ℕ → ℝ) : ginv.cost φ = invPrice φ := by
  have h5 : ∀ k : Fin raw.ret.length,
      bcost φ (GLab.cdim (aux.p.tab.get (aux.SA.get (GXD.reg raw k)))) = bcost φ 8 :=
    fun k => congrArg (bcost φ) (cen_dim _ (GXD.reg_mem raw k))
  have hr := validE.glab_ranks gscal (roles raw srcOK.hv) GS.toCoef
    (scalOf_MA raw srcOK.hv srcOK.hAi srcOK.hBi srcOK.hx srcOK.hy srcOK.hid)
    (scalOf_MAi raw srcOK.hv srcOK.hAi srcOK.hBi srcOK.hx srcOK.hy srcOK.hid)
    (scalOf_MB raw srcOK.hv srcOK.hAi srcOK.hBi srcOK.hx srcOK.hy srcOK.hid)
    (scalOf_MBi raw srcOK.hv srcOK.hAi srcOK.hBi srcOK.hx srcOK.hy srcOK.hid)
    (reg raw) (reg_slot raw srcOK.hv srcOK.hAi srcOK.hBi srcOK.hx srcOK.hy srcOK.hid) (reg_mem raw)
    glab_hg
  change GX.GLab.cost glab φ = _
  unfold GX.GLab.cost glab
  rw [hr.1, hr.2.1, hr.2.2.1]
  simp only [hr.2.2.2]
  rw [Finset.sum_congr rfl (fun k _ => h5 k), Finset.sum_const, Finset.card_univ,
    nsmul_eq_mul, Fintype.card_fin, ← inv_cost φ, show raw.ret.length = 8 from by decide]
  norm_num [bcost]
  try rfl

theorem ginv_ent (q : Fin raw.R) : ginv.ent q = bankEnt q := rfl

theorem ginv_ent_dim (q : Fin raw.R) :
    (ginv.ent q).dim = GLab.cdim (par.tab.get (st0.get (2 * raw.v + q.val))) := by
  rw [ginv_ent, bankEnt_dim]

theorem ginv_fits : sched.fits ginv.ent := by
  convert fits
  funext q
  exact ginv_ent q

end
end GXD.HalitZiyaV1_K8ZC

#print axioms GXD.HalitZiyaV1_K8ZC.gscal
#print axioms GXD.HalitZiyaV1_K8ZC.ginv
#print axioms GXD.HalitZiyaV1_K8ZC.ginv_cost
#print axioms GXD.HalitZiyaV1_K8ZC.ginv_fits
