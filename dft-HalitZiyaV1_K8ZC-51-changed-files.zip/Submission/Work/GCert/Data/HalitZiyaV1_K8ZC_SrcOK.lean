import Submission.Work.GCert.Scalar.ZeroCopyF
import Submission.Work.GCert.Data.Gen.HalitZiyaV1_K8ZC_YChk
import Submission.Work.GCert.Data.Gen.HalitZiyaV1_K8ZC_Src0
import Submission.Work.GCert.Data.Gen.HalitZiyaV1_K8ZC_Zx0
import Submission.Work.GCert.Data.Gen.HalitZiyaV1_K8ZC_Zs0
import Submission.Work.GCert.Data.Gen.HalitZiyaV1_K8ZC_Zs1
import Submission.Work.GCert.Data.Gen.HalitZiyaV1_K8ZC_Zs2
import Submission.Work.GCert.Data.Gen.HalitZiyaV1_K8ZC_Zs3
import Submission.Work.GCert.Data.Gen.HalitZiyaV1_K8ZC_Zs4

/-!
The scalar half of the zero-copy certificate `GXD.HalitZiyaV1_K8ZC.raw` (no source copies: x roles read slots):
`srcOK : GS.ZC.SourceOKR raw` from 1 x-column batches, the y check, `aNoYK`, the kinds and 5 slot-column
batches (the gauged slots with the E7 test).
-/

set_option maxRecDepth 100000
namespace GXD.HalitZiyaV1_K8ZC
open GXD

def xs : List (GS.SPar × Nat × Nat) := [(⟨10, 40, 65536, 65536, 65536⟩, 0, 112)]
noncomputable def ss : List (GS.SPar × List Nat × Bool) := [(⟨10, 34, 32, 32, 32⟩, slb0, true), (⟨10, 34, 32, 32, 32⟩, slb1, true), (⟨10, 34, 32, 32, 32⟩, slb2, false), (⟨10, 34, 32, 32, 32⟩, slb3, false), (⟨10, 34, 32, 32, 32⟩, slb4, false)]

theorem xs_ok : ∀ e ∈ xs, GS.ZC.xCheckLF raw e.1 e.2.1 e.2.2 rls = true := by
  intro e he
  simp only [xs, List.mem_cons, List.mem_nil_iff, or_false] at he
  rcases he with rfl
  · exact zx0_ok

theorem ss_ok : ∀ e ∈ ss, GS.ZC.sCheckLF raw e.1 e.2.1 e.2.2 rls = true := by
  intro e he
  simp only [ss, List.mem_cons, List.mem_nil_iff, or_false] at he
  rcases he with rfl | rfl | rfl | rfl | rfl
  · exact zs0_ok
  · exact zs1_ok
  · exact zs2_ok
  · exact zs3_ok
  · exact zs4_ok

theorem xs_cover : ∀ t, t < raw.v → ∃ e ∈ xs, e.2.1 ≤ t ∧ t < e.2.1 + e.2.2 := by
  decide +kernel

theorem ss_cover : ∀ q, q < raw.R → ∃ e ∈ ss, 2 * raw.v + q ∈ e.2.1 := by
  decide +kernel

/-- **the zero-copy scalar half** -/
theorem srcOK : GS.ZC.SourceOKR raw :=
  GS.ZC.SourceOKR.of_checksLF (by decide) kinds_ok rls xs xs_ok xs_cover
    [(⟨10, 34, 4, 8, 8⟩, 0, 112)] (fun e he => by
      simp only [List.mem_singleton] at he
      subst he
      exact ychk_ok)
    (fun t ht => ⟨(⟨10, 34, 4, 8, 8⟩, 0, 112), List.mem_singleton_self _, Nat.zero_le t, by
      have : raw.v = 112 := rfl
      simpa [this] using ht⟩)
    aNoY_ok ss ss_ok ss_cover

theorem gl_eq : gl = slb0 ++ slb1 := by decide +kernel

theorem gauged_run (q : Fin raw.R) (hq : 2 * raw.v + q.val ∈ gl) :
    ∃ l, 2 * raw.v + q.val ∈ l ∧ GS.ZC.SRunR raw l true := by
  rw [gl_eq] at hq
  rcases List.mem_append.mp hq with hq | hq
  swap
  · exact ⟨slb1, hq, GS.ZC.sCheckLF_sound zs1_ok⟩
  exact ⟨slb0, hq, GS.ZC.sCheckLF_sound zs0_ok⟩

end GXD.HalitZiyaV1_K8ZC

#print axioms GXD.HalitZiyaV1_K8ZC.srcOK
#print axioms GXD.HalitZiyaV1_K8ZC.gauged_run
