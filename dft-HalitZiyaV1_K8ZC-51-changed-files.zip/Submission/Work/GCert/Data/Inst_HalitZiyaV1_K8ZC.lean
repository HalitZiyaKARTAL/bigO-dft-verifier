import Submission.Work.Bridge377.Bank
import Submission.Work.FoldRate.Group
import Submission.Work.GCert.Data.HalitZiyaV1_K8ZC_Price
import Submission.Work.GCert.Data.Rate_HalitZiyaV1_K8ZC

/-! The numerical HalitZiyaV1_K8ZC unit invoice (as `InstC588AT`). -/

namespace OAI.PowerSaving.BridgeRate.HalitZiyaV1_K8ZC
open Finset Binary Matrix RAM CB FoldRate
noncomputable section

def padPrice (φ : ℕ → ℝ) : ℝ := 477 * bcost φ 1

def unitPrice (φ : ℕ → ℝ) : ℝ :=
  72 * GXD.HalitZiyaV1_K8ZC.invPrice φ + (112 : ℝ) * GX.bankPrice377 φ + padPrice φ

theorem unit_cost (φ : ℕ → ℝ) :
    unitPrice φ = listCost φ BlockAccounting.blocks_HalitZiyaV1_K8ZC := by
  unfold unitPrice GXD.HalitZiyaV1_K8ZC.invPrice padPrice
  simp only [GX.bankPrice377, listCost, BlockAccounting.blocks_HalitZiyaV1_K8ZC,
    List.map_cons, List.map_nil, List.sum_cons, List.sum_nil]
  norm_num [bcost]
  ring

end
end OAI.PowerSaving.BridgeRate.HalitZiyaV1_K8ZC

#print axioms OAI.PowerSaving.BridgeRate.HalitZiyaV1_K8ZC.unit_cost
