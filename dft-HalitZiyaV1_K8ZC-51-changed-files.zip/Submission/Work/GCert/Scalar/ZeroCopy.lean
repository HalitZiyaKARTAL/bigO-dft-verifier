import Submission.Work.GCert.Scalar.ZeroCopyDef
import Submission.Work.GCert.Scalar.SourceTag16Sound
import Submission.Work.GCert.Data.Glue
import Submission.Work.Gauge.Defs

/-!
# Zero-copy provider replay: soundness

For a certificate whose phase-A and phase-B adds pass only the relaxed kind test
`GS.ZC.okZK` (registers in range, a y role read only by a y role; in particular `x_t += c * s_q`
is allowed):

* `xCheck_sound`, `XRun.xcol`: an accepted x-column replay gives the x-from-x and y-from-x
  blocks of the total matrix `GS.Mt` on its batch;
* `sCheck_sound`, `SRun.xrow`, `SRun.yrow`: an accepted slot-column replay gives the x-from-slot
  zero block (and, with `ey`, the y-from-slot zero block: the E7 fact of the gauged slots);
* `SourceOK c` (x batches, the existing y check `GS.YRun`, phase A not reading y, slot batches
  covering every slot) gives the five scalar identities `hAi hBi hx hy hid`, hence
  `SourceOK.scal : GX.Scal` (through the unchanged `GXD.scalOf`) and `SourceOK.gscal : GX.GScal`.

The rule "x targets read only x" of `GS.okBK` is not used: the x rows of `Mt` are computed by the
slot-column replay instead of being derived from the gate support (`GS.SourceOK.xu`).
No existing definition is changed.  No `sorry`.
-/

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
set_option linter.deprecated false

namespace GS.ZC
open SSC GXD OAI.PowerSaving OAI.PowerSaving.Binary OAI.PowerSaving.RAM OAI.PowerSaving.SS
  OAI.PowerSaving.CB OAI.PowerSaving.CR Finset Matrix

theorem okZ_spec {v v2 nr t s : Nat} (h : okZK v v2 nr t s = true) :
    t < nr ∧ s < nr ∧ (s < v ∨ v2 ≤ s ∨ (v ≤ t ∧ t < v2)) := by
  simp only [okZK, Bool.and_eq_true, Bool.or_eq_true, Nat.ble_eq] at h
  omega

/-- the relaxed kind test of a certificate -/
abbrev okZ (c : Raw) : Nat → Nat → Bool := okZK c.v (2 * c.v) (2 * c.v + c.R)

/-! ## items on abstract states -/

section
variable (c : Raw) (p : SPar) (n : Nat)

/-- one item on abstract states: chunks of A and of B under `okZ`, the scatter under `okS` -/
def ItemRun : Item → SSt → SSt → Prop
  | .cA gs, a, b => GRun p.sw n (U c p) (okZ c) (fun _ => true) a (gs.flatMap Gate.adds) b
  | .scat, a, b => GRun p.sw n (U c p) (okS c) (fun _ => true) a (scatAdds c) b ∧ ScatShape c
  | .cB gs, a, b => GRun p.sw n (U c p) (okZ c) (fun _ => true) a (gs.flatMap Gate.adds) b

def ItemsRun : List Item → SSt → SSt → Prop
  | [], a, b => b = a
  | it :: l, a, b => ∃ m, ItemRun c p n it a m ∧ ItemsRun l m b

theorem ItemsRun_split (l1 l2 : List Item) : ∀ (a b : SSt),
    ItemsRun c p n (l1 ++ l2) a b → ∃ m, ItemsRun c p n l1 a m ∧ ItemsRun c p n l2 m b := by
  induction l1 with
  | nil => intro a b h; exact ⟨a, rfl, h⟩
  | cons x l1 ih =>
    intro a b h
    obtain ⟨m1, hs, hr⟩ := h
    obtain ⟨m, r1, r2⟩ := ih m1 b hr
    exact ⟨m, ⟨m1, hs, r1⟩, r2⟩

theorem ItemsRun_cB (cs : List (List Gate)) : ∀ (a b : SSt),
    ItemsRun c p n (cs.map Item.cB) a b →
    GRun p.sw n (U c p) (okZ c) (fun _ => true) a (cs.flatten.flatMap Gate.adds) b := by
  induction cs with
  | nil => intro a b h; exact h
  | cons gs cs ih =>
    intro a b h
    obtain ⟨m, h1, h2⟩ := h
    rw [List.flatten_cons, List.flatMap_append]
    exact GRun_append _ _ _ _ _ _ _ _ _ _ h1 (ih m b h2)

/-- a run of `sourceProg c`: phase A, the scatter, phase B -/
theorem sourceProg_split {a b : SSt} (h : ItemsRun c p n (sourceProg c) a b) :
    ∃ a1 a2, GRun p.sw n (U c p) (okZ c) (fun _ => true) a (addsA c) a1 ∧
      GRun p.sw n (U c p) (okS c) (fun _ => true) a1 (scatAdds c) a2 ∧ ScatShape c ∧
      GRun p.sw n (U c p) (okZ c) (fun _ => true) a2 (addsB c) b := by
  obtain ⟨m1, r1, r2⟩ := ItemsRun_split c p n _ _ a b h
  obtain ⟨m2, ⟨rs, hsh⟩, r3⟩ := r2
  exact ⟨m1, m2, ItemsRun_cB c p n _ a m1 r1, rs, hsh, ItemsRun_cB c p n _ m2 b r3⟩

end

/-! ## the kernel items run the items -/

section
variable (c : Raw) (p : SPar) (lo n : Nat) (hp : PGood c p lo n)
include hp

theorem gItem_sound (it : Item) (tr : Trie) (k : Trie → Bool) (hI : GOk p.d p.sw n tr)
    (h : gItem c p (2 * c.v) (2 * c.v + c.R) (maskW p.sw n) (64 + p.sw * n) (2^(64 + p.sw * n))
      c.ret.length it tr k = true) :
    ∃ tr', GOk p.d p.sw n tr' ∧ k tr' = true ∧
      ItemRun c p n it (absG p.d (64 + p.sw * n) tr) (absG p.d (64 + p.sw * n) tr') := by
  have hu := U_pos c p lo n hp
  cases it with
  | cA gs =>
    exact gGates_sound p.d p.sw n _ _ p.ux p.us p.uy c.v (2 * c.v) (okZ c) (fun _ => true) hp.hsw
      rfl rfl hu gs tr k hI h
  | scat =>
    obtain ⟨tr', hI', hk, hlen, hb, hr⟩ := gScat_sound p.d p.sw n _ _ p.ux p.us p.uy c.v (2 * c.v)
      (okS c) hp.hsw rfl rfl hu c.ret c.ret.length (scatRows c) c.v tr k hI h
    exact ⟨tr', hI', hk, hr, hlen, hb⟩
  | cB gs =>
    exact gGates_sound p.d p.sw n _ _ p.ux p.us p.uy c.v (2 * c.v) (okZ c) (fun _ => true) hp.hsw
      rfl rfl hu gs tr k hI h

theorem gItems_sound (items : List Item) : ∀ (tr : Trie) (k : Trie → Bool), GOk p.d p.sw n tr →
    gItems c p (2 * c.v) (2 * c.v + c.R) (maskW p.sw n) (64 + p.sw * n) (2^(64 + p.sw * n))
      c.ret.length items tr k = true →
    ∃ tr', GOk p.d p.sw n tr' ∧ k tr' = true ∧
      ItemsRun c p n items (absG p.d (64 + p.sw * n) tr) (absG p.d (64 + p.sw * n) tr') := by
  induction items with
  | nil => intro tr k hI h; exact ⟨tr, hI, h, rfl⟩
  | cons it items ih =>
    intro tr k hI h
    obtain ⟨tr1, hI1, hk1, r1⟩ := gItem_sound c p lo n hp it tr _ hI h
    obtain ⟨tr2, hI2, hk2, r2⟩ := ih tr1 k hI1 hk1
    exact ⟨tr2, hI2, hk2, _, r1, r2⟩

end

/-! ## x columns -/

/-- **An accepted x-column replay** for the sources `lo .. lo+n-1` (relaxed kinds). -/
def XRun (c : Raw) (lo n : Nat) : Prop :=
  ∃ (p : SPar) (a0 a1 a2 a3 : SSt), PGood c p lo n ∧ InitSt p n lo p.ux a0 ∧
    GRun p.sw n (U c p) (okZ c) (fun _ => true) a0 (addsA c) a1 ∧
    GRun p.sw n (U c p) (okS c) (fun _ => true) a1 (scatAdds c) a2 ∧ ScatShape c ∧
    GRun p.sw n (U c p) (okZ c) (fun _ => true) a2 (addsB c) a3 ∧
    SmallSt p.sw n a3 ∧ FinSt c p lo n 0 p.ux a3 ∧ FinSt c p lo n c.v p.uy a3

theorem xCheck_sound {c : Raw} {p : SPar} {lo n : Nat} (h : xCheck c p lo n = true) :
    XRun c lo n := by
  unfold xCheck at h
  obtain ⟨hp, h1⟩ := pgood_of (gPre_sound c p lo n _ h)
  rw [forceN_eq] at h1
  have h2 : Tag16.init p.sw p.ux lo n 0 (Trie.mk p.d) (fun tr0 =>
      gItems c p (2 * c.v) (2 * c.v + c.R) (maskW p.sw n) (64 + p.sw * n) (2 ^ (64 + p.sw * n))
        c.ret.length (sourceProg c) tr0 fun tr3 =>
          guard (gFin p.sw (64 + p.sw * n) (2 ^ (64 + p.sw * n)) p.ux 0 lo (lo + n) tr3 c.v 0)
            (gFin p.sw (64 + p.sw * n) (2 ^ (64 + p.sw * n)) p.uy c.v lo (lo + n) tr3 c.v 0))
      = true := h1
  have hle : lo + 0 + n ≤ 2 ^ p.d := by have := hp.hd; have := hp.hn; omega
  obtain ⟨t0, hwf, hk, hval⟩ := Tag16.init_sound p.d p.sw p.ux lo n 0 (Trie.mk p.d) _
    (Trie.wf_mk p.d) hle h2
  obtain ⟨hI0, hinit⟩ := Tag16.init_ok p.d p.sw n p.ux lo hp.hsw hp.hxs hp.hx2 t0 hwf hval
  obtain ⟨tr3, hI3, hk3, hr⟩ := gItems_sound c p lo n hp (sourceProg c) t0 _ hI0 hk
  obtain ⟨f1, f2⟩ := guard_true hk3
  obtain ⟨a1, a2, rA, rS, hsh, rB⟩ := sourceProg_split c p n hr
  exact ⟨p, _, a1, a2, _, hp, hinit, rA, rS, hsh, rB, hI3.small,
    fin_of c p lo n hp 0 p.ux tr3 hI3 f1, fin_of c p lo n hp c.v p.uy tr3 hI3 f2⟩

theorem XRun.addA {c : Raw} {lo n : Nat} (h : XRun c lo n) : ∀ x ∈ addsA c,
    x.1 < 2 * c.v + c.R ∧ x.2.1 < 2 * c.v + c.R ∧ x.1 ≠ x.2.1 ∧
      (c.v ≤ x.2.1 → x.2.1 < 2 * c.v → c.v ≤ x.1 ∧ x.1 < 2 * c.v) := by
  obtain ⟨p, a0, a1, a2, a3, hp, hi, rA, rS, hsh, rB, hsm, fx, fy⟩ := h
  intro x hx
  obtain ⟨ho, hne⟩ := GRun_all _ _ _ _ _ _ _ _ rA x hx rfl
  obtain ⟨h1, h2, h3⟩ := okZ_spec ho
  exact ⟨h1, h2, hne, by omega⟩

theorem XRun.addB {c : Raw} {lo n : Nat} (h : XRun c lo n) : ∀ x ∈ addsB c,
    x.1 < 2 * c.v + c.R ∧ x.2.1 < 2 * c.v + c.R ∧ x.1 ≠ x.2.1 ∧
      (c.v ≤ x.2.1 → x.2.1 < 2 * c.v → c.v ≤ x.1 ∧ x.1 < 2 * c.v) := by
  obtain ⟨p, a0, a1, a2, a3, hp, hi, rA, rS, hsh, rB, hsm, fx, fy⟩ := h
  intro x hx
  obtain ⟨ho, hne⟩ := GRun_all _ _ _ _ _ _ _ _ rB x hx rfl
  obtain ⟨h1, h2, h3⟩ := okZ_spec ho
  exact ⟨h1, h2, hne, by omega⟩

/-- **the columns of the x sources of a batch**: x rows and y rows of the total matrix -/
theorem XRun.xcol {c : Raw} (hv : 0 < c.v) {lo n : Nat} (h : XRun c lo n)
    (t : Fin c.v) (hlo : lo ≤ t.val) (hhi : t.val < lo + n) :
    (∀ t' : Fin c.v, Mt c hv (lX t') (lX t) = if t' = t then 1 else 0) ∧
      ∀ S : Fin c.v, Mt c hv (lY S) (lX t) = if S = t then 1 else 0 := by
  obtain ⟨p, a0, a1, a2, a3, hp, hi, rA, rS, hsh, rB, hsm, fx, fy⟩ := h
  have hokZ : ∀ t s, okZ c t s = true → emb c (unemb c hv t) = t ∧ emb c (unemb c hv s) = s :=
    fun t s ho => ⟨emb_unemb hv t (okZ_spec ho).1, emb_unemb hv s (okZ_spec ho).2.1⟩
  have hCA : Cm p.sw n (U c p) (emb c) a1 = MA c hv * Cm p.sw n (U c p) (emb c) a0 := by
    have := GRun_Cm p.sw n (U c p) (okZ c) (fun _ => true) (emb c) (unemb c hv) (unemb_emb hv) hokZ
      (addsA c) a0 a1 rA
    rw [micF_true] at this
    exact this
  have hCB : Cm p.sw n (U c p) (emb c) a3 = MB c hv * Cm p.sw n (U c p) (emb c) a2 := by
    have := GRun_Cm p.sw n (U c p) (okZ c) (fun _ => true) (emb c) (unemb c hv) (unemb_emb hv) hokZ
      (addsB c) a2 a3 rB
    rw [micF_true] at this
    exact this
  have hCS := cm_scat p lo n hp a1 a2 rS hsh
  have hus : p.ux < 2^p.sw :=
    lt_of_lt_of_le hp.hxs (Nat.pow_le_pow_right (by norm_num) (by omega))
  have hT : t.val - lo < n := by omega
  have hC0 : ∀ j : Rl c, Cm p.sw n (U c p) (emb c) a0 j ⟨t.val - lo, hT⟩
      = if j = lX t then 1 else 0 := by
    intro j
    have h1 := cont_start p.sw n (U c p) a0 lo p.ux hp.hx hus hi (emb c j) (t.val - lo) hT
      (fun hr => U_x c p _ (by have := hp.hn; omega))
    show gcont p.sw (U c p) a0 (emb c j) (t.val - lo) = _
    rw [h1]
    have e : lo + (t.val - lo) = t.val := by omega
    by_cases hj : j = lX t
    · rw [if_pos hj, hj, if_pos (by rw [e]; rfl)]
    · have hne : ¬ emb c j = lo + (t.val - lo) := by
        intro he
        apply hj
        rw [← unemb_emb hv j, he, e, unemb_x hv t.val t.isLt]
      rw [if_neg hj, if_neg hne]
  have key : ∀ i : Rl c, Mt c hv i (lX t) = Cm p.sw n (U c p) (emb c) a3 i ⟨t.val - lo, hT⟩ := by
    intro i
    have e1 := mul_unitCol (Mt c hv) (Cm p.sw n (U c p) (emb c) a0) (lX t) ⟨t.val - lo, hT⟩ hC0 i
    rw [← e1]
    unfold Mt
    rw [Matrix.mul_assoc, Matrix.mul_assoc, ← hCA, ← hCS, ← hCB]
  refine ⟨fun t' => ?_, fun S => ?_⟩
  · rw [key]
    have hf := fx t'.val t'.isLt
    rw [Nat.zero_add] at hf
    have h1 := cont_end p.sw n (U c p) a3 t'.val p.ux (t'.val - lo) (lo ≤ t'.val ∧ t'.val < lo + n)
      hp.hsw hp.hx hp.hxs (U_x c p _ t'.isLt) (hsm t'.val).2 hf (t.val - lo) hT
    show gcont p.sw (U c p) a3 t'.val (t.val - lo) = _
    rw [h1]
    by_cases e : t' = t
    · rw [if_pos e, if_pos ⟨by rw [e]; exact ⟨hlo, hhi⟩, by rw [e]⟩]
    · have hne : ¬ ((lo ≤ t'.val ∧ t'.val < lo + n) ∧ t.val - lo = t'.val - lo) := by
        intro hh
        exact e (Fin.ext (by omega))
      rw [if_neg e, if_neg hne]
  · rw [key]
    have hf := fy S.val S.isLt
    have h1 := cont_end p.sw n (U c p) a3 (c.v + S.val) p.uy (S.val - lo)
      (lo ≤ S.val ∧ S.val < lo + n) hp.hsw hp.hy hp.hys
      (U_y c p _ (by omega) (by have := S.isLt; omega)) (hsm (c.v + S.val)).2 hf (t.val - lo) hT
    show gcont p.sw (U c p) a3 (c.v + S.val) (t.val - lo) = _
    rw [h1]
    by_cases e : S = t
    · rw [if_pos e, if_pos ⟨by rw [e]; exact ⟨hlo, hhi⟩, by rw [e]⟩]
    · have hne : ¬ ((lo ≤ S.val ∧ S.val < lo + n) ∧ t.val - lo = S.val - lo) := by
        intro hh
        exact e (Fin.ext (by omega))
      rw [if_neg e, if_neg hne]

/-! ## slot columns (the s-mode) -/

/-- **An accepted slot-column replay** for the slot registers `gl` (relaxed kinds): at the end
every x role holds nothing, and if `ey` every y role holds nothing. -/
def SRun (c : Raw) (gl : List Nat) (ey : Bool) : Prop :=
  ∃ (p : SPar) (a0 b : SSt), PGood c p 0 gl.length ∧
    (∀ r ∈ gl, 2 * c.v ≤ r ∧ r < 2 * c.v + c.R) ∧ gl.Nodup ∧ p.us < 2^(p.sw - 1) ∧
    (∀ r, a0.N r = 0 ∧ a0.P r = if r ∈ gl then p.us * 2^(p.sw * gl.idxOf r) else 0) ∧
    ItemsRun c p gl.length (sourceProg c) a0 b ∧
    (∀ S, S < c.v → b.P S = b.N S) ∧
    (ey = true → ∀ S, S < c.v → b.P (c.v + S) = b.N (c.v + S))

theorem sCheck_sound {c : Raw} {p : SPar} {gl : List Nat} {ey : Bool}
    (h : sCheck c p gl ey = true) : SRun c gl ey := by
  unfold sCheck at h
  obtain ⟨hp, h1⟩ := pgood_of (gPre_sound c p 0 gl.length _ h)
  obtain ⟨hinc, h2⟩ := guard_true h1
  obtain ⟨hus, h3⟩ := guard_true h2
  obtain ⟨hus2, h4⟩ := guard_true h3
  rw [forceN_eq] at h4
  have h5 : Tag16.initL p.sw p.us gl 0 (Trie.mk p.d) (fun tr0 =>
      gItems c p (2 * c.v) (2 * c.v + c.R) (maskW p.sw gl.length) (64 + p.sw * gl.length)
        (2 ^ (64 + p.sw * gl.length)) c.ret.length (sourceProg c) tr0 fun tr3 =>
          guard (gFin p.sw (64 + p.sw * gl.length) (2 ^ (64 + p.sw * gl.length)) p.ux 0 0 0 tr3 c.v 0)
            (Bool.rec (motive := fun _ => Bool) true
              (gFin p.sw (64 + p.sw * gl.length) (2 ^ (64 + p.sw * gl.length)) p.uy c.v 0 0 tr3 c.v 0)
              ey)) = true := h4
  have hinc' : GS.incK (2 * c.v + c.R) gl (2 * c.v) = true := by
    rw [← Tag16.incK_eq]; exact hinc
  obtain ⟨hgl, hnd⟩ := incK_sound _ gl _ hinc'
  have hu1 := ble_true hus
  have hu2 := ble_true hus2
  have hlt : ∀ r ∈ gl, r < 2 ^ p.d := fun r hr => by have := (hgl r hr).2; have := hp.hd; omega
  obtain ⟨t0, hwf, hk, hval⟩ := Tag16.initL_sound p.d p.sw p.us gl 0 (Trie.mk p.d) _
    (Trie.wf_mk p.d) hlt hnd h5
  have husw : p.us < 2 ^ (p.sw - 1) := by
    have e : Nat.pow 2 (Nat.sub p.sw 1) = 2 ^ (p.sw - 1) := rfl
    omega
  obtain ⟨hI0, hinit⟩ := Tag16.init_okL p.d p.sw p.us gl hp.hsw husw (by omega) t0 hwf hval
  obtain ⟨tr3, hI3, hk3, hr⟩ := gItems_sound c p 0 gl.length hp (sourceProg c) t0 _ hI0 hk
  obtain ⟨f1, f2⟩ := guard_true hk3
  refine ⟨p, _, _, hp, hgl, hnd, husw, hinit, hr, fun S hS => ?_, fun hey S hS => ?_⟩
  · have h6 := gFin_sound p.d p.sw (64 + p.sw * gl.length) p.ux 0 0 0 tr3 hI3.wf c.v 0 f1 S hS
    have e1 : (0:Nat) + (0 + S) = S := by omega
    have e2 : ¬ (0 ≤ 0 + S ∧ 0 + S < 0) := by omega
    rw [e1, if_neg e2, Nat.add_zero] at h6
    exact h6
  · have f2' : gFin p.sw (64 + p.sw * gl.length) (2 ^ (64 + p.sw * gl.length)) p.uy c.v 0 0 tr3
        c.v 0 = true := by
      rw [hey] at f2; exact f2
    have h6 := gFin_sound p.d p.sw (64 + p.sw * gl.length) p.uy c.v 0 0 tr3 hI3.wf c.v 0 f2' S hS
    have e1 : (0:Nat) + S = S := by omega
    have e2 : ¬ (0 ≤ 0 + S ∧ 0 + S < 0) := by omega
    rw [if_neg e2, e1, Nat.add_zero] at h6
    exact h6

/-- a slot column of the total matrix is the final content of its digit -/
theorem SRun.key {c : Raw} (hv : 0 < c.v) {gl : List Nat} {ey : Bool} (h : SRun c gl ey)
    (q : Fin c.R) (hq : 2 * c.v + q.val ∈ gl) :
    ∃ (p : SPar) (b : SSt), (∀ S, S < c.v → b.P S = b.N S) ∧
      (ey = true → ∀ S, S < c.v → b.P (c.v + S) = b.N (c.v + S)) ∧
      ∀ i : Rl c, Mt c hv i (lS q) = gcont p.sw (U c p) b (emb c i) (gl.idxOf (2 * c.v + q.val)) := by
  obtain ⟨p, a0, b, hp, hgl, hnd, husw, hi, hr, hfx, hfy⟩ := h
  obtain ⟨a1, a2, rA, rS, hsh, rB⟩ := sourceProg_split c p gl.length hr
  have hokZ : ∀ t s, okZ c t s = true → emb c (unemb c hv t) = t ∧ emb c (unemb c hv s) = s :=
    fun t s ho => ⟨emb_unemb hv t (okZ_spec ho).1, emb_unemb hv s (okZ_spec ho).2.1⟩
  have hCA : Cm p.sw gl.length (U c p) (emb c) a1
      = MA c hv * Cm p.sw gl.length (U c p) (emb c) a0 := by
    have := GRun_Cm p.sw gl.length (U c p) (okZ c) (fun _ => true) (emb c) (unemb c hv)
      (unemb_emb hv) hokZ (addsA c) a0 a1 rA
    rw [micF_true] at this
    exact this
  have hCB : Cm p.sw gl.length (U c p) (emb c) b
      = MB c hv * Cm p.sw gl.length (U c p) (emb c) a2 := by
    have := GRun_Cm p.sw gl.length (U c p) (okZ c) (fun _ => true) (emb c) (unemb c hv)
      (unemb_emb hv) hokZ (addsB c) a2 b rB
    rw [micF_true] at this
    exact this
  have hCS := cm_scat p 0 gl.length hp a1 a2 rS hsh
  have hus : p.us < 2^p.sw := lt_of_lt_of_le husw (Nat.pow_le_pow_right (by norm_num) (by omega))
  have hT : gl.idxOf (2 * c.v + q.val) < gl.length := List.idxOf_lt_length_of_mem hq
  have u0 : (p.us : ℚ) ≠ 0 := by have := hp.hs; positivity
  have hC0 : ∀ j : Rl c, Cm p.sw gl.length (U c p) (emb c) a0 j ⟨gl.idxOf (2 * c.v + q.val), hT⟩
      = if j = lS q then 1 else 0 := by
    intro j
    show gcont p.sw (U c p) a0 (emb c j) (gl.idxOf (2 * c.v + q.val)) = _
    unfold gcont
    rw [(hi (emb c j)).1, (hi (emb c j)).2, dg_zero_left]
    by_cases hj : emb c j ∈ gl
    · rw [if_pos hj, dg_mul_pow p.sw p.us hus, U_s c p _ (hgl _ hj).1]
      by_cases e : j = lS q
      · have e' : emb c j = 2 * c.v + q.val := by rw [e]; rfl
        rw [if_pos (by rw [e']), if_pos e]
        field_simp
        simp
      · have e' : ¬ gl.idxOf (2 * c.v + q.val) = gl.idxOf (emb c j) := by
          intro he
          apply e
          have := (List.idxOf_inj hq).mp he
          rw [← unemb_emb hv j, ← this]
          exact unemb_emb hv (lS q)
        rw [if_neg e', if_neg e]
        simp
    · have e : ¬ j = lS q := fun e => hj (by rw [e]; exact hq)
      rw [if_neg hj, if_neg e, dg_zero_left]
      simp
  refine ⟨p, b, hfx, hfy, fun i => ?_⟩
  have key : Mt c hv i (lS q)
      = Cm p.sw gl.length (U c p) (emb c) b i ⟨gl.idxOf (2 * c.v + q.val), hT⟩ := by
    have e1 := mul_unitCol (Mt c hv) (Cm p.sw gl.length (U c p) (emb c) a0) (lS q) _ hC0 i
    rw [← e1]
    unfold Mt
    rw [Matrix.mul_assoc, Matrix.mul_assoc, ← hCA, ← hCS, ← hCB]
  exact key

/-- **the s-mode**: an x row of the total matrix vanishes on a replayed slot column. -/
theorem SRun.xrow {c : Raw} (hv : 0 < c.v) {gl : List Nat} {ey : Bool} (h : SRun c gl ey)
    (q : Fin c.R) (hq : 2 * c.v + q.val ∈ gl) (t : Fin c.v) : Mt c hv (lX t) (lS q) = 0 := by
  obtain ⟨p, b, hfx, _, key⟩ := h.key hv q hq
  rw [key]
  show gcont p.sw (U c p) b t.val (gl.idxOf (2 * c.v + q.val)) = 0
  unfold gcont
  rw [hfx t.val t.isLt]
  simp

/-- **E7 in the same replay**: a y row of the total matrix vanishes on a slot column replayed
with `ey`. -/
theorem SRun.yrow {c : Raw} (hv : 0 < c.v) {gl : List Nat} (h : SRun c gl true)
    (q : Fin c.R) (hq : 2 * c.v + q.val ∈ gl) (S : Fin c.v) : Mt c hv (lY S) (lS q) = 0 := by
  obtain ⟨p, b, _, hfy, key⟩ := h.key hv q hq
  rw [key]
  show gcont p.sw (U c p) b (c.v + S.val) (gl.idxOf (2 * c.v + q.val)) = 0
  unfold gcont
  rw [hfy rfl S.val S.isLt]
  simp

/-! ## the scalar half -/

/-- **The scalar half of a certificate without source copies.**  x-column replays covering every
port, the existing y check, phase A never reading a y role, slot-column replays covering every
slot. -/
structure SourceOK (c : Raw) : Prop where
  hv : 0 < c.v
  hs : ∀ t, t < c.v → ∃ lo n, lo ≤ t ∧ t < lo + n ∧ XRun c lo n
  hyc : ∀ t, t < c.v → ∃ lo n, lo ≤ t ∧ t < lo + n ∧ GS.YRun c lo n
  hA_noY : ∀ x ∈ addsA c, x.2.1 < c.v ∨ 2 * c.v ≤ x.2.1
  hsl : ∀ q, q < c.R → ∃ gl ey, 2 * c.v + q ∈ gl ∧ SRun c gl ey

namespace SourceOK
variable {c : Raw} (K : SourceOK c)
include K

theorem addA : ∀ x ∈ addsA c, x.1 < 2 * c.v + c.R ∧ x.2.1 < 2 * c.v + c.R ∧ x.1 ≠ x.2.1 ∧
    (c.v ≤ x.2.1 → x.2.1 < 2 * c.v → c.v ≤ x.1 ∧ x.1 < 2 * c.v) := by
  obtain ⟨lo, n, _, _, h⟩ := K.hs 0 K.hv
  exact h.addA

theorem addB : ∀ x ∈ addsB c, x.1 < 2 * c.v + c.R ∧ x.2.1 < 2 * c.v + c.R ∧ x.1 ≠ x.2.1 ∧
    (c.v ≤ x.2.1 → x.2.1 < 2 * c.v → c.v ≤ x.1 ∧ x.1 < 2 * c.v) := by
  obtain ⟨lo, n, _, _, h⟩ := K.hs 0 K.hv
  exact h.addB

theorem un_ne (t s : Nat) (ht : t < 2 * c.v + c.R) (hs : s < 2 * c.v + c.R) (hne : t ≠ s) :
    unemb c K.hv t ≠ unemb c K.hv s := fun e => hne (by
  rw [← emb_unemb K.hv t ht, e, emb_unemb K.hv s hs])

theorem hAi : MAi c K.hv * MA c K.hv = 1 := by
  apply mul_eq_one_comm.mp
  exact matP_inv _ _ (gatesDistinct_of _ _ (fun t s cf hm => by
    obtain ⟨x, hx, rfl, rfl⟩ := mem_mic _ _ _ _ hm
    obtain ⟨h1, h2, h3, _⟩ := K.addA x hx
    exact K.un_ne _ _ h1 h2 h3))

theorem hBi : MBi c K.hv * MB c K.hv = 1 := by
  apply mul_eq_one_comm.mp
  exact matP_inv _ _ (gatesDistinct_of _ _ (fun t s cf hm => by
    obtain ⟨x, hx, rfl, rfl⟩ := mem_mic _ _ _ _ hm
    obtain ⟨h1, h2, h3, _⟩ := K.addB x hx
    exact K.un_ne _ _ h1 h2 h3))

theorem hid (S t : Fin c.v) :
    (MB c K.hv * scatM (Jrm c * Ccm c) * MA c K.hv) (lY S) (lX t) = if S = t then 1 else 0 := by
  obtain ⟨lo, n, hlo, hhi, h⟩ := K.hs t.val t.isLt
  exact (h.xcol K.hv t hlo hhi).2 S

theorem mb_ycol (i : Rl c) (t : Fin c.v) : MB c K.hv i (lY t) = if i = lY t then 1 else 0 := by
  have hf := ycol_filter (unemb c K.hv) (selY c.v (2 * c.v)) (addsB c)
    (fun x hx hsel τ hτ => by
      obtain ⟨_, h2, _⟩ := K.addB x hx
      have := selY_spec.mpr (unemb_of_y K.hv x.2.1 h2 τ hτ)
      rw [hsel] at this
      exact Bool.false_ne_true this)
    (fun x hx hsel => by
      obtain ⟨_, _, _, h5⟩ := K.addB x hx
      obtain ⟨g1, g2⟩ := selY_spec.mp hsel
      obtain ⟨g3, g4⟩ := h5 g1 g2
      exact ⟨_, unemb_y K.hv x.1 g3 g4⟩) i t
  show matP (unemb c K.hv) (mic (addsB c)) i (lY t) = _
  rw [hf]
  have htg : ∀ t' s cf, Micro.add t' s cf ∈ micF (selY c.v (2 * c.v)) (addsB c) →
      ∃ τ : Fin c.v, unemb c K.hv t' = lY τ := by
    intro t' s cf hm
    obtain ⟨x, hx, rfl, rfl, hsel⟩ := mem_micF _ _ _ _ _ hm
    obtain ⟨_, _, _, h5⟩ := K.addB x hx
    obtain ⟨g1, g2⟩ := selY_spec.mp hsel
    obtain ⟨g3, g4⟩ := h5 g1 g2
    exact ⟨_, unemb_y K.hv x.1 g3 g4⟩
  rcases i with (τ | S) | q
  · exact matP_row _ _ _ (fun t' s cf hm hh => by
      obtain ⟨τ', hτ'⟩ := htg t' s cf hm
      rw [hτ'] at hh; cases hh) _
  · obtain ⟨lo, n, hlo, hhi, p, a0, a3, hp, hi, hr, hsm, fy⟩ := K.hyc t.val t.isLt
    have hokB : ∀ t s, okB c t s = true →
        emb c (unemb c K.hv t) = t ∧ emb c (unemb c K.hv s) = s :=
      fun t s ho => ⟨emb_unemb K.hv t (okB_spec ho).1, emb_unemb K.hv s (okB_spec ho).2.1⟩
    have hC := GRun_Cm p.sw n (U c p) (okB c) (selY c.v (2 * c.v)) (emb c) (unemb c K.hv)
      (unemb_emb K.hv) hokB (addsB c) a0 a3 hr
    have hus : p.uy < 2^p.sw :=
      lt_of_lt_of_le hp.hys (Nat.pow_le_pow_right (by norm_num) (by omega))
    have hT : t.val - lo < n := by omega
    have hC0 : ∀ j : Rl c, Cm p.sw n (U c p) (emb c) a0 j ⟨t.val - lo, hT⟩
        = if j = lY t then 1 else 0 := by
      intro j
      have h1 := cont_start p.sw n (U c p) a0 (c.v + lo) p.uy hp.hy hus hi (emb c j) (t.val - lo) hT
        (fun hr => U_y c p _ (by omega) (by have := hp.hn; omega))
      show gcont p.sw (U c p) a0 (emb c j) (t.val - lo) = _
      rw [h1]
      have e : c.v + lo + (t.val - lo) = c.v + t.val := by omega
      by_cases hj : j = lY t
      · rw [if_pos hj, hj, if_pos (by rw [e]; rfl)]
      · have hne : ¬ emb c j = c.v + lo + (t.val - lo) := by
          intro he
          apply hj
          rw [← unemb_emb K.hv j, he, e, unemb_y K.hv (c.v + t.val) (by omega)
            (by have := t.isLt; omega)]
          exact congrArg (fun x => (Sum.inl (Sum.inr x) : Rl c)) (Fin.ext (by simp))
        rw [if_neg hj, if_neg hne]
    have e1 := mul_unitCol (matP (unemb c K.hv) (micF (selY c.v (2 * c.v)) (addsB c)))
      (Cm p.sw n (U c p) (emb c) a0) (lY t) ⟨t.val - lo, hT⟩ hC0 (lY S)
    rw [← e1, ← hC]
    have h1 := cont_end p.sw n (U c p) a3 (c.v + S.val) p.uy (S.val - lo)
      (lo ≤ S.val ∧ S.val < lo + n) hp.hsw hp.hy hp.hys
      (U_y c p _ (by omega) (by have := S.isLt; omega)) (hsm (c.v + S.val)).2 (fy S.val S.isLt)
      (t.val - lo) hT
    show gcont p.sw (U c p) a3 (c.v + S.val) (t.val - lo) = _
    rw [h1]
    by_cases e : S = t
    · rw [e, if_pos ⟨⟨hlo, hhi⟩, rfl⟩, if_pos rfl]
    · have hne : ¬ ((lo ≤ S.val ∧ S.val < lo + n) ∧ t.val - lo = S.val - lo) := by
        intro hh
        exact e (Fin.ext (by omega))
      rw [if_neg hne, if_neg (fun hh => e (Sum.inr.inj (Sum.inl.inj hh)))]
  · exact matP_row _ _ _ (fun t' s cf hm hh => by
      obtain ⟨τ', hτ'⟩ := htg t' s cf hm
      rw [hτ'] at hh; cases hh) _

theorem hy (i : Rl c) (t : Fin c.v) :
    (MB c K.hv * scatM (Jrm c * Ccm c) * MA c K.hv) i (lY t) = if i = lY t then 1 else 0 := by
  have hA : ∀ i : Rl c, MA c K.hv i (lY t) = if i = lY t then 1 else 0 :=
    matP_col (unemb c K.hv) (lY t) (mic (addsA c)) (fun t' s cf hm hh => by
    obtain ⟨x, hx, rfl, rfl⟩ := mem_mic _ _ _ _ hm
    obtain ⟨_, h2, _⟩ := K.addA x hx
    have hny := K.hA_noY x hx
    have := unemb_of_y K.hv x.2.1 h2 t hh
    omega)
  have hS : ∀ i : Rl c, scatM (Jrm c * Ccm c) i (lY t) = if i = lY t then 1 else 0 := by
    intro i
    unfold scatM
    rw [Matrix.add_apply, Matrix.one_apply, embYS_colY, add_zero]
  have hcol := unitCol_mul _ _ (lY t) hS hA
  rw [Matrix.mul_assoc, mul_unitCol (MB c K.hv) _ (lY t) (lY t) hcol i]
  exact K.mb_ycol i t

/-- **the x rows are identity rows**: x columns from the x replays, y columns from `hy`, slot
columns from the s-mode replays. -/
theorem hx (t : Fin c.v) (j : Rl c) :
    (MB c K.hv * scatM (Jrm c * Ccm c) * MA c K.hv) (lX t) j = if lX t = j then 1 else 0 := by
  rcases j with (τ | S) | q
  · obtain ⟨lo, n, hlo, hhi, h⟩ := K.hs τ.val τ.isLt
    have h1 := (h.xcol K.hv τ hlo hhi).1 t
    show Mt c K.hv (lX t) (lX τ) = _
    rw [h1]
    by_cases e : t = τ
    · rw [if_pos e, e, if_pos rfl]
    · rw [if_neg e, if_neg (fun hh => e (Sum.inl.inj (Sum.inl.inj hh)))]
  · exact K.hy (lX t) S
  · obtain ⟨gl, ey, hq, h⟩ := K.hsl q.val q.isLt
    have h1 := h.xrow K.hv q hq t
    show Mt c K.hv (lX t) (lS q) = _
    rw [h1, if_neg (fun hh => by cases hh)]

/-- **the scalar half** (`GX.Scal`), through the unchanged `GXD.scalOf`. -/
noncomputable def scal : GX.Scal (Fin c.v) (Fin c.R) (Fin c.ret.length) :=
  scalOf c K.hv K.hAi K.hBi K.hx K.hy K.hid

/-- **the gauged scalar half** (`GX.GScal`): every gauged slot is replayed with `ey`. -/
noncomputable def gscal (g : Finset (Fin c.R))
    (hg : ∀ q ∈ g, ∃ gl, 2 * c.v + q.val ∈ gl ∧ SRun c gl true) :
    GX.GScal (Fin c.v) (Fin c.R) (Fin c.ret.length) where
  toScal := K.scal
  gauged := g
  hE := fun q hq t => by
    obtain ⟨gl, hgl, h⟩ := hg q hq
    exact h.yrow K.hv q hgl t

theorem scal_MA : K.scal.MA = matP (unemb c K.hv) (GLab.mic toCoef (c.gatesA.flatMap Gate.adds)) :=
  rfl
theorem scal_MAi :
    K.scal.MAi = matPinv (unemb c K.hv) (GLab.mic toCoef (c.gatesA.flatMap Gate.adds)) := rfl
theorem scal_MB : K.scal.MB = matP (unemb c K.hv) (GLab.mic toCoef (c.gatesB.flatMap Gate.adds)) :=
  rfl
theorem scal_MBi :
    K.scal.MBi = matPinv (unemb c K.hv) (GLab.mic toCoef (c.gatesB.flatMap Gate.adds)) := rfl

end SourceOK

/-! ## building `SourceOK` from finitely many checks -/

/-- `SourceOK` from lists of accepted kernel checks: x batches `(p, lo, n)` covering every port,
y batches, phase A not reading y (`GS.aNoYK`), slot batches `(p, gl, ey)` covering every slot. -/
theorem SourceOK.of_checks {c : Raw} (hv : 0 < c.v)
    (xs : List (SPar × Nat × Nat)) (hxs : ∀ e ∈ xs, xCheck c e.1 e.2.1 e.2.2 = true)
    (hxc : ∀ t, t < c.v → ∃ e ∈ xs, e.2.1 ≤ t ∧ t < e.2.1 + e.2.2)
    (ys : List (SPar × Nat × Nat)) (hys : ∀ e ∈ ys, yCheck c e.1 e.2.1 e.2.2 = true)
    (hyc : ∀ t, t < c.v → ∃ e ∈ ys, e.2.1 ≤ t ∧ t < e.2.1 + e.2.2)
    (hA : aNoYK c = true)
    (ss : List (SPar × List Nat × Bool)) (hss : ∀ e ∈ ss, sCheck c e.1 e.2.1 e.2.2 = true)
    (hsc : ∀ q, q < c.R → ∃ e ∈ ss, 2 * c.v + q ∈ e.2.1) : SourceOK c where
  hv := hv
  hs := fun t ht => by
    obtain ⟨e, he, h1, h2⟩ := hxc t ht
    exact ⟨e.2.1, e.2.2, h1, h2, xCheck_sound (hxs e he)⟩
  hyc := fun t ht => by
    obtain ⟨e, he, h1, h2⟩ := hyc t ht
    exact ⟨e.2.1, e.2.2, h1, h2, YRun.of_check (hys e he)⟩
  hA_noY := aNoYK_sound hA
  hsl := fun q hq => by
    obtain ⟨e, he, h1⟩ := hsc q hq
    exact ⟨e.2.1, e.2.2, h1, sCheck_sound (hss e he)⟩

end GS.ZC

#print axioms GS.ZC.xCheck_sound
#print axioms GS.ZC.XRun.xcol
#print axioms GS.ZC.sCheck_sound
#print axioms GS.ZC.SRun.xrow
#print axioms GS.ZC.SRun.yrow
#print axioms GS.ZC.SourceOK.hAi
#print axioms GS.ZC.SourceOK.hBi
#print axioms GS.ZC.SourceOK.hx
#print axioms GS.ZC.SourceOK.hy
#print axioms GS.ZC.SourceOK.hid
#print axioms GS.ZC.SourceOK.scal
#print axioms GS.ZC.SourceOK.gscal
#print axioms GS.ZC.SourceOK.of_checks
