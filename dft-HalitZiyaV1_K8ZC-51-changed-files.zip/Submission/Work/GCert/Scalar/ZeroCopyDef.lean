import Submission.Work.GCert.Scalar.SourceTag16Def

/-!
# Zero-copy provider replay: kernel terms (core Lean only)

A provider certificate WITHOUT source copies has adds `x_t += c * s_q` (an x role reading a
slot).  The existing replays (`GS.Tag16.sourceCheck`, `GS.Tag16.sourceECheck`) run the chunks of
phases A and B under `GS.okBK`, whose conjunct `(v ≤ t ∨ s < v)` rejects such adds; that rule is
only used to derive the zero blocks of the x rows of the total matrix (`GS.SourceOK.xu`).

Here the chunks of A and B run under the relaxed kind test `okZK` ("a y role is read only by a
y role"), and the x rows are computed instead:

* `xCheck c p lo n`: the x columns `lo .. lo+n-1` (as `GS.Tag16.sourceCheck`): at the end `x_t`
  and `y_t` hold exactly source `t`;
* `sCheck c p gl ey`: the slot columns of the registers `gl` (as `GS.Tag16.sourceECheck`): at the
  end every x role holds nothing ("s-mode"), and if `ey` every y role holds nothing too (E7).

Packing, tags, exact division and mask tests are the existing ones (`GS.gGates`, `GS.gScat`,
`GS.gFin`, `GS.Tag16.init`, `GS.Tag16.initL`).  Soundness: `ZeroCopy.lean`.
-/

namespace GS.ZC
open SSC GXD

/-- the relaxed kind test of phases A and B: registers in range, and a y role is read only by a
y role.  (No rule on what an x role reads.) -/
def okZK (v v2 nr t s : Nat) : Bool :=
  Nat.ble (Nat.succ t) nr && (Nat.ble (Nat.succ s) nr &&
    (Nat.ble (Nat.succ s) v || (Nat.ble v2 s || (Nat.ble v t && Nat.ble (Nat.succ t) v2))))

section
variable (c : Raw) (p : SPar) (v2 nr tm K m2 rl : Nat)

/-- one item: chunks of A and of B under `okZK`, the scatter under `okSK` -/
noncomputable def gItem (it : Item) (tr : Trie) (k : Trie → Bool) : Bool :=
  Item.rec (motive := fun _ => Bool)
    (fun gs => gGates tm K m2 p.ux p.us p.uy c.v v2 (okZK c.v v2 nr) (fun _ => true) gs tr k)
    (gScat tm K m2 p.ux p.us p.uy c.v v2 (okSK c.v v2 nr) c.ret rl (scatRows c) c.v tr k)
    (fun gs => gGates tm K m2 p.ux p.us p.uy c.v v2 (okZK c.v v2 nr) (fun _ => true) gs tr k) it

noncomputable def gItems : List Item → Trie → (Trie → Bool) → Bool :=
  List.rec (motive := fun _ => Trie → (Trie → Bool) → Bool)
    (fun tr k => k tr)
    (fun it _ ih tr k => gItem c p v2 nr tm K m2 rl it tr fun tr' => ih tr' k)

end

/-- **x columns** `lo .. lo+n-1`: replay of `sourceProg c` under `okZK`; at the end `x_t` and
`y_t` hold exactly source `t`. -/
noncomputable def xCheck (c : Raw) (p : SPar) (lo n : Nat) : Bool :=
  gPre c p lo n fun v2 nr hi tm K m2 => forceN (List.length c.ret) fun rl =>
    Tag16.init p.sw p.ux lo n 0 (Trie.mk p.d) fun tr0 =>
      gItems c p v2 nr tm K m2 rl (sourceProg c) tr0 fun tr3 =>
        guard (gFin p.sw K m2 p.ux 0 lo hi tr3 c.v 0) (gFin p.sw K m2 p.uy c.v lo hi tr3 c.v 0)

/-- **slot columns** of the registers `gl` (the s-mode): replay of `sourceProg c` under `okZK`;
at the end every x role holds nothing, and if `ey` every y role holds nothing. -/
noncomputable def sCheck (c : Raw) (p : SPar) (gl : List Nat) (ey : Bool) : Bool :=
  gPre c p 0 gl.length fun v2 nr _ tm K m2 =>
    guard (Tag16.incK nr gl v2) (guard (Nat.ble (Nat.succ p.us) (Nat.pow 2 (Nat.sub p.sw 1)))
      (guard (Nat.ble (Nat.succ p.us) 2147483648)
        (forceN (List.length c.ret) fun rl =>
          Tag16.initL p.sw p.us gl 0 (Trie.mk p.d) fun tr0 =>
            gItems c p v2 nr tm K m2 rl (sourceProg c) tr0 fun tr3 =>
              guard (gFin p.sw K m2 p.ux 0 0 0 tr3 c.v 0)
                (Bool.rec (motive := fun _ => Bool) true (gFin p.sw K m2 p.uy c.v 0 0 tr3 c.v 0) ey))))

end GS.ZC
