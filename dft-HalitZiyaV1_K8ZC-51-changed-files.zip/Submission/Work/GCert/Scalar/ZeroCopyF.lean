import Submission.Work.GCert.Scalar.ZeroCopyFDef
import Submission.Work.GCert.Scalar.ZeroCopyL

/-!
# Listed renormalisation with tagged accumulators: soundness

* `dg_tagged`: the digit read in place, `(X mod 2^(64 + sw (T+1))) / 2^(64 + sw T)`, is digit `T`
  of the untagged vector `X / 2^64`;
* `renF_sound`, `renLeafF_sound`: the tagged renormalisation of one leaf satisfies `RenOK` (the
  specification of `ZeroCopyR.lean`: reduced digits, small tags);
* `renLF_state`, `gItemsLF_sound`, `xCheckLF_sound`, `sCheckLF_sound`, `SourceOKR.of_checksLF`: as
  in `ZeroCopyL.lean`.

No `sorry`.
-/

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
set_option linter.deprecated false

namespace GS.ZC
open SSC GXD

/-- the digit read in place from a tagged half -/
theorem dg_tagged (sw X T : Nat) :
    (X % 2 ^ (64 + sw * (T + 1))) / 2 ^ (64 + sw * T) = dg sw (X / 2 ^ 64) T := by
  rw [dg_eq, Nat.div_div_eq_div_mul, ← Nat.pow_add]
  have e : 2 ^ (64 + sw * (T + 1)) = 2 ^ (64 + sw * T) * 2 ^ sw := by
    rw [← Nat.pow_add]; congr 1; ring
  rw [e, Nat.mod_mul_right_div_self]

theorem renF_succ (sw cnt T X Y aP aN tP tN : Nat) (k : Nat → Nat → Nat → Nat → Bool) :
    renF sw (cnt + 1) T X Y aP aN tP tN k =
      renF sw cnt (T + 1) X Y
        (aP + red (dg sw (X / 2 ^ 64) T) (dg sw (Y / 2 ^ 64) T) *
          (2 ^ (64 + sw * T) + (2654435761 * (T + 1)) % 65536))
        (aN + red (dg sw (Y / 2 ^ 64) T) (dg sw (X / 2 ^ 64) T) *
          (2 ^ (64 + sw * T) + (2654435761 * (T + 1)) % 65536))
        (tP + red (dg sw (X / 2 ^ 64) T) (dg sw (Y / 2 ^ 64) T) * ((2654435761 * (T + 1)) % 65536))
        (tN + red (dg sw (Y / 2 ^ 64) T) (dg sw (X / 2 ^ 64) T) * ((2654435761 * (T + 1)) % 65536))
        k := by
  have hm : ∀ p q : Nat, Bool.rec (motive := fun _ => Nat) q p (Nat.ble p q) = min p q := by
    intro p q
    cases h : Nat.ble p q
    · have : ¬ p ≤ q := fun h' => by rw [Nat.ble_eq_true_of_le h'] at h; cases h
      show q = min p q
      omega
    · have : p ≤ q := ble_true h
      show p = min p q
      omega
  have r1 : ∀ p q : Nat, p - min p q = red p q := fun p q => rfl
  have r2 : ∀ p q : Nat, q - min p q = red q p := fun p q => by unfold red; rw [Nat.min_comm]
  have d1 := dg_tagged sw X T
  have d2 := dg_tagged sw Y T
  show forceN ((X % 2 ^ (64 + sw * (T + 1))) / 2 ^ (64 + sw * T)) (fun p =>
      forceN ((Y % 2 ^ (64 + sw * (T + 1))) / 2 ^ (64 + sw * T)) fun q =>
      forceN (Bool.rec (motive := fun _ => Nat) q p (Nat.ble p q)) fun m =>
      forceN (p - m) fun p' => forceN (q - m) fun q' =>
      forceN ((2654435761 * (T + 1)) % 65536) fun w =>
      forceN (aP + p' * (2 ^ (64 + sw * T) + w)) fun aP' =>
      forceN (aN + q' * (2 ^ (64 + sw * T) + w)) fun aN' =>
      forceN (tP + p' * w) fun tP' => forceN (tN + q' * w) fun tN' =>
      renF sw cnt (T + 1) X Y aP' aN' tP' tN' k) = _
  simp only [forceN_eq, hm, r1, r2, d1, d2]

/-- **digits of the tagged renormalisation**: the accumulators are `A * 2^64 + tP` with the reduced
digits in `A` above the old ones -/
theorem renF_sound (sw : Nat) (hsw : 1 ≤ sw) (X Y : Nat) : ∀ (cnt T aP aN tP tN A B : Nat)
    (k : Nat → Nat → Nat → Nat → Bool), aP = A * 2 ^ 64 + tP → aN = B * 2 ^ 64 + tN →
    A < 2 ^ (sw * T) → B < 2 ^ (sw * T) →
    renF sw cnt T X Y aP aN tP tN k = true →
    ∃ A' B' tP' tN', k (A' * 2 ^ 64 + tP') (B' * 2 ^ 64 + tN') tP' tN' = true ∧
      A' < 2 ^ (sw * (T + cnt)) ∧ B' < 2 ^ (sw * (T + cnt)) ∧
      (∀ j, j < T → dg sw A' j = dg sw A j ∧ dg sw B' j = dg sw B j) ∧
      ∀ j, j < cnt →
        dg sw A' (T + j) = red (dg sw (X / 2 ^ 64) (T + j)) (dg sw (Y / 2 ^ 64) (T + j)) ∧
        dg sw B' (T + j) = red (dg sw (Y / 2 ^ 64) (T + j)) (dg sw (X / 2 ^ 64) (T + j)) := by
  intro cnt
  induction cnt with
  | zero =>
    intro T aP aN tP tN A B k hP hN hA hB h
    subst hP; subst hN
    exact ⟨A, B, tP, tN, h, by rw [Nat.add_zero]; exact hA, by rw [Nat.add_zero]; exact hB,
      fun j _ => ⟨rfl, rfl⟩, fun j hj => absurd hj (Nat.not_lt_zero j)⟩
  | succ cnt ih =>
    intro T aP aN tP tN A B k hP hN hA hB h
    subst hP; subst hN
    rw [renF_succ] at h
    have hr1 : red (dg sw (X / 2 ^ 64) T) (dg sw (Y / 2 ^ 64) T) < 2 ^ sw :=
      lt_of_le_of_lt (Nat.sub_le _ _) (dg_lt sw _ T)
    have hr2 : red (dg sw (Y / 2 ^ 64) T) (dg sw (X / 2 ^ 64) T) < 2 ^ sw :=
      lt_of_le_of_lt (Nat.sub_le _ _) (dg_lt sw _ T)
    have bnd : ∀ a r : Nat, a < 2 ^ (sw * T) → r < 2 ^ sw → a + r * 2 ^ (sw * T) < 2 ^ (sw * (T + 1)) := by
      intro a r ha hr
      calc a + r * 2 ^ (sw * T) < 2 ^ (sw * T) + r * 2 ^ (sw * T) := Nat.add_lt_add_right ha _
        _ = (r + 1) * 2 ^ (sw * T) := by ring
        _ ≤ 2 ^ sw * 2 ^ (sw * T) := Nat.mul_le_mul_right _ hr
        _ = 2 ^ (sw * (T + 1)) := by rw [← Nat.pow_add]; congr 1; ring
    have eq : ∀ (C t r w : Nat), C * 2 ^ 64 + t + r * (2 ^ (64 + sw * T) + w)
        = (C + r * 2 ^ (sw * T)) * 2 ^ 64 + (t + r * w) := by
      intro C t r w
      rw [Nat.pow_add]; ring
    obtain ⟨A', B', tP', tN', hk, b1, b2, hlow, hdig⟩ :=
      ih (T + 1) _ _ _ _ _ _ k
        (eq A tP (red (dg sw (X / 2 ^ 64) T) (dg sw (Y / 2 ^ 64) T)) ((2654435761 * (T + 1)) % 65536))
        (eq B tN (red (dg sw (Y / 2 ^ 64) T) (dg sw (X / 2 ^ 64) T)) ((2654435761 * (T + 1)) % 65536))
        (bnd _ _ hA hr1) (bnd _ _ hB hr2) h
    refine ⟨A', B', tP', tN', hk, by rw [show T + (cnt + 1) = T + 1 + cnt by omega]; exact b1,
      by rw [show T + (cnt + 1) = T + 1 + cnt by omega]; exact b2, fun j hj => ?_, fun j hj => ?_⟩
    · obtain ⟨l1, l2⟩ := hlow j (by omega)
      rw [l1, l2, dg_low sw T A _ j hA hj hsw, dg_low sw T B _ j hB hj hsw]
      exact ⟨rfl, rfl⟩
    · cases j with
      | zero =>
        obtain ⟨l1, l2⟩ := hlow T (by omega)
        rw [Nat.add_zero, l1, l2, dg_top sw T A _ hA, dg_top sw T B _ hB, Nat.mod_eq_of_lt hr1,
          Nat.mod_eq_of_lt hr2]
        exact ⟨rfl, rfl⟩
      | succ j =>
        obtain ⟨d1, d2⟩ := hdig j (by omega)
        rw [show T + (j + 1) = T + 1 + j by omega]
        exact ⟨d1, d2⟩

/-- **one leaf**: the tagged renormalisation satisfies `RenOK` -/
theorem renLeafF_sound (sw n K : Nat) (hsw : 1 ≤ sw) (x : Nat) (k : Nat → Bool)
    (h : renLeafF sw n K x k = true) : ∃ x', k x' = true ∧ RenOK sw n K x x' := by
  unfold renLeafF at h
  cases hx : Nat.beq x 0
  case true =>
    rw [hx] at h
    have e : x = 0 := beq_true hx
    subst e
    refine ⟨0, h, 0, 0, 0, 0, by ring, Nat.two_pow_pos _, Nat.two_pow_pos _, by norm_num, by norm_num,
      fun j _ => ?_⟩
    simp [red, dg_zero_left]
  rw [hx] at h
  replace h : forceN (x % 2 ^ K) (fun X => forceN (x >>> K) fun Y =>
      renF sw n 0 X Y 0 0 0 0 fun aP aN tP tN =>
        guard (Nat.ble (Nat.succ tP) 9223372036854775808)
          (guard (Nat.ble (Nat.succ tN) 9223372036854775808)
            (forceN (aP + aN * 2 ^ K) k))) = true := h
  simp only [forceN_eq] at h
  obtain ⟨A', B', tP', tN', hk, b1, b2, _, hdig⟩ := renF_sound sw hsw (x % 2 ^ K) (x >>> K) n 0 0 0 0 0
    0 0 _ (by ring) (by ring) (by simp) (by simp) h
  obtain ⟨g1, hk⟩ := guard_true hk
  obtain ⟨g2, hk⟩ := guard_true hk
  have e63 : (2 : Nat) ^ 63 = 9223372036854775808 := by norm_num
  refine ⟨_, hk, A', B', tP', tN', rfl, by rw [Nat.zero_add] at b1; exact b1,
    by rw [Nat.zero_add] at b2; exact b2, by have := ble_true g1; omega, by have := ble_true g2; omega,
    fun j hj => ?_⟩
  obtain ⟨d1, d2⟩ := hdig j hj
  rw [Nat.zero_add, Nat.shiftRight_eq_div_pow] at d1 d2
  exact ⟨d1, d2⟩

/-- **renormalising the leaves of the listed registers** (tagged version) -/
theorem renLF_state (d sw n : Nat) (u : Nat → Nat) (hsw : 1 ≤ sw) :
    ∀ (rs : List Nat) (tr : Trie), GOk d sw n tr → ∀ (k : Trie → Bool),
      renLF sw n (64 + sw * n) rs tr k = true →
      ∃ tr', k tr' = true ∧ GOk d sw n tr' ∧
        CEq sw n u (absG d (64 + sw * n) tr) (absG d (64 + sw * n) tr') := by
  intro rs
  induction rs with
  | nil => intro tr hI k h; exact ⟨tr, h, hI, fun r T hT => rfl⟩
  | cons r rs ih =>
    intro tr hI k h
    have h1 : modK tr r (fun x kk => renLeafF sw n (64 + sw * n) x kk)
        (fun tr' => renLF sw n (64 + sw * n) rs tr' k) = true := h
    rw [modK_eq d tr hI.wf] at h1
    obtain ⟨hr, h2⟩ := Bool.and_eq_true_iff.mp h1
    have hr' : r < 2 ^ d := of_decide_eq_true hr
    obtain ⟨x', hk, hok⟩ := renLeafF_sound sw n (64 + sw * n) hsw (tr.get r) _ h2
    have hwf1 : (tr.set r x').wf d := Trie.wf_set d tr hI.wf r x'
    have hset := absS_set d tr hI.wf r x' hr'
    have hold : absS (2 ^ d) tr r = tr.get r := absS_apply d tr r hr'
    have hx : OkW sw n (tr.get r % 2 ^ (64 + sw * n)) ∧ OkW sw n (tr.get r >>> (64 + sw * n)) := by
      rw [← hold]; exact hI.ok r
    obtain ⟨hok', hdig⟩ := renOK_facts sw n (tr.get r) x' hx hok
    have hI1 : GOk d sw n (tr.set r x') := by
      refine ⟨hwf1, fun r' => ?_⟩
      rw [hset, Function.update_apply]
      by_cases e : r' = r
      · rw [if_pos e]; exact hok'
      · rw [if_neg e]; exact hI.ok r'
    have hc1 : CEq sw n u (absG d (64 + sw * n) tr) (absG d (64 + sw * n) (tr.set r x')) := by
      intro r' T hT
      unfold gcont
      congr 1
      show ((dg sw ((absS (2 ^ d) tr r' % 2 ^ (64 + sw * n)) >>> 64) T : ℚ)
          - (dg sw ((absS (2 ^ d) tr r' >>> (64 + sw * n)) >>> 64) T : ℚ))
        = ((dg sw ((absS (2 ^ d) (tr.set r x') r' % 2 ^ (64 + sw * n)) >>> 64) T : ℚ)
          - (dg sw ((absS (2 ^ d) (tr.set r x') r' >>> (64 + sw * n)) >>> 64) T : ℚ))
      rw [hset, Function.update_apply]
      by_cases e : r' = r
      · rw [if_pos e, e, hold]
        exact (hdig T hT).symm
      · rw [if_neg e]
    obtain ⟨tr', hk', hI', hc'⟩ := ih (tr.set r x') hI1 k hk
    exact ⟨tr', hk', hI', fun r' T hT => (hc1 r' T hT).trans (hc' r' T hT)⟩

section
variable (c : Raw) (p : SPar) (lo n : Nat) (hp : PGood c p lo n)
include hp

/-- **the replay with listed tagged renormalisations** is a run of the items with
content-preserving jumps -/
theorem gItemsLF_sound (items : List Item) : ∀ (rls : List (List Nat)) (tr : Trie) (k : Trie → Bool),
    GOk p.d p.sw n tr →
    gItemsLF c p n (2 * c.v) (2 * c.v + c.R) (maskW p.sw n) (64 + p.sw * n) (2^(64 + p.sw * n))
      c.ret.length items rls tr k = true →
    ∃ tr', GOk p.d p.sw n tr' ∧ k tr' = true ∧
      ItemsRunR c p n items (absG p.d (64 + p.sw * n) tr) (absG p.d (64 + p.sw * n) tr') := by
  induction items with
  | nil => intro rls tr k hI h; exact ⟨tr, hI, h, rfl⟩
  | cons it items ih =>
    intro rls tr k hI h
    obtain ⟨tr1, hI1, hk1, r1⟩ := gItem_sound c p lo n hp it tr _ hI h
    cases rls with
    | nil =>
      obtain ⟨tr3, hI3, hk3, r3⟩ := ih [] tr1 k hI1 hk1
      exact ⟨tr3, hI3, hk3, _, _, r1, fun r T hT => rfl, r3⟩
    | cons rs rest =>
      obtain ⟨tr2, hk2, hI2, hc⟩ := renLF_state p.d p.sw n (U c p) hp.hsw rs tr1 hI1 _ hk1
      obtain ⟨tr3, hI3, hk3, r3⟩ := ih rest tr2 k hI2 hk2
      exact ⟨tr3, hI3, hk3, _, _, r1, hc, r3⟩

end

theorem xCheckLF_sound {c : Raw} {p : SPar} {lo n : Nat} {rls : List (List Nat)}
    (h : xCheckLF c p lo n rls = true) : XRunR c lo n := by
  unfold xCheckLF at h
  obtain ⟨hp, h1⟩ := pgood_of (gPre_sound c p lo n _ h)
  rw [forceN_eq] at h1
  have h2 : Tag16.init p.sw p.ux lo n 0 (Trie.mk p.d) (fun tr0 =>
      gItemsLF c p n (2 * c.v) (2 * c.v + c.R) (maskW p.sw n) (64 + p.sw * n) (2 ^ (64 + p.sw * n))
        c.ret.length (sourceProg c) rls tr0 fun tr3 =>
          guard (gFin p.sw (64 + p.sw * n) (2 ^ (64 + p.sw * n)) p.ux 0 lo (lo + n) tr3 c.v 0)
            (gFin p.sw (64 + p.sw * n) (2 ^ (64 + p.sw * n)) p.uy c.v lo (lo + n) tr3 c.v 0))
      = true := h1
  have hle : lo + 0 + n ≤ 2 ^ p.d := by have := hp.hd; have := hp.hn; omega
  obtain ⟨t0, hwf, hk, hval⟩ := Tag16.init_sound p.d p.sw p.ux lo n 0 (Trie.mk p.d) _
    (Trie.wf_mk p.d) hle h2
  obtain ⟨hI0, hinit⟩ := Tag16.init_ok p.d p.sw n p.ux lo hp.hsw hp.hxs hp.hx2 t0 hwf hval
  obtain ⟨tr3, hI3, hk3, hr⟩ := gItemsLF_sound c p lo n hp (sourceProg c) rls t0 _ hI0 hk
  obtain ⟨f1, f2⟩ := guard_true hk3
  exact ⟨p, _, _, hp, hinit, hr, hI3.small,
    fin_of c p lo n hp 0 p.ux tr3 hI3 f1, fin_of c p lo n hp c.v p.uy tr3 hI3 f2⟩

theorem sCheckLF_sound {c : Raw} {p : SPar} {gl : List Nat} {ey : Bool} {rls : List (List Nat)}
    (h : sCheckLF c p gl ey rls = true) : SRunR c gl ey := by
  unfold sCheckLF at h
  obtain ⟨hp, h1⟩ := pgood_of (gPre_sound c p 0 gl.length _ h)
  obtain ⟨hinc, h2⟩ := guard_true h1
  obtain ⟨hus, h3⟩ := guard_true h2
  obtain ⟨hus2, h4⟩ := guard_true h3
  rw [forceN_eq] at h4
  have h5 : Tag16.initL p.sw p.us gl 0 (Trie.mk p.d) (fun tr0 =>
      gItemsLF c p gl.length (2 * c.v) (2 * c.v + c.R) (maskW p.sw gl.length) (64 + p.sw * gl.length)
        (2 ^ (64 + p.sw * gl.length)) c.ret.length (sourceProg c) rls tr0 fun tr3 =>
          guard (gFin p.sw (64 + p.sw * gl.length) (2 ^ (64 + p.sw * gl.length)) p.ux 0 0 0 tr3 c.v 0)
            (Bool.rec (motive := fun _ => Bool) true
              (gFin p.sw (64 + p.sw * gl.length) (2 ^ (64 + p.sw * gl.length)) p.uy c.v 0 0 tr3 c.v 0)
              ey)) = true := h4
  have hinc' : GS.incK (2 * c.v + c.R) gl (2 * c.v) = true := by
    rw [← Tag16.incK_eq]; exact hinc
  obtain ⟨hgl, hnd⟩ := incK_sound _ gl _ hinc'
  have hlt : ∀ r ∈ gl, r < 2 ^ p.d := fun r hr => by have := (hgl r hr).2; have := hp.hd; omega
  obtain ⟨t0, hwf, hk, hval⟩ := Tag16.initL_sound p.d p.sw p.us gl 0 (Trie.mk p.d) _
    (Trie.wf_mk p.d) hlt hnd h5
  have husw : p.us < 2 ^ (p.sw - 1) := by
    have := ble_true hus
    have e : Nat.pow 2 (Nat.sub p.sw 1) = 2 ^ (p.sw - 1) := rfl
    omega
  have hu2 := ble_true hus2
  obtain ⟨hI0, hinit⟩ := Tag16.init_okL p.d p.sw p.us gl hp.hsw husw (by omega) t0 hwf hval
  obtain ⟨tr3, hI3, hk3, hr⟩ := gItemsLF_sound c p 0 gl.length hp (sourceProg c) rls t0 _ hI0 hk
  obtain ⟨f1, f2⟩ := guard_true hk3
  refine ⟨p, _, _, hp, hgl, hnd, husw, hinit, hr, fun S hS => ?_, fun hey S hS => ?_⟩
  · have h6 := gFin_sound p.d p.sw (64 + p.sw * gl.length) p.ux 0 0 0 tr3 hI3.wf c.v 0 f1 S hS
    have e1 : (0:Nat) + (0 + S) = S := by omega
    have e2 : ¬ (0 ≤ 0 + S ∧ 0 + S < 0) := by omega
    rw [e1, if_neg e2, Nat.add_zero] at h6
    exact h6
  · have f2' : gFin p.sw (64 + p.sw * gl.length) (2 ^ (64 + p.sw * gl.length)) p.uy c.v 0 0 tr3
        c.v 0 = true := by
      rw [hey] at f2; exact f2
    have h6 := gFin_sound p.d p.sw (64 + p.sw * gl.length) p.uy c.v 0 0 tr3 hI3.wf c.v 0 f2' S hS
    have e1 : (0:Nat) + S = S := by omega
    have e2 : ¬ (0 ≤ 0 + S ∧ 0 + S < 0) := by omega
    rw [if_neg e2, e1, Nat.add_zero] at h6
    exact h6

/-- `SourceOKR` from lists of accepted kernel checks with listed tagged renormalisations -/
theorem SourceOKR.of_checksLF {c : Raw} (hv : 0 < c.v) (hk : kindsK c = true) (rls : List (List Nat))
    (xs : List (SPar × Nat × Nat)) (hxs : ∀ e ∈ xs, xCheckLF c e.1 e.2.1 e.2.2 rls = true)
    (hxc : ∀ t, t < c.v → ∃ e ∈ xs, e.2.1 ≤ t ∧ t < e.2.1 + e.2.2)
    (ys : List (SPar × Nat × Nat)) (hys : ∀ e ∈ ys, yCheck c e.1 e.2.1 e.2.2 = true)
    (hyc : ∀ t, t < c.v → ∃ e ∈ ys, e.2.1 ≤ t ∧ t < e.2.1 + e.2.2)
    (hA : aNoYK c = true)
    (ss : List (SPar × List Nat × Bool)) (hss : ∀ e ∈ ss, sCheckLF c e.1 e.2.1 e.2.2 rls = true)
    (hsc : ∀ q, q < c.R → ∃ e ∈ ss, 2 * c.v + q ∈ e.2.1) : SourceOKR c where
  hv := hv
  hk := hk
  hs := fun t ht => by
    obtain ⟨e, he, h1, h2⟩ := hxc t ht
    exact ⟨e.2.1, e.2.2, h1, h2, xCheckLF_sound (hxs e he)⟩
  hyc := fun t ht => by
    obtain ⟨e, he, h1, h2⟩ := hyc t ht
    exact ⟨e.2.1, e.2.2, h1, h2, YRun.of_check (hys e he)⟩
  hA_noY := aNoYK_sound hA
  hsl := fun q hq => by
    obtain ⟨e, he, h1⟩ := hsc q hq
    exact ⟨e.2.1, e.2.2, h1, sCheckLF_sound (hss e he)⟩

end GS.ZC

#print axioms GS.ZC.dg_tagged
#print axioms GS.ZC.renF_sound
#print axioms GS.ZC.renLeafF_sound
#print axioms GS.ZC.renLF_state
#print axioms GS.ZC.gItemsLF_sound
#print axioms GS.ZC.xCheckLF_sound
#print axioms GS.ZC.sCheckLF_sound
#print axioms GS.ZC.SourceOKR.of_checksLF
