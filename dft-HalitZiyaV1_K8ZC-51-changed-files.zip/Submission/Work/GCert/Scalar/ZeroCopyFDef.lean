import Submission.Work.GCert.Scalar.ZeroCopyLDef

/-!
# Zero-copy provider replay, listed renormalisation with TAGGED accumulators: kernel terms

`GS.ZC.renLeaf` (`ZeroCopyRDef.lean`) builds the renormalised digits in untagged accumulators
(`aP + p' * 2^(sw T)`) and shifts the untagged vectors digit by digit.  Those intermediate numerals
mostly share their low bits (zero digits at the bottom), and the kernel hashes a numeral by its low
bits: they collide in its caches and the run time grows quadratically (measured).  Here every big
intermediate carries a tag in its low 64 bits:

* the digits of the tagged halves `X = V * 2^64 + tag` are read in place,
  `digit T = (X mod 2^(64 + sw (T+1))) / 2^(64 + sw T)` (no shifted copies);
* the reduced digits are accumulated directly in tagged form,
  `aP + p' * (2^(64 + sw T) + w_T)` with the 16-bit weight `w_T` of `GS.Tag16`; the tags themselves
  are also summed separately (`tP`, `tN`) for the bound test `< 2^63`.

The result is the same leaf as `GS.ZC.renLeaf` (same digits, same tags).

* `renF`, `renLeafF`: the digits and one leaf;
* `renLF`, `gItemsLF`, `xCheckLF`, `sCheckLF`: as `renL`, `gItemsL`, `xCheckL`, `sCheckL`.

Soundness: `ZeroCopyF.lean`.
-/

namespace GS.ZC
open SSC GXD

/-- renormalise `cnt` digits `T, T+1, ..` of the tagged halves `X`, `Y`, accumulating the reduced
digits in tagged form (`aP`, `aN`) and their tags (`tP`, `tN`) -/
noncomputable def renF (sw : Nat) :
    Nat → Nat → Nat → Nat → Nat → Nat → Nat → Nat → (Nat → Nat → Nat → Nat → Bool) → Bool :=
  Nat.rec (motive := fun _ => Nat → Nat → Nat → Nat → Nat → Nat → Nat →
      (Nat → Nat → Nat → Nat → Bool) → Bool)
    (fun _ _ _ aP aN tP tN k => k aP aN tP tN)
    (fun _ ih T X Y aP aN tP tN k =>
      forceN (Nat.div (Nat.mod X (Nat.pow 2 (Nat.add 64 (Nat.mul sw (Nat.succ T)))))
        (Nat.pow 2 (Nat.add 64 (Nat.mul sw T)))) fun p =>
      forceN (Nat.div (Nat.mod Y (Nat.pow 2 (Nat.add 64 (Nat.mul sw (Nat.succ T)))))
        (Nat.pow 2 (Nat.add 64 (Nat.mul sw T)))) fun q =>
      forceN (Bool.rec (motive := fun _ => Nat) q p (Nat.ble p q)) fun m =>
      forceN (Nat.sub p m) fun p' => forceN (Nat.sub q m) fun q' =>
      forceN (Nat.mod (Nat.mul 2654435761 (Nat.succ T)) 65536) fun w =>
      forceN (Nat.add aP (Nat.mul p' (Nat.add (Nat.pow 2 (Nat.add 64 (Nat.mul sw T))) w))) fun aP' =>
      forceN (Nat.add aN (Nat.mul q' (Nat.add (Nat.pow 2 (Nat.add 64 (Nat.mul sw T))) w))) fun aN' =>
      forceN (Nat.add tP (Nat.mul p' w)) fun tP' => forceN (Nat.add tN (Nat.mul q' w)) fun tN' =>
      ih (Nat.succ T) X Y aP' aN' tP' tN' k)

/-- the renormalised leaf of `x` (`x = X + Y * 2^K`, tagged halves of `K` bits, `n` digits of width
`sw`); a zero leaf stays zero -/
noncomputable def renLeafF (sw n K : Nat) (x : Nat) (k : Nat → Bool) : Bool :=
  Bool.rec (motive := fun _ => Bool)
    (forceN (Nat.mod x (Nat.pow 2 K)) fun X => forceN (Nat.shiftRight x K) fun Y =>
      renF sw n 0 X Y 0 0 0 0 fun aP aN tP tN =>
        guard (Nat.ble (Nat.succ tP) 9223372036854775808)
          (guard (Nat.ble (Nat.succ tN) 9223372036854775808)
            (forceN (Nat.add aP (Nat.mul aN (Nat.pow 2 K))) k)))
    (k 0) (Nat.beq x 0)

/-- renormalise the leaves of the registers `rs` -/
noncomputable def renLF (sw n K : Nat) : List Nat → Trie → (Trie → Bool) → Bool :=
  List.rec (motive := fun _ => Trie → (Trie → Bool) → Bool)
    (fun tr k => k tr)
    (fun r _ ih tr k => modK tr r (fun x kk => renLeafF sw n K x kk) fun tr' => ih tr' k)

section
variable (c : Raw) (p : SPar) (n v2 nr tm K m2 rl : Nat)

/-- the items; after item `i` the registers of the `i`-th list of `rls` are renormalised -/
noncomputable def gItemsLF : List Item → List (List Nat) → Trie → (Trie → Bool) → Bool :=
  List.rec (motive := fun _ => List (List Nat) → Trie → (Trie → Bool) → Bool)
    (fun _ tr k => k tr)
    (fun it _ ih rls tr k => gItem c p v2 nr tm K m2 rl it tr fun tr' =>
      List.rec (motive := fun _ => Bool) (ih [] tr' k)
        (fun rs rest _ => renLF p.sw n K rs tr' fun tr'' => ih rest tr'' k) rls)

end

/-- **x columns** `lo .. lo+n-1`, renormalising the registers `rls[i]` after item `i` -/
noncomputable def xCheckLF (c : Raw) (p : SPar) (lo n : Nat) (rls : List (List Nat)) : Bool :=
  gPre c p lo n fun v2 nr hi tm K m2 => forceN (List.length c.ret) fun rl =>
    Tag16.init p.sw p.ux lo n 0 (Trie.mk p.d) fun tr0 =>
      gItemsLF c p n v2 nr tm K m2 rl (sourceProg c) rls tr0 fun tr3 =>
        guard (gFin p.sw K m2 p.ux 0 lo hi tr3 c.v 0) (gFin p.sw K m2 p.uy c.v lo hi tr3 c.v 0)

/-- **slot columns** (registers `gl`), renormalising the registers `rls[i]` after item `i` -/
noncomputable def sCheckLF (c : Raw) (p : SPar) (gl : List Nat) (ey : Bool) (rls : List (List Nat)) :
    Bool :=
  gPre c p 0 gl.length fun v2 nr _ tm K m2 =>
    guard (Tag16.incK nr gl v2) (guard (Nat.ble (Nat.succ p.us) (Nat.pow 2 (Nat.sub p.sw 1)))
      (guard (Nat.ble (Nat.succ p.us) 2147483648)
        (forceN (List.length c.ret) fun rl =>
          Tag16.initL p.sw p.us gl 0 (Trie.mk p.d) fun tr0 =>
            gItemsLF c p gl.length v2 nr tm K m2 rl (sourceProg c) rls tr0 fun tr3 =>
              guard (gFin p.sw K m2 p.ux 0 0 0 tr3 c.v 0)
                (Bool.rec (motive := fun _ => Bool) true (gFin p.sw K m2 p.uy c.v 0 0 tr3 c.v 0) ey))))

end GS.ZC
