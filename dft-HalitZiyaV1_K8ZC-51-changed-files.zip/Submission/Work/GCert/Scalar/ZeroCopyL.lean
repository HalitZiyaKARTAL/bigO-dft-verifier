import Submission.Work.GCert.Scalar.ZeroCopyLDef
import Submission.Work.GCert.Scalar.ZeroCopyR

/-!
# Zero-copy provider replay with renormalisation of listed registers: soundness

* `renOK_facts`: a renormalised leaf (`RenOK`) has small digits and tags and the same contents;
* `renL_state`: renormalising the leaves of any list of registers keeps a well-formed state with
  small digits and the same contents (`CEq`);
* `gItemsL_sound`: the replay `gItemsL` (any renormalisation lists) is a run of the items with
  content-preserving jumps (`ItemsRunR`, as for `gItemsR`);
* `xCheckL_sound`, `sCheckL_sound`: the checks give `XRunR` and `SRunR`, so `ZeroCopyR.lean`
  (`XRunR.xcol`, `SRunR.xrow`, `SRunR.yrow`, `SourceOKR`) applies unchanged;
* `SourceOKR.of_checksL`: the scalar half from lists of accepted checks.

No `sorry`.
-/

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
set_option linter.deprecated false

namespace GS.ZC
open SSC GXD

/-- **one renormalised leaf**: small digits and tags, the same digit differences -/
theorem renOK_facts (sw n : Nat) (x x' : Nat)
    (hx : OkW sw n (x % 2 ^ (64 + sw * n)) ∧ OkW sw n (x >>> (64 + sw * n)))
    (h : RenOK sw n (64 + sw * n) x x') :
    (OkW sw n (x' % 2 ^ (64 + sw * n)) ∧ OkW sw n (x' >>> (64 + sw * n))) ∧
    ∀ T, T < n →
      ((dg sw ((x' % 2 ^ (64 + sw * n)) >>> 64) T : ℚ) - (dg sw ((x' >>> (64 + sw * n)) >>> 64) T : ℚ))
        = ((dg sw ((x % 2 ^ (64 + sw * n)) >>> 64) T : ℚ)
          - (dg sw ((x >>> (64 + sw * n)) >>> 64) T : ℚ)) := by
  obtain ⟨aP, aN, tP, tN, ex, b1, b2, t1, t2, hdig⟩ := h
  have K2 : aP * 2 ^ 64 + tP < 2 ^ (64 + sw * n) := by
    have h3 : tP < 2 ^ 64 := lt_trans t1 (by norm_num)
    calc aP * 2 ^ 64 + tP < aP * 2 ^ 64 + 2 ^ 64 := Nat.add_lt_add_left h3 _
      _ = (aP + 1) * 2 ^ 64 := by ring
      _ ≤ 2 ^ (sw * n) * 2 ^ 64 := Nat.mul_le_mul_right _ b1
      _ = 2 ^ (64 + sw * n) := by rw [← Nat.pow_add, Nat.add_comm]
  have h1 : ((aP * 2 ^ 64 + tP) + (aN * 2 ^ 64 + tN) * 2 ^ (64 + sw * n)) % 2 ^ (64 + sw * n)
      = aP * 2 ^ 64 + tP := by
    rw [Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt K2]
  have h2 : ((aP * 2 ^ 64 + tP) + (aN * 2 ^ 64 + tN) * 2 ^ (64 + sw * n)) / 2 ^ (64 + sw * n)
      = aN * 2 ^ 64 + tN := by
    rw [Nat.add_mul_div_right _ _ (Nat.two_pow_pos _), Nat.div_eq_of_lt K2, Nat.zero_add]
  have untag : ∀ a t : Nat, t < 2 ^ 63 → (a * 2 ^ 64 + t) / 2 ^ 64 = a ∧ (a * 2 ^ 64 + t) % 2 ^ 64 = t := by
    intro a t ht
    have : t < 2 ^ 64 := lt_trans ht (by norm_num)
    refine ⟨?_, ?_⟩
    · rw [Nat.add_comm, Nat.add_mul_div_right _ _ (by norm_num), Nat.div_eq_of_lt this, Nat.zero_add]
    · rw [Nat.add_comm, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt this]
  obtain ⟨u1, u2⟩ := untag aP tP t1
  obtain ⟨v1, v2⟩ := untag aN tN t2
  obtain ⟨o1, o2⟩ := hx
  refine ⟨?_, fun T hT => ?_⟩
  · rw [ex, Nat.shiftRight_eq_div_pow, h1, h2]
    refine ⟨⟨fun T hT => ?_, by rw [u2]; exact t1⟩, ⟨fun T hT => ?_, by rw [v2]; exact t2⟩⟩
    · rw [Nat.shiftRight_eq_div_pow, u1, (hdig T hT).1]
      have := o1.1 T hT
      rw [Nat.shiftRight_eq_div_pow] at this
      exact lt_of_le_of_lt (Nat.sub_le _ _) this
    · rw [Nat.shiftRight_eq_div_pow, v1, (hdig T hT).2]
      have := o2.1 T hT
      rw [Nat.shiftRight_eq_div_pow, Nat.shiftRight_eq_div_pow] at this
      exact lt_of_le_of_lt (Nat.sub_le _ _) this
  · have e1 : (x' % 2 ^ (64 + sw * n)) >>> 64 = aP := by
      rw [ex, h1, Nat.shiftRight_eq_div_pow, u1]
    have e2 : (x' >>> (64 + sw * n)) >>> 64 = aN := by
      rw [ex]
      simp only [Nat.shiftRight_eq_div_pow]
      rw [h2, v1]
    rw [e1, e2, (hdig T hT).1, (hdig T hT).2, red_sub]
    all_goals simp only [Nat.shiftRight_eq_div_pow]

/-- **renormalising the leaves of the listed registers** keeps a well-formed state with small digits
and tags and the same contents -/
theorem renL_state (d sw n : Nat) (u : Nat → Nat) (hsw : 1 ≤ sw) :
    ∀ (rs : List Nat) (tr : Trie), GOk d sw n tr → ∀ (k : Trie → Bool),
      renL sw n (64 + sw * n) rs tr k = true →
      ∃ tr', k tr' = true ∧ GOk d sw n tr' ∧
        CEq sw n u (absG d (64 + sw * n) tr) (absG d (64 + sw * n) tr') := by
  intro rs
  induction rs with
  | nil => intro tr hI k h; exact ⟨tr, h, hI, fun r T hT => rfl⟩
  | cons r rs ih =>
    intro tr hI k h
    have h1 : modK tr r (fun x kk => renLeaf sw n (64 + sw * n) x kk)
        (fun tr' => renL sw n (64 + sw * n) rs tr' k) = true := h
    rw [modK_eq d tr hI.wf] at h1
    obtain ⟨hr, h2⟩ := Bool.and_eq_true_iff.mp h1
    have hr' : r < 2 ^ d := of_decide_eq_true hr
    obtain ⟨x', hk, hok⟩ := renLeaf_sound sw n (64 + sw * n) hsw (tr.get r) _ h2
    have hwf1 : (tr.set r x').wf d := Trie.wf_set d tr hI.wf r x'
    have hset := absS_set d tr hI.wf r x' hr'
    have hold : absS (2 ^ d) tr r = tr.get r := absS_apply d tr r hr'
    have hx : OkW sw n (tr.get r % 2 ^ (64 + sw * n)) ∧ OkW sw n (tr.get r >>> (64 + sw * n)) := by
      rw [← hold]; exact hI.ok r
    obtain ⟨hok', hdig⟩ := renOK_facts sw n (tr.get r) x' hx hok
    have hI1 : GOk d sw n (tr.set r x') := by
      refine ⟨hwf1, fun r' => ?_⟩
      rw [hset, Function.update_apply]
      by_cases e : r' = r
      · rw [if_pos e]; exact hok'
      · rw [if_neg e]; exact hI.ok r'
    have hc1 : CEq sw n u (absG d (64 + sw * n) tr) (absG d (64 + sw * n) (tr.set r x')) := by
      intro r' T hT
      unfold gcont
      congr 1
      show ((dg sw ((absS (2 ^ d) tr r' % 2 ^ (64 + sw * n)) >>> 64) T : ℚ)
          - (dg sw ((absS (2 ^ d) tr r' >>> (64 + sw * n)) >>> 64) T : ℚ))
        = ((dg sw ((absS (2 ^ d) (tr.set r x') r' % 2 ^ (64 + sw * n)) >>> 64) T : ℚ)
          - (dg sw ((absS (2 ^ d) (tr.set r x') r' >>> (64 + sw * n)) >>> 64) T : ℚ))
      rw [hset, Function.update_apply]
      by_cases e : r' = r
      · rw [if_pos e, e, hold]
        exact (hdig T hT).symm
      · rw [if_neg e]
    obtain ⟨tr', hk', hI', hc'⟩ := ih (tr.set r x') hI1 k hk
    exact ⟨tr', hk', hI', fun r' T hT => (hc1 r' T hT).trans (hc' r' T hT)⟩

section
variable (c : Raw) (p : SPar) (lo n : Nat) (hp : PGood c p lo n)
include hp

/-- **the replay with listed renormalisations** is a run of the items with content-preserving
jumps -/
theorem gItemsL_sound (items : List Item) : ∀ (rls : List (List Nat)) (tr : Trie) (k : Trie → Bool),
    GOk p.d p.sw n tr →
    gItemsL c p n (2 * c.v) (2 * c.v + c.R) (maskW p.sw n) (64 + p.sw * n) (2^(64 + p.sw * n))
      c.ret.length items rls tr k = true →
    ∃ tr', GOk p.d p.sw n tr' ∧ k tr' = true ∧
      ItemsRunR c p n items (absG p.d (64 + p.sw * n) tr) (absG p.d (64 + p.sw * n) tr') := by
  induction items with
  | nil => intro rls tr k hI h; exact ⟨tr, hI, h, rfl⟩
  | cons it items ih =>
    intro rls tr k hI h
    obtain ⟨tr1, hI1, hk1, r1⟩ := gItem_sound c p lo n hp it tr _ hI h
    cases rls with
    | nil =>
      obtain ⟨tr3, hI3, hk3, r3⟩ := ih [] tr1 k hI1 hk1
      exact ⟨tr3, hI3, hk3, _, _, r1, fun r T hT => rfl, r3⟩
    | cons rs rest =>
      obtain ⟨tr2, hk2, hI2, hc⟩ := renL_state p.d p.sw n (U c p) hp.hsw rs tr1 hI1 _ hk1
      obtain ⟨tr3, hI3, hk3, r3⟩ := ih rest tr2 k hI2 hk2
      exact ⟨tr3, hI3, hk3, _, _, r1, hc, r3⟩

end

/-- the x-column check with listed renormalisations gives an accepted renormalising run -/
theorem xCheckL_sound {c : Raw} {p : SPar} {lo n : Nat} {rls : List (List Nat)}
    (h : xCheckL c p lo n rls = true) : XRunR c lo n := by
  unfold xCheckL at h
  obtain ⟨hp, h1⟩ := pgood_of (gPre_sound c p lo n _ h)
  rw [forceN_eq] at h1
  have h2 : Tag16.init p.sw p.ux lo n 0 (Trie.mk p.d) (fun tr0 =>
      gItemsL c p n (2 * c.v) (2 * c.v + c.R) (maskW p.sw n) (64 + p.sw * n) (2 ^ (64 + p.sw * n))
        c.ret.length (sourceProg c) rls tr0 fun tr3 =>
          guard (gFin p.sw (64 + p.sw * n) (2 ^ (64 + p.sw * n)) p.ux 0 lo (lo + n) tr3 c.v 0)
            (gFin p.sw (64 + p.sw * n) (2 ^ (64 + p.sw * n)) p.uy c.v lo (lo + n) tr3 c.v 0))
      = true := h1
  have hle : lo + 0 + n ≤ 2 ^ p.d := by have := hp.hd; have := hp.hn; omega
  obtain ⟨t0, hwf, hk, hval⟩ := Tag16.init_sound p.d p.sw p.ux lo n 0 (Trie.mk p.d) _
    (Trie.wf_mk p.d) hle h2
  obtain ⟨hI0, hinit⟩ := Tag16.init_ok p.d p.sw n p.ux lo hp.hsw hp.hxs hp.hx2 t0 hwf hval
  obtain ⟨tr3, hI3, hk3, hr⟩ := gItemsL_sound c p lo n hp (sourceProg c) rls t0 _ hI0 hk
  obtain ⟨f1, f2⟩ := guard_true hk3
  exact ⟨p, _, _, hp, hinit, hr, hI3.small,
    fin_of c p lo n hp 0 p.ux tr3 hI3 f1, fin_of c p lo n hp c.v p.uy tr3 hI3 f2⟩

/-- the slot-column check with listed renormalisations gives an accepted renormalising run -/
theorem sCheckL_sound {c : Raw} {p : SPar} {gl : List Nat} {ey : Bool} {rls : List (List Nat)}
    (h : sCheckL c p gl ey rls = true) : SRunR c gl ey := by
  unfold sCheckL at h
  obtain ⟨hp, h1⟩ := pgood_of (gPre_sound c p 0 gl.length _ h)
  obtain ⟨hinc, h2⟩ := guard_true h1
  obtain ⟨hus, h3⟩ := guard_true h2
  obtain ⟨hus2, h4⟩ := guard_true h3
  rw [forceN_eq] at h4
  have h5 : Tag16.initL p.sw p.us gl 0 (Trie.mk p.d) (fun tr0 =>
      gItemsL c p gl.length (2 * c.v) (2 * c.v + c.R) (maskW p.sw gl.length) (64 + p.sw * gl.length)
        (2 ^ (64 + p.sw * gl.length)) c.ret.length (sourceProg c) rls tr0 fun tr3 =>
          guard (gFin p.sw (64 + p.sw * gl.length) (2 ^ (64 + p.sw * gl.length)) p.ux 0 0 0 tr3 c.v 0)
            (Bool.rec (motive := fun _ => Bool) true
              (gFin p.sw (64 + p.sw * gl.length) (2 ^ (64 + p.sw * gl.length)) p.uy c.v 0 0 tr3 c.v 0)
              ey)) = true := h4
  have hinc' : GS.incK (2 * c.v + c.R) gl (2 * c.v) = true := by
    rw [← Tag16.incK_eq]; exact hinc
  obtain ⟨hgl, hnd⟩ := incK_sound _ gl _ hinc'
  have hlt : ∀ r ∈ gl, r < 2 ^ p.d := fun r hr => by have := (hgl r hr).2; have := hp.hd; omega
  obtain ⟨t0, hwf, hk, hval⟩ := Tag16.initL_sound p.d p.sw p.us gl 0 (Trie.mk p.d) _
    (Trie.wf_mk p.d) hlt hnd h5
  have husw : p.us < 2 ^ (p.sw - 1) := by
    have := ble_true hus
    have e : Nat.pow 2 (Nat.sub p.sw 1) = 2 ^ (p.sw - 1) := rfl
    omega
  have hu2 := ble_true hus2
  obtain ⟨hI0, hinit⟩ := Tag16.init_okL p.d p.sw p.us gl hp.hsw husw (by omega) t0 hwf hval
  obtain ⟨tr3, hI3, hk3, hr⟩ := gItemsL_sound c p 0 gl.length hp (sourceProg c) rls t0 _ hI0 hk
  obtain ⟨f1, f2⟩ := guard_true hk3
  refine ⟨p, _, _, hp, hgl, hnd, husw, hinit, hr, fun S hS => ?_, fun hey S hS => ?_⟩
  · have h6 := gFin_sound p.d p.sw (64 + p.sw * gl.length) p.ux 0 0 0 tr3 hI3.wf c.v 0 f1 S hS
    have e1 : (0:Nat) + (0 + S) = S := by omega
    have e2 : ¬ (0 ≤ 0 + S ∧ 0 + S < 0) := by omega
    rw [e1, if_neg e2, Nat.add_zero] at h6
    exact h6
  · have f2' : gFin p.sw (64 + p.sw * gl.length) (2 ^ (64 + p.sw * gl.length)) p.uy c.v 0 0 tr3
        c.v 0 = true := by
      rw [hey] at f2; exact f2
    have h6 := gFin_sound p.d p.sw (64 + p.sw * gl.length) p.uy c.v 0 0 tr3 hI3.wf c.v 0 f2' S hS
    have e1 : (0:Nat) + S = S := by omega
    have e2 : ¬ (0 ≤ 0 + S ∧ 0 + S < 0) := by omega
    rw [if_neg e2, e1, Nat.add_zero] at h6
    exact h6

/-- `SourceOKR` from lists of accepted kernel checks with listed renormalisations (one list of
register lists `rls` for all checks). -/
theorem SourceOKR.of_checksL {c : Raw} (hv : 0 < c.v) (hk : kindsK c = true) (rls : List (List Nat))
    (xs : List (SPar × Nat × Nat)) (hxs : ∀ e ∈ xs, xCheckL c e.1 e.2.1 e.2.2 rls = true)
    (hxc : ∀ t, t < c.v → ∃ e ∈ xs, e.2.1 ≤ t ∧ t < e.2.1 + e.2.2)
    (ys : List (SPar × Nat × Nat)) (hys : ∀ e ∈ ys, yCheck c e.1 e.2.1 e.2.2 = true)
    (hyc : ∀ t, t < c.v → ∃ e ∈ ys, e.2.1 ≤ t ∧ t < e.2.1 + e.2.2)
    (hA : aNoYK c = true)
    (ss : List (SPar × List Nat × Bool)) (hss : ∀ e ∈ ss, sCheckL c e.1 e.2.1 e.2.2 rls = true)
    (hsc : ∀ q, q < c.R → ∃ e ∈ ss, 2 * c.v + q ∈ e.2.1) : SourceOKR c where
  hv := hv
  hk := hk
  hs := fun t ht => by
    obtain ⟨e, he, h1, h2⟩ := hxc t ht
    exact ⟨e.2.1, e.2.2, h1, h2, xCheckL_sound (hxs e he)⟩
  hyc := fun t ht => by
    obtain ⟨e, he, h1, h2⟩ := hyc t ht
    exact ⟨e.2.1, e.2.2, h1, h2, YRun.of_check (hys e he)⟩
  hA_noY := aNoYK_sound hA
  hsl := fun q hq => by
    obtain ⟨e, he, h1⟩ := hsc q hq
    exact ⟨e.2.1, e.2.2, h1, sCheckL_sound (hss e he)⟩

end GS.ZC

#print axioms GS.ZC.renOK_facts
#print axioms GS.ZC.renL_state
#print axioms GS.ZC.gItemsL_sound
#print axioms GS.ZC.xCheckL_sound
#print axioms GS.ZC.sCheckL_sound
#print axioms GS.ZC.SourceOKR.of_checksL
