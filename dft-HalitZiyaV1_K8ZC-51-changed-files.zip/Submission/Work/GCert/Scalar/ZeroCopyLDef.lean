import Submission.Work.GCert.Scalar.ZeroCopyRDef

/-!
# Zero-copy provider replay with renormalisation of LISTED registers: kernel terms (core Lean only)

As `ZeroCopyRDef.lean`, but after item `i` only the registers of the `i`-th list of a given list
`rls` are renormalised (`renL`: one descent per register), instead of every leaf of the trie.  A
register that the item does not modify is unchanged, so renormalising the targets of every item
gives the same states as `GS.ZC.gItemsR` at a fraction of the cost.  The lists are DATA: whatever
they contain, renormalising a register keeps its content, so soundness does not depend on them.

* `renL`: renormalise the leaves of a list of registers;
* `gItemsL`: `GS.ZC.gItems` with `renL` of the `i`-th list after item `i` (no list: nothing);
* `xCheckL`, `sCheckL`: `GS.ZC.xCheckR`, `GS.ZC.sCheckR` on `gItemsL`.

Soundness: `ZeroCopyL.lean`.
-/

namespace GS.ZC
open SSC GXD

/-- renormalise the leaves of the registers `rs` (one descent each; fails on a register out of
range) -/
noncomputable def renL (sw n K : Nat) : List Nat → Trie → (Trie → Bool) → Bool :=
  List.rec (motive := fun _ => Trie → (Trie → Bool) → Bool)
    (fun tr k => k tr)
    (fun r _ ih tr k => modK tr r (fun x kk => renLeaf sw n K x kk) fun tr' => ih tr' k)

section
variable (c : Raw) (p : SPar) (n v2 nr tm K m2 rl : Nat)

/-- the items; after item `i` the registers of the `i`-th list of `rls` are renormalised -/
noncomputable def gItemsL : List Item → List (List Nat) → Trie → (Trie → Bool) → Bool :=
  List.rec (motive := fun _ => List (List Nat) → Trie → (Trie → Bool) → Bool)
    (fun _ tr k => k tr)
    (fun it _ ih rls tr k => gItem c p v2 nr tm K m2 rl it tr fun tr' =>
      List.rec (motive := fun _ => Bool) (ih [] tr' k)
        (fun rs rest _ => renL p.sw n K rs tr' fun tr'' => ih rest tr'' k) rls)

end

/-- **x columns** `lo .. lo+n-1`, renormalising the registers `rls[i]` after item `i`. -/
noncomputable def xCheckL (c : Raw) (p : SPar) (lo n : Nat) (rls : List (List Nat)) : Bool :=
  gPre c p lo n fun v2 nr hi tm K m2 => forceN (List.length c.ret) fun rl =>
    Tag16.init p.sw p.ux lo n 0 (Trie.mk p.d) fun tr0 =>
      gItemsL c p n v2 nr tm K m2 rl (sourceProg c) rls tr0 fun tr3 =>
        guard (gFin p.sw K m2 p.ux 0 lo hi tr3 c.v 0) (gFin p.sw K m2 p.uy c.v lo hi tr3 c.v 0)

/-- **slot columns** (registers `gl`), renormalising the registers `rls[i]` after item `i`. -/
noncomputable def sCheckL (c : Raw) (p : SPar) (gl : List Nat) (ey : Bool) (rls : List (List Nat)) :
    Bool :=
  gPre c p 0 gl.length fun v2 nr _ tm K m2 =>
    guard (Tag16.incK nr gl v2) (guard (Nat.ble (Nat.succ p.us) (Nat.pow 2 (Nat.sub p.sw 1)))
      (guard (Nat.ble (Nat.succ p.us) 2147483648)
        (forceN (List.length c.ret) fun rl =>
          Tag16.initL p.sw p.us gl 0 (Trie.mk p.d) fun tr0 =>
            gItemsL c p gl.length v2 nr tm K m2 rl (sourceProg c) rls tr0 fun tr3 =>
              guard (gFin p.sw K m2 p.ux 0 0 0 tr3 c.v 0)
                (Bool.rec (motive := fun _ => Bool) true (gFin p.sw K m2 p.uy c.v 0 0 tr3 c.v 0) ey))))

end GS.ZC
