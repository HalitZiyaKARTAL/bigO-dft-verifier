import Submission.Work.GCert.Scalar.ZeroCopyRDef
import Submission.Work.GCert.Scalar.ZeroCopy

/-!
# Zero-copy provider replay with renormalisation: soundness

* `renLeaf_sound`, `renT_sound`: the kernel renormalisation keeps every content (`P_T - N_T`) and gives a
  well-formed state with small digits (`RenOK`, `TRel`);
* `gItemsR_sound`: the renormalising replay of a list of items is a run of the items with content-preserving
  jumps (`ItemsRunR`);
* `ItemsRunR.cm`: such a run of `sourceProg c` multiplies the content matrix by the total matrix `Mt`;
* `xCheckR_sound`, `XRunR.xcol`, `sCheckR_sound`, `SRunR.xrow`, `SRunR.yrow`: as in `ZeroCopy.lean`;
* `kindsK_sound`: the kinds of every add;
* `SourceOKR c`: the scalar half (`hAi hBi hx hy hid`, `scal : GX.Scal`, `gscal : GX.GScal`).

No `sorry`.
-/

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
set_option linter.deprecated false

namespace GS.ZC
open SSC GXD OAI.PowerSaving OAI.PowerSaving.Binary OAI.PowerSaving.RAM OAI.PowerSaving.SS
  OAI.PowerSaving.CB OAI.PowerSaving.CR Finset Matrix

/-! ## digits of a sum `a + b * 2^(sw T)` -/

theorem dg_lt (sw X T : Nat) : dg sw X T < 2 ^ sw := Nat.mod_lt _ (Nat.two_pow_pos sw)

theorem dg_eq (sw X T : Nat) : dg sw X T = X / 2 ^ (sw * T) % 2 ^ sw := by
  unfold dg
  rw [Nat.shiftRight_eq_div_pow]

theorem dg_low (sw T a b j : Nat) (ha : a < 2 ^ (sw * T)) (hj : j < T) (hsw : 1 ≤ sw) :
    dg sw (a + b * 2 ^ (sw * T)) j = dg sw a j := by
  rw [dg_eq, dg_eq]
  have h1 : sw ≤ sw * (T - j) := Nat.le_mul_of_pos_right sw (by omega)
  have h2 : sw * (T - j) + sw * j = sw * T := by rw [← Nat.mul_add]; congr 1; omega
  have e : b * 2 ^ (sw * T) = (b * 2 ^ (sw * (T - j) - sw) * 2 ^ sw) * 2 ^ (sw * j) := by
    rw [Nat.mul_assoc, Nat.mul_assoc, ← Nat.pow_add, ← Nat.pow_add]
    congr 2
    omega
  rw [e, Nat.add_mul_div_right _ _ (Nat.two_pow_pos _), Nat.add_mul_mod_self_right]

theorem dg_top (sw T a b : Nat) (ha : a < 2 ^ (sw * T)) :
    dg sw (a + b * 2 ^ (sw * T)) T = b % 2 ^ sw := by
  rw [dg_eq, Nat.add_mul_div_right _ _ (Nat.two_pow_pos _), Nat.div_eq_of_lt ha, Nat.zero_add]

theorem dg_succ' (sw X j : Nat) : dg sw X (j + 1) = dg sw (X / 2 ^ sw) j := dg_succ sw X j

/-! ## the renormalisation of the digits -/

/-- the reduced digit: `p - min p q` -/
def red (p q : Nat) : Nat := p - min p q

theorem renD_succ (sw cnt T P N aP aN tP tN : Nat) (k : Nat → Nat → Nat → Nat → Bool) :
    renD sw (cnt + 1) T P N aP aN tP tN k =
      renD sw cnt (T + 1) (P / 2 ^ sw) (N / 2 ^ sw)
        (aP + red (P % 2 ^ sw) (N % 2 ^ sw) * 2 ^ (sw * T))
        (aN + red (N % 2 ^ sw) (P % 2 ^ sw) * 2 ^ (sw * T))
        (tP + red (P % 2 ^ sw) (N % 2 ^ sw) * ((2654435761 * (T + 1)) % 65536))
        (tN + red (N % 2 ^ sw) (P % 2 ^ sw) * ((2654435761 * (T + 1)) % 65536)) k := by
  have hm : ∀ p q : Nat, Bool.rec (motive := fun _ => Nat) q p (Nat.ble p q) = min p q := by
    intro p q
    cases h : Nat.ble p q
    · have : ¬ p ≤ q := fun h' => by rw [Nat.ble_eq_true_of_le h'] at h; cases h
      show q = min p q
      omega
    · have : p ≤ q := ble_true h
      show p = min p q
      omega
  have r1 : ∀ p q : Nat, p - min p q = red p q := fun p q => rfl
  have r2 : ∀ p q : Nat, q - min p q = red q p := fun p q => by unfold red; rw [Nat.min_comm]
  show forceN (P % 2 ^ sw) (fun p => forceN (N % 2 ^ sw) fun q =>
      forceN (Bool.rec (motive := fun _ => Nat) q p (Nat.ble p q)) fun m =>
      forceN (p - m) fun p' => forceN (q - m) fun q' =>
      forceN ((2654435761 * (T + 1)) % 65536) fun w =>
      forceN (aP + (p' <<< (sw * T))) fun aP' =>
      forceN (aN + (q' <<< (sw * T))) fun aN' =>
      forceN (tP + p' * w) fun tP' => forceN (tN + q' * w) fun tN' =>
      renD sw cnt (T + 1) (P / 2 ^ sw) (N / 2 ^ sw) aP' aN' tP' tN' k) = _
  simp only [forceN_eq, Nat.shiftLeft_eq, hm, r1, r2]

/-- **digits of the renormalised pair**: the accumulators get the reduced digits above the old ones -/
theorem renD_sound (sw : Nat) (hsw : 1 ≤ sw) : ∀ (cnt T P N aP aN tP tN : Nat)
    (k : Nat → Nat → Nat → Nat → Bool), aP < 2 ^ (sw * T) → aN < 2 ^ (sw * T) →
    renD sw cnt T P N aP aN tP tN k = true →
    ∃ aP' aN' tP' tN', k aP' aN' tP' tN' = true ∧ aP' < 2 ^ (sw * (T + cnt)) ∧
      aN' < 2 ^ (sw * (T + cnt)) ∧
      (∀ j, j < T → dg sw aP' j = dg sw aP j ∧ dg sw aN' j = dg sw aN j) ∧
      ∀ j, j < cnt → dg sw aP' (T + j) = red (dg sw P j) (dg sw N j) ∧
        dg sw aN' (T + j) = red (dg sw N j) (dg sw P j) := by
  intro cnt
  induction cnt with
  | zero =>
    intro T P N aP aN tP tN k hP hN h
    exact ⟨aP, aN, tP, tN, h, by rw [Nat.add_zero]; exact hP, by rw [Nat.add_zero]; exact hN,
      fun j _ => ⟨rfl, rfl⟩, fun j hj => absurd hj (Nat.not_lt_zero j)⟩
  | succ cnt ih =>
    intro T P N aP aN tP tN k hP hN h
    rw [renD_succ] at h
    have hr1 : red (P % 2 ^ sw) (N % 2 ^ sw) < 2 ^ sw :=
      lt_of_le_of_lt (Nat.sub_le _ _) (Nat.mod_lt _ (Nat.two_pow_pos sw))
    have hr2 : red (N % 2 ^ sw) (P % 2 ^ sw) < 2 ^ sw :=
      lt_of_le_of_lt (Nat.sub_le _ _) (Nat.mod_lt _ (Nat.two_pow_pos sw))
    have bnd : ∀ a r : Nat, a < 2 ^ (sw * T) → r < 2 ^ sw → a + r * 2 ^ (sw * T) < 2 ^ (sw * (T + 1)) := by
      intro a r ha hr
      calc a + r * 2 ^ (sw * T) < 2 ^ (sw * T) + r * 2 ^ (sw * T) := Nat.add_lt_add_right ha _
        _ = (r + 1) * 2 ^ (sw * T) := by ring
        _ ≤ 2 ^ sw * 2 ^ (sw * T) := Nat.mul_le_mul_right _ hr
        _ = 2 ^ (sw * (T + 1)) := by rw [← Nat.pow_add]; congr 1; ring
    obtain ⟨aP', aN', tP', tN', hk, b1, b2, hlow, hdig⟩ :=
      ih (T + 1) _ _ _ _ _ _ k (bnd _ _ hP hr1) (bnd _ _ hN hr2) h
    refine ⟨aP', aN', tP', tN', hk, by rw [show T + (cnt + 1) = T + 1 + cnt by omega]; exact b1,
      by rw [show T + (cnt + 1) = T + 1 + cnt by omega]; exact b2, fun j hj => ?_, fun j hj => ?_⟩
    · obtain ⟨l1, l2⟩ := hlow j (by omega)
      rw [l1, l2, dg_low sw T aP _ j hP hj hsw, dg_low sw T aN _ j hN hj hsw]
      exact ⟨rfl, rfl⟩
    · cases j with
      | zero =>
        obtain ⟨l1, l2⟩ := hlow T (by omega)
        rw [Nat.add_zero, l1, l2, dg_top sw T aP _ hP, dg_top sw T aN _ hN, Nat.mod_eq_of_lt hr1,
          Nat.mod_eq_of_lt hr2, dg_zero', dg_zero']
        exact ⟨rfl, rfl⟩
      | succ j =>
        obtain ⟨d1, d2⟩ := hdig j (by omega)
        rw [show T + (j + 1) = T + 1 + j by omega, d1, d2, dg_succ', dg_succ']
        exact ⟨rfl, rfl⟩

/-- what the renormalisation of one leaf gives -/
def RenOK (sw n K x x' : Nat) : Prop :=
  ∃ aP aN tP tN, x' = (aP * 2 ^ 64 + tP) + (aN * 2 ^ 64 + tN) * 2 ^ K ∧ aP < 2 ^ (sw * n) ∧
    aN < 2 ^ (sw * n) ∧ tP < 2 ^ 63 ∧ tN < 2 ^ 63 ∧
    ∀ j, j < n → dg sw aP j = red (dg sw ((x % 2 ^ K) / 2 ^ 64) j) (dg sw ((x / 2 ^ K) / 2 ^ 64) j) ∧
      dg sw aN j = red (dg sw ((x / 2 ^ K) / 2 ^ 64) j) (dg sw ((x % 2 ^ K) / 2 ^ 64) j)

theorem renLeaf_sound (sw n K : Nat) (hsw : 1 ≤ sw) (x : Nat) (k : Nat → Bool)
    (h : renLeaf sw n K x k = true) : ∃ x', k x' = true ∧ RenOK sw n K x x' := by
  unfold renLeaf at h
  cases hx : Nat.beq x 0
  case true =>
    rw [hx] at h
    have e : x = 0 := beq_true hx
    subst e
    refine ⟨0, h, 0, 0, 0, 0, by ring, Nat.two_pow_pos _, Nat.two_pow_pos _, by norm_num, by norm_num,
      fun j _ => ?_⟩
    simp [red, dg_zero_left]
  rw [hx] at h
  have e0 : Nat.shiftRight (Nat.mod x (Nat.pow 2 K)) 64 = (x % 2 ^ K) / 2 ^ 64 := by
    show (x % 2 ^ K) >>> 64 = _; rw [Nat.shiftRight_eq_div_pow]
  have e1 : Nat.shiftRight (Nat.shiftRight x K) 64 = (x / 2 ^ K) / 2 ^ 64 := by
    show (x >>> K) >>> 64 = _; rw [Nat.shiftRight_eq_div_pow, Nat.shiftRight_eq_div_pow]
  replace h : renD sw n 0 (Nat.shiftRight (Nat.mod x (Nat.pow 2 K)) 64)
      (Nat.shiftRight (Nat.shiftRight x K) 64) 0 0 0 0 (fun aP aN tP tN =>
        guard (Nat.ble (Nat.succ tP) 9223372036854775808)
          (guard (Nat.ble (Nat.succ tN) 9223372036854775808)
            (forceN (Nat.add (Nat.add (Nat.shiftLeft aP 64) tP)
              (Nat.shiftLeft (Nat.add (Nat.shiftLeft aN 64) tN) K)) k))) = true := h
  rw [e0, e1] at h
  obtain ⟨aP, aN, tP, tN, hk, b1, b2, _, hdig⟩ := renD_sound sw hsw n 0 _ _ 0 0 0 0 _
    (by rw [Nat.mul_zero, Nat.pow_zero]; exact Nat.one_pos)
    (by rw [Nat.mul_zero, Nat.pow_zero]; exact Nat.one_pos) h
  obtain ⟨g1, hk⟩ := guard_true hk
  obtain ⟨g2, hk⟩ := guard_true hk
  rw [forceN_eq] at hk
  have e63 : (2 : Nat) ^ 63 = 9223372036854775808 := by norm_num
  refine ⟨_, hk, aP, aN, tP, tN, ?_, by rw [Nat.zero_add] at b1; exact b1,
    by rw [Nat.zero_add] at b2; exact b2, by have := ble_true g1; omega, by have := ble_true g2; omega,
    fun j hj => ?_⟩
  · show (aP <<< 64 + tP) + ((aN <<< 64 + tN) <<< K) = _
    simp only [Nat.shiftLeft_eq]
  · obtain ⟨d1, d2⟩ := hdig j hj
    rw [Nat.zero_add] at d1 d2
    exact ⟨d1, d2⟩

/-! ## tries of the same shape -/

/-- two tries of the same shape with related leaves -/
def TRel (R : Nat → Nat → Prop) : Trie → Trie → Prop
  | .leaf x, .leaf x' => R x x'
  | .node l r, .node l' r' => TRel R l l' ∧ TRel R r r'
  | _, _ => False

theorem TRel.wf {R : Nat → Nat → Prop} : ∀ (d : Nat) (t t' : Trie), TRel R t t' → t.wf d → t'.wf d := by
  intro d
  induction d with
  | zero =>
    intro t t' h hw
    cases t with
    | leaf x => cases t' with
      | leaf x' => exact trivial
      | node _ _ => exact absurd h id
    | node _ _ => exact absurd hw id
  | succ d ih =>
    intro t t' h hw
    cases t with
    | leaf x => exact absurd hw id
    | node l r => cases t' with
      | leaf x' => exact absurd h id
      | node l' r' => exact ⟨ih l l' h.1 hw.1, ih r r' h.2 hw.2⟩

theorem TRel.get {R : Nat → Nat → Prop} : ∀ (t t' : Trie), TRel R t t' → ∀ key, R (t.get key) (t'.get key) := by
  intro t
  induction t with
  | leaf x =>
    intro t' h key
    cases t' with
    | leaf x' => exact h
    | node _ _ => exact absurd h id
  | node l r il ir =>
    intro t' h key
    cases t' with
    | leaf x' => exact absurd h id
    | node l' r' =>
      show R (if key % 2 = 0 then l.get (key / 2) else r.get (key / 2))
        (if key % 2 = 0 then l'.get (key / 2) else r'.get (key / 2))
      split
      · exact il l' h.1 _
      · exact ir r' h.2 _

theorem renT_sound (sw n K : Nat) (hsw : 1 ≤ sw) : ∀ (t : Trie) (k : Trie → Bool),
    renT sw n K t k = true → ∃ t', k t' = true ∧ TRel (RenOK sw n K) t t' := by
  intro t
  induction t with
  | leaf x =>
    intro k h
    obtain ⟨x', hk, hr⟩ := renLeaf_sound sw n K hsw x _ h
    exact ⟨.leaf x', hk, hr⟩
  | node l r il ir =>
    intro k h
    obtain ⟨l', h1, hl⟩ := il _ h
    obtain ⟨r', h2, hr⟩ := ir _ h1
    exact ⟨.node l' r', h2, hl, hr⟩

/-! ## renormalised states keep the contents -/

/-- two abstract states with the same contents (digits `T < n`) -/
def CEq (sw n : Nat) (u : Nat → Nat) (a b : SSt) : Prop :=
  ∀ r T, T < n → gcont sw u a r T = gcont sw u b r T

theorem cm_of_ceq {ρ : Type} [Fintype ρ] [DecidableEq ρ] (sw n : Nat) (u : Nat → Nat) (emb : ρ → Nat)
    (a b : SSt) (h : CEq sw n u a b) : Cm sw n u emb a = Cm sw n u emb b := by
  ext i T
  exact h (emb i) T.val T.isLt

theorem red_sub (p q : Nat) : ((red p q : Nat) : ℚ) - ((red q p : Nat) : ℚ) = (p : ℚ) - (q : ℚ) := by
  unfold red
  rcases le_total p q with h | h
  · rw [Nat.min_eq_left h, Nat.min_eq_right h, Nat.sub_self]
    push_cast [Nat.cast_sub h]
    ring
  · rw [Nat.min_eq_right h, Nat.min_eq_left h, Nat.sub_self]
    push_cast [Nat.cast_sub h]
    ring

/-- **the renormalisation of a state**: well formed, small digits, same contents -/
theorem renT_state (d sw n : Nat) (u : Nat → Nat) (hsw : 1 ≤ sw) (tr : Trie) (hI : GOk d sw n tr)
    (k : Trie → Bool) (h : renT sw n (64 + sw * n) tr k = true) :
    ∃ tr', k tr' = true ∧ GOk d sw n tr' ∧
      CEq sw n u (absG d (64 + sw * n) tr) (absG d (64 + sw * n) tr') := by
  obtain ⟨tr', hk, hrel⟩ := renT_sound sw n (64 + sw * n) hsw tr k h
  have hwf' := TRel.wf d tr tr' hrel hI.wf
  -- the leaf facts
  have leaf : ∀ r, r < 2 ^ d → RenOK sw n (64 + sw * n) (absS (2 ^ d) tr r) (absS (2 ^ d) tr' r) := by
    intro r hr
    rw [absS_apply d tr r hr, absS_apply d tr' r hr]
    exact TRel.get tr tr' hrel r
  have K2 : ∀ aP tP : Nat, aP < 2 ^ (sw * n) → tP < 2 ^ 63 →
      aP * 2 ^ 64 + tP < 2 ^ (64 + sw * n) := by
    intro aP tP h1 h2
    have h3 : tP < 2 ^ 64 := lt_trans h2 (by norm_num)
    calc aP * 2 ^ 64 + tP < aP * 2 ^ 64 + 2 ^ 64 := Nat.add_lt_add_left h3 _
      _ = (aP + 1) * 2 ^ 64 := by ring
      _ ≤ 2 ^ (sw * n) * 2 ^ 64 := Nat.mul_le_mul_right _ h1
      _ = 2 ^ (64 + sw * n) := by rw [← Nat.pow_add, Nat.add_comm]
  -- decompositions of a renormalised leaf
  have halves : ∀ aP aN tP tN : Nat, aP < 2 ^ (sw * n) → tP < 2 ^ 63 →
      ((aP * 2 ^ 64 + tP) + (aN * 2 ^ 64 + tN) * 2 ^ (64 + sw * n)) % 2 ^ (64 + sw * n) = aP * 2 ^ 64 + tP ∧
      ((aP * 2 ^ 64 + tP) + (aN * 2 ^ 64 + tN) * 2 ^ (64 + sw * n)) / 2 ^ (64 + sw * n) = aN * 2 ^ 64 + tN := by
    intro aP aN tP tN h1 h2
    have hlt := K2 aP tP h1 h2
    refine ⟨?_, ?_⟩
    · rw [Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt hlt]
    · rw [Nat.add_mul_div_right _ _ (Nat.two_pow_pos _), Nat.div_eq_of_lt hlt, Nat.zero_add]
  have untag : ∀ a t : Nat, t < 2 ^ 63 → (a * 2 ^ 64 + t) / 2 ^ 64 = a ∧ (a * 2 ^ 64 + t) % 2 ^ 64 = t := by
    intro a t ht
    have : t < 2 ^ 64 := lt_trans ht (by norm_num)
    refine ⟨?_, ?_⟩
    · rw [Nat.add_comm, Nat.add_mul_div_right _ _ (by norm_num), Nat.div_eq_of_lt this, Nat.zero_add]
    · rw [Nat.add_comm, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt this]
  refine ⟨tr', hk, ⟨hwf', fun r => ?_⟩, fun r T hT => ?_⟩
  · -- small digits and tags
    by_cases hr : r < 2 ^ d
    · obtain ⟨aP, aN, tP, tN, ex, b1, b2, t1, t2, hdig⟩ := leaf r hr
      obtain ⟨h1, h2⟩ := halves aP aN tP tN b1 t1
      obtain ⟨u1, u2⟩ := untag aP tP t1
      obtain ⟨v1, v2⟩ := untag aN tN t2
      obtain ⟨o1, o2⟩ := hI.ok r
      rw [ex, Nat.shiftRight_eq_div_pow, h1, h2]
      refine ⟨⟨fun T hT => ?_, by rw [u2]; exact t1⟩, ⟨fun T hT => ?_, by rw [v2]; exact t2⟩⟩
      · rw [Nat.shiftRight_eq_div_pow, u1, (hdig T hT).1]
        have := o1.1 T hT
        rw [Nat.shiftRight_eq_div_pow] at this
        exact lt_of_le_of_lt (Nat.sub_le _ _) this
      · rw [Nat.shiftRight_eq_div_pow, v1, (hdig T hT).2]
        have := o2.1 T hT
        rw [Nat.shiftRight_eq_div_pow, Nat.shiftRight_eq_div_pow] at this
        exact lt_of_le_of_lt (Nat.sub_le _ _) this
    · have e : absS (2 ^ d) tr' r = 0 := by unfold absS; rw [if_neg hr]
      rw [e, Nat.zero_mod, Nat.zero_shiftRight]
      exact ⟨ok_zero sw n, ok_zero sw n⟩
  · -- the contents
    unfold gcont
    congr 1
    show ((dg sw ((absS (2 ^ d) tr r % 2 ^ (64 + sw * n)) >>> 64) T : ℚ)
        - (dg sw ((absS (2 ^ d) tr r >>> (64 + sw * n)) >>> 64) T : ℚ))
      = ((dg sw ((absS (2 ^ d) tr' r % 2 ^ (64 + sw * n)) >>> 64) T : ℚ)
        - (dg sw ((absS (2 ^ d) tr' r >>> (64 + sw * n)) >>> 64) T : ℚ))
    by_cases hr : r < 2 ^ d
    · obtain ⟨aP, aN, tP, tN, ex, b1, b2, t1, t2, hdig⟩ := leaf r hr
      obtain ⟨h1, h2⟩ := halves aP aN tP tN b1 t1
      obtain ⟨u1, _⟩ := untag aP tP t1
      obtain ⟨v1, _⟩ := untag aN tN t2
      have e1 : (absS (2 ^ d) tr' r % 2 ^ (64 + sw * n)) >>> 64 = aP := by
        rw [ex, h1, Nat.shiftRight_eq_div_pow, u1]
      have e2 : (absS (2 ^ d) tr' r >>> (64 + sw * n)) >>> 64 = aN := by
        rw [ex]
        simp only [Nat.shiftRight_eq_div_pow]
        rw [h2, v1]
      rw [e1, e2, (hdig T hT).1, (hdig T hT).2, red_sub]
      all_goals simp only [Nat.shiftRight_eq_div_pow]
    · have e : ∀ t : Trie, absS (2 ^ d) t r = 0 := fun t => by unfold absS; rw [if_neg hr]
      rw [e tr, e tr']

/-! ## items with renormalisation -/

section
variable (c : Raw) (p : SPar) (n : Nat)

/-- a run of items, each followed by a content-preserving jump -/
def ItemsRunR : List Item → SSt → SSt → Prop
  | [], a, b => b = a
  | it :: l, a, b => ∃ m m', ItemRun c p n it a m ∧ CEq p.sw n (U c p) m m' ∧ ItemsRunR l m' b

theorem ItemsRunR_split (l1 l2 : List Item) : ∀ (a b : SSt),
    ItemsRunR c p n (l1 ++ l2) a b → ∃ m, ItemsRunR c p n l1 a m ∧ ItemsRunR c p n l2 m b := by
  induction l1 with
  | nil => intro a b h; exact ⟨a, rfl, h⟩
  | cons x l1 ih =>
    intro a b h
    obtain ⟨m1, m1', hs, hc, hr⟩ := h
    obtain ⟨m, r1, r2⟩ := ih m1' b hr
    exact ⟨m, ⟨m1, m1', hs, hc, r1⟩, r2⟩

end

section
variable (c : Raw) (p : SPar) (lo n : Nat) (hp : PGood c p lo n)
include hp

theorem gItemsR_sound (items : List Item) : ∀ (tr : Trie) (k : Trie → Bool), GOk p.d p.sw n tr →
    gItemsR c p n (2 * c.v) (2 * c.v + c.R) (maskW p.sw n) (64 + p.sw * n) (2^(64 + p.sw * n))
      c.ret.length items tr k = true →
    ∃ tr', GOk p.d p.sw n tr' ∧ k tr' = true ∧
      ItemsRunR c p n items (absG p.d (64 + p.sw * n) tr) (absG p.d (64 + p.sw * n) tr') := by
  induction items with
  | nil => intro tr k hI h; exact ⟨tr, hI, h, rfl⟩
  | cons it items ih =>
    intro tr k hI h
    obtain ⟨tr1, hI1, hk1, r1⟩ := gItem_sound c p lo n hp it tr _ hI h
    obtain ⟨tr2, hk2, hI2, hc⟩ := renT_state p.d p.sw n (U c p) hp.hsw tr1 hI1 _ hk1
    obtain ⟨tr3, hI3, hk3, r3⟩ := ih tr2 k hI2 hk2
    exact ⟨tr3, hI3, hk3, _, _, r1, hc, r3⟩

end

/-! ## the content matrix of a renormalised run of `sourceProg` -/

section
variable {c : Raw} (hv : 0 < c.v) {p : SPar} {lo n : Nat} (hp : PGood c p lo n)
include hv hp

theorem okZ_emb : ∀ t s, okZ c t s = true → emb c (unemb c hv t) = t ∧ emb c (unemb c hv s) = s :=
  fun t s ho => ⟨emb_unemb hv t (okZ_spec ho).1, emb_unemb hv s (okZ_spec ho).2.1⟩

theorem runR_chunks (cs : List (List Gate)) : ∀ (a b : SSt),
    ItemsRunR c p n (cs.map Item.cB) a b →
    Cm p.sw n (U c p) (emb c) b
      = matP (unemb c hv) (mic (cs.flatten.flatMap Gate.adds)) * Cm p.sw n (U c p) (emb c) a := by
  induction cs with
  | nil =>
    intro a b h
    have e : b = a := h
    rw [e]
    show _ = 1 * _
    rw [Matrix.one_mul]
  | cons gs cs ih =>
    intro a b h
    obtain ⟨m, m', hr, hc, hrest⟩ := h
    have h1 := GRun_Cm p.sw n (U c p) (okZ c) (fun _ => true) (emb c) (unemb c hv) (unemb_emb hv)
      (okZ_emb hv hp) (gs.flatMap Gate.adds) a m hr
    rw [micF_true] at h1
    rw [ih m' b hrest, ← cm_of_ceq p.sw n (U c p) (emb c) m m' hc, h1, ← Matrix.mul_assoc,
      List.flatten_cons, List.flatMap_append]
    unfold mic
    rw [List.map_append, matP_append]

/-- **a renormalised run of `sourceProg c` multiplies the content matrix by `Mt`** -/
theorem runR_cm (a b : SSt) (h : ItemsRunR c p n (sourceProg c) a b) :
    Cm p.sw n (U c p) (emb c) b = Mt c hv * Cm p.sw n (U c p) (emb c) a := by
  obtain ⟨m1, r1, r2⟩ := ItemsRunR_split c p n _ _ a b h
  obtain ⟨m2, m2', ⟨rs, hsh⟩, hc, r3⟩ := r2
  have hA := runR_chunks hv hp c.A a m1 r1
  have hS := cm_scat p lo n hp m1 m2 rs hsh
  have hB := runR_chunks hv hp c.B m2' b r3
  rw [hB, ← cm_of_ceq p.sw n (U c p) (emb c) m2 m2' hc, hS, hA]
  unfold Mt MA MB addsA addsB Raw.gatesA Raw.gatesB
  rw [Matrix.mul_assoc, Matrix.mul_assoc]

end

/-! ## x columns -/

/-- **An accepted renormalising x-column replay** for the sources `lo .. lo+n-1`. -/
def XRunR (c : Raw) (lo n : Nat) : Prop :=
  ∃ (p : SPar) (a0 b : SSt), PGood c p lo n ∧ InitSt p n lo p.ux a0 ∧
    ItemsRunR c p n (sourceProg c) a0 b ∧
    SmallSt p.sw n b ∧ FinSt c p lo n 0 p.ux b ∧ FinSt c p lo n c.v p.uy b

theorem xCheckR_sound {c : Raw} {p : SPar} {lo n : Nat} (h : xCheckR c p lo n = true) :
    XRunR c lo n := by
  unfold xCheckR at h
  obtain ⟨hp, h1⟩ := pgood_of (gPre_sound c p lo n _ h)
  rw [forceN_eq] at h1
  have h2 : Tag16.init p.sw p.ux lo n 0 (Trie.mk p.d) (fun tr0 =>
      gItemsR c p n (2 * c.v) (2 * c.v + c.R) (maskW p.sw n) (64 + p.sw * n) (2 ^ (64 + p.sw * n))
        c.ret.length (sourceProg c) tr0 fun tr3 =>
          guard (gFin p.sw (64 + p.sw * n) (2 ^ (64 + p.sw * n)) p.ux 0 lo (lo + n) tr3 c.v 0)
            (gFin p.sw (64 + p.sw * n) (2 ^ (64 + p.sw * n)) p.uy c.v lo (lo + n) tr3 c.v 0))
      = true := h1
  have hle : lo + 0 + n ≤ 2 ^ p.d := by have := hp.hd; have := hp.hn; omega
  obtain ⟨t0, hwf, hk, hval⟩ := Tag16.init_sound p.d p.sw p.ux lo n 0 (Trie.mk p.d) _
    (Trie.wf_mk p.d) hle h2
  obtain ⟨hI0, hinit⟩ := Tag16.init_ok p.d p.sw n p.ux lo hp.hsw hp.hxs hp.hx2 t0 hwf hval
  obtain ⟨tr3, hI3, hk3, hr⟩ := gItemsR_sound c p lo n hp (sourceProg c) t0 _ hI0 hk
  obtain ⟨f1, f2⟩ := guard_true hk3
  exact ⟨p, _, _, hp, hinit, hr, hI3.small,
    fin_of c p lo n hp 0 p.ux tr3 hI3 f1, fin_of c p lo n hp c.v p.uy tr3 hI3 f2⟩

/-- **the columns of the x sources of a batch** (renormalising replay) -/
theorem XRunR.xcol {c : Raw} (hv : 0 < c.v) {lo n : Nat} (h : XRunR c lo n)
    (t : Fin c.v) (hlo : lo ≤ t.val) (hhi : t.val < lo + n) :
    (∀ t' : Fin c.v, Mt c hv (lX t') (lX t) = if t' = t then 1 else 0) ∧
      ∀ S : Fin c.v, Mt c hv (lY S) (lX t) = if S = t then 1 else 0 := by
  obtain ⟨p, a0, a3, hp, hi, hr, hsm, fx, fy⟩ := h
  have hCm := runR_cm hv hp a0 a3 hr
  have hus : p.ux < 2^p.sw :=
    lt_of_lt_of_le hp.hxs (Nat.pow_le_pow_right (by norm_num) (by omega))
  have hT : t.val - lo < n := by omega
  have hC0 : ∀ j : Rl c, Cm p.sw n (U c p) (emb c) a0 j ⟨t.val - lo, hT⟩
      = if j = lX t then 1 else 0 := by
    intro j
    have h1 := cont_start p.sw n (U c p) a0 lo p.ux hp.hx hus hi (emb c j) (t.val - lo) hT
      (fun hr => U_x c p _ (by have := hp.hn; omega))
    show gcont p.sw (U c p) a0 (emb c j) (t.val - lo) = _
    rw [h1]
    have e : lo + (t.val - lo) = t.val := by omega
    by_cases hj : j = lX t
    · rw [if_pos hj, hj, if_pos (by rw [e]; rfl)]
    · have hne : ¬ emb c j = lo + (t.val - lo) := by
        intro he
        apply hj
        rw [← unemb_emb hv j, he, e, unemb_x hv t.val t.isLt]
      rw [if_neg hj, if_neg hne]
  have key : ∀ i : Rl c, Mt c hv i (lX t) = Cm p.sw n (U c p) (emb c) a3 i ⟨t.val - lo, hT⟩ := by
    intro i
    have e1 := mul_unitCol (Mt c hv) (Cm p.sw n (U c p) (emb c) a0) (lX t) ⟨t.val - lo, hT⟩ hC0 i
    rw [← e1, hCm]
  refine ⟨fun t' => ?_, fun S => ?_⟩
  · rw [key]
    have hf := fx t'.val t'.isLt
    rw [Nat.zero_add] at hf
    have h1 := cont_end p.sw n (U c p) a3 t'.val p.ux (t'.val - lo) (lo ≤ t'.val ∧ t'.val < lo + n)
      hp.hsw hp.hx hp.hxs (U_x c p _ t'.isLt) (hsm t'.val).2 hf (t.val - lo) hT
    show gcont p.sw (U c p) a3 t'.val (t.val - lo) = _
    rw [h1]
    by_cases e : t' = t
    · rw [if_pos e, if_pos ⟨by rw [e]; exact ⟨hlo, hhi⟩, by rw [e]⟩]
    · have hne : ¬ ((lo ≤ t'.val ∧ t'.val < lo + n) ∧ t.val - lo = t'.val - lo) := by
        intro hh
        exact e (Fin.ext (by omega))
      rw [if_neg e, if_neg hne]
  · rw [key]
    have hf := fy S.val S.isLt
    have h1 := cont_end p.sw n (U c p) a3 (c.v + S.val) p.uy (S.val - lo)
      (lo ≤ S.val ∧ S.val < lo + n) hp.hsw hp.hy hp.hys
      (U_y c p _ (by omega) (by have := S.isLt; omega)) (hsm (c.v + S.val)).2 hf (t.val - lo) hT
    show gcont p.sw (U c p) a3 (c.v + S.val) (t.val - lo) = _
    rw [h1]
    by_cases e : S = t
    · rw [if_pos e, if_pos ⟨by rw [e]; exact ⟨hlo, hhi⟩, by rw [e]⟩]
    · have hne : ¬ ((lo ≤ S.val ∧ S.val < lo + n) ∧ t.val - lo = S.val - lo) := by
        intro hh
        exact e (Fin.ext (by omega))
      rw [if_neg e, if_neg hne]

/-! ## slot columns -/

/-- **An accepted renormalising slot-column replay** for the slot registers `gl`. -/
def SRunR (c : Raw) (gl : List Nat) (ey : Bool) : Prop :=
  ∃ (p : SPar) (a0 b : SSt), PGood c p 0 gl.length ∧
    (∀ r ∈ gl, 2 * c.v ≤ r ∧ r < 2 * c.v + c.R) ∧ gl.Nodup ∧ p.us < 2^(p.sw - 1) ∧
    (∀ r, a0.N r = 0 ∧ a0.P r = if r ∈ gl then p.us * 2^(p.sw * gl.idxOf r) else 0) ∧
    ItemsRunR c p gl.length (sourceProg c) a0 b ∧
    (∀ S, S < c.v → b.P S = b.N S) ∧
    (ey = true → ∀ S, S < c.v → b.P (c.v + S) = b.N (c.v + S))

theorem sCheckR_sound {c : Raw} {p : SPar} {gl : List Nat} {ey : Bool}
    (h : sCheckR c p gl ey = true) : SRunR c gl ey := by
  unfold sCheckR at h
  obtain ⟨hp, h1⟩ := pgood_of (gPre_sound c p 0 gl.length _ h)
  obtain ⟨hinc, h2⟩ := guard_true h1
  obtain ⟨hus, h3⟩ := guard_true h2
  obtain ⟨hus2, h4⟩ := guard_true h3
  rw [forceN_eq] at h4
  have h5 : Tag16.initL p.sw p.us gl 0 (Trie.mk p.d) (fun tr0 =>
      gItemsR c p gl.length (2 * c.v) (2 * c.v + c.R) (maskW p.sw gl.length) (64 + p.sw * gl.length)
        (2 ^ (64 + p.sw * gl.length)) c.ret.length (sourceProg c) tr0 fun tr3 =>
          guard (gFin p.sw (64 + p.sw * gl.length) (2 ^ (64 + p.sw * gl.length)) p.ux 0 0 0 tr3 c.v 0)
            (Bool.rec (motive := fun _ => Bool) true
              (gFin p.sw (64 + p.sw * gl.length) (2 ^ (64 + p.sw * gl.length)) p.uy c.v 0 0 tr3 c.v 0)
              ey)) = true := h4
  have hinc' : GS.incK (2 * c.v + c.R) gl (2 * c.v) = true := by
    rw [← Tag16.incK_eq]; exact hinc
  obtain ⟨hgl, hnd⟩ := incK_sound _ gl _ hinc'
  have hlt : ∀ r ∈ gl, r < 2 ^ p.d := fun r hr => by have := (hgl r hr).2; have := hp.hd; omega
  obtain ⟨t0, hwf, hk, hval⟩ := Tag16.initL_sound p.d p.sw p.us gl 0 (Trie.mk p.d) _
    (Trie.wf_mk p.d) hlt hnd h5
  have husw : p.us < 2 ^ (p.sw - 1) := by
    have := ble_true hus
    have e : Nat.pow 2 (Nat.sub p.sw 1) = 2 ^ (p.sw - 1) := rfl
    omega
  have hu2 := ble_true hus2
  obtain ⟨hI0, hinit⟩ := Tag16.init_okL p.d p.sw p.us gl hp.hsw husw (by omega) t0 hwf hval
  obtain ⟨tr3, hI3, hk3, hr⟩ := gItemsR_sound c p 0 gl.length hp (sourceProg c) t0 _ hI0 hk
  obtain ⟨f1, f2⟩ := guard_true hk3
  refine ⟨p, _, _, hp, hgl, hnd, husw, hinit, hr, fun S hS => ?_, fun hey S hS => ?_⟩
  · have h6 := gFin_sound p.d p.sw (64 + p.sw * gl.length) p.ux 0 0 0 tr3 hI3.wf c.v 0 f1 S hS
    have e1 : (0:Nat) + (0 + S) = S := by omega
    have e2 : ¬ (0 ≤ 0 + S ∧ 0 + S < 0) := by omega
    rw [e1, if_neg e2, Nat.add_zero] at h6
    exact h6
  · have f2' : gFin p.sw (64 + p.sw * gl.length) (2 ^ (64 + p.sw * gl.length)) p.uy c.v 0 0 tr3
        c.v 0 = true := by
      rw [hey] at f2; exact f2
    have h6 := gFin_sound p.d p.sw (64 + p.sw * gl.length) p.uy c.v 0 0 tr3 hI3.wf c.v 0 f2' S hS
    have e1 : (0:Nat) + S = S := by omega
    have e2 : ¬ (0 ≤ 0 + S ∧ 0 + S < 0) := by omega
    rw [if_neg e2, e1, Nat.add_zero] at h6
    exact h6

theorem SRunR.key {c : Raw} (hv : 0 < c.v) {gl : List Nat} {ey : Bool} (h : SRunR c gl ey)
    (q : Fin c.R) (hq : 2 * c.v + q.val ∈ gl) :
    ∃ (p : SPar) (b : SSt), (∀ S, S < c.v → b.P S = b.N S) ∧
      (ey = true → ∀ S, S < c.v → b.P (c.v + S) = b.N (c.v + S)) ∧
      ∀ i : Rl c, Mt c hv i (lS q) = gcont p.sw (U c p) b (emb c i) (gl.idxOf (2 * c.v + q.val)) := by
  obtain ⟨p, a0, b, hp, hgl, hnd, husw, hi, hr, hfx, hfy⟩ := h
  have hCm := runR_cm hv hp a0 b hr
  have hus : p.us < 2^p.sw := lt_of_lt_of_le husw (Nat.pow_le_pow_right (by norm_num) (by omega))
  have hT : gl.idxOf (2 * c.v + q.val) < gl.length := List.idxOf_lt_length_of_mem hq
  have u0 : (p.us : ℚ) ≠ 0 := by have := hp.hs; positivity
  have hC0 : ∀ j : Rl c, Cm p.sw gl.length (U c p) (emb c) a0 j ⟨gl.idxOf (2 * c.v + q.val), hT⟩
      = if j = lS q then 1 else 0 := by
    intro j
    show gcont p.sw (U c p) a0 (emb c j) (gl.idxOf (2 * c.v + q.val)) = _
    unfold gcont
    rw [(hi (emb c j)).1, (hi (emb c j)).2, dg_zero_left]
    by_cases hj : emb c j ∈ gl
    · rw [if_pos hj, dg_mul_pow p.sw p.us hus, U_s c p _ (hgl _ hj).1]
      by_cases e : j = lS q
      · have e' : emb c j = 2 * c.v + q.val := by rw [e]; rfl
        rw [if_pos (by rw [e']), if_pos e]
        field_simp
        simp
      · have e' : ¬ gl.idxOf (2 * c.v + q.val) = gl.idxOf (emb c j) := by
          intro he
          apply e
          have := (List.idxOf_inj hq).mp he
          rw [← unemb_emb hv j, ← this]
          exact unemb_emb hv (lS q)
        rw [if_neg e', if_neg e]
        simp
    · have e : ¬ j = lS q := fun e => hj (by rw [e]; exact hq)
      rw [if_neg hj, if_neg e, dg_zero_left]
      simp
  refine ⟨p, b, hfx, hfy, fun i => ?_⟩
  have key : Mt c hv i (lS q)
      = Cm p.sw gl.length (U c p) (emb c) b i ⟨gl.idxOf (2 * c.v + q.val), hT⟩ := by
    have e1 := mul_unitCol (Mt c hv) (Cm p.sw gl.length (U c p) (emb c) a0) (lS q) _ hC0 i
    rw [← e1, hCm]
  exact key

theorem SRunR.xrow {c : Raw} (hv : 0 < c.v) {gl : List Nat} {ey : Bool} (h : SRunR c gl ey)
    (q : Fin c.R) (hq : 2 * c.v + q.val ∈ gl) (t : Fin c.v) : Mt c hv (lX t) (lS q) = 0 := by
  obtain ⟨p, b, hfx, _, key⟩ := h.key hv q hq
  rw [key]
  show gcont p.sw (U c p) b t.val (gl.idxOf (2 * c.v + q.val)) = 0
  unfold gcont
  rw [hfx t.val t.isLt]
  simp

theorem SRunR.yrow {c : Raw} (hv : 0 < c.v) {gl : List Nat} (h : SRunR c gl true)
    (q : Fin c.R) (hq : 2 * c.v + q.val ∈ gl) (S : Fin c.v) : Mt c hv (lY S) (lS q) = 0 := by
  obtain ⟨p, b, _, hfy, key⟩ := h.key hv q hq
  rw [key]
  show gcont p.sw (U c p) b (c.v + S.val) (gl.idxOf (2 * c.v + q.val)) = 0
  unfold gcont
  rw [hfy rfl S.val S.isLt]
  simp

/-! ## kinds -/

theorem kindsK_sound {c : Raw} (h : kindsK c = true) :
    ∀ x ∈ addsA c ++ addsB c, x.1 < 2 * c.v + c.R ∧ x.2.1 < 2 * c.v + c.R ∧ x.1 ≠ x.2.1 ∧
      (c.v ≤ x.2.1 → x.2.1 < 2 * c.v → c.v ≤ x.1 ∧ x.1 < 2 * c.v) := by
  intro x hx
  have h1 : (okZK c.v (2 * c.v) (2 * c.v + c.R) x.1 x.2.1 && !(Nat.beq x.1 x.2.1)) = true :=
    List.all_eq_true.mp h x hx
  obtain ⟨h2, h3⟩ := Bool.and_eq_true_iff.mp h1
  have h4 := okZ_spec h2
  have h5 : x.1 ≠ x.2.1 := by
    intro e
    rw [e, Nat.beq_refl] at h3
    exact absurd h3 (by decide)
  exact ⟨h4.1, h4.2.1, h5, by omega⟩

/-! ## the scalar half -/

/-- **The scalar half from renormalising replays.** -/
structure SourceOKR (c : Raw) : Prop where
  hv : 0 < c.v
  hk : kindsK c = true
  hs : ∀ t, t < c.v → ∃ lo n, lo ≤ t ∧ t < lo + n ∧ XRunR c lo n
  hyc : ∀ t, t < c.v → ∃ lo n, lo ≤ t ∧ t < lo + n ∧ GS.YRun c lo n
  hA_noY : ∀ x ∈ addsA c, x.2.1 < c.v ∨ 2 * c.v ≤ x.2.1
  hsl : ∀ q, q < c.R → ∃ gl ey, 2 * c.v + q ∈ gl ∧ SRunR c gl ey

namespace SourceOKR
variable {c : Raw} (K : SourceOKR c)
include K

theorem addA : ∀ x ∈ addsA c, x.1 < 2 * c.v + c.R ∧ x.2.1 < 2 * c.v + c.R ∧ x.1 ≠ x.2.1 ∧
    (c.v ≤ x.2.1 → x.2.1 < 2 * c.v → c.v ≤ x.1 ∧ x.1 < 2 * c.v) :=
  fun x hx => kindsK_sound K.hk x (List.mem_append_left _ hx)

theorem addB : ∀ x ∈ addsB c, x.1 < 2 * c.v + c.R ∧ x.2.1 < 2 * c.v + c.R ∧ x.1 ≠ x.2.1 ∧
    (c.v ≤ x.2.1 → x.2.1 < 2 * c.v → c.v ≤ x.1 ∧ x.1 < 2 * c.v) :=
  fun x hx => kindsK_sound K.hk x (List.mem_append_right _ hx)

theorem un_ne (t s : Nat) (ht : t < 2 * c.v + c.R) (hs : s < 2 * c.v + c.R) (hne : t ≠ s) :
    unemb c K.hv t ≠ unemb c K.hv s := fun e => hne (by
  rw [← emb_unemb K.hv t ht, e, emb_unemb K.hv s hs])

theorem hAi : MAi c K.hv * MA c K.hv = 1 := by
  apply mul_eq_one_comm.mp
  exact matP_inv _ _ (gatesDistinct_of _ _ (fun t s cf hm => by
    obtain ⟨x, hx, rfl, rfl⟩ := mem_mic _ _ _ _ hm
    obtain ⟨h1, h2, h3, _⟩ := K.addA x hx
    exact K.un_ne _ _ h1 h2 h3))

theorem hBi : MBi c K.hv * MB c K.hv = 1 := by
  apply mul_eq_one_comm.mp
  exact matP_inv _ _ (gatesDistinct_of _ _ (fun t s cf hm => by
    obtain ⟨x, hx, rfl, rfl⟩ := mem_mic _ _ _ _ hm
    obtain ⟨h1, h2, h3, _⟩ := K.addB x hx
    exact K.un_ne _ _ h1 h2 h3))

theorem hid (S t : Fin c.v) :
    (MB c K.hv * scatM (Jrm c * Ccm c) * MA c K.hv) (lY S) (lX t) = if S = t then 1 else 0 := by
  obtain ⟨lo, n, hlo, hhi, h⟩ := K.hs t.val t.isLt
  exact (h.xcol K.hv t hlo hhi).2 S

theorem mb_ycol (i : Rl c) (t : Fin c.v) : MB c K.hv i (lY t) = if i = lY t then 1 else 0 := by
  have hf := ycol_filter (unemb c K.hv) (selY c.v (2 * c.v)) (addsB c)
    (fun x hx hsel τ hτ => by
      obtain ⟨_, h2, _⟩ := K.addB x hx
      have := selY_spec.mpr (unemb_of_y K.hv x.2.1 h2 τ hτ)
      rw [hsel] at this
      exact Bool.false_ne_true this)
    (fun x hx hsel => by
      obtain ⟨_, _, _, h5⟩ := K.addB x hx
      obtain ⟨g1, g2⟩ := selY_spec.mp hsel
      obtain ⟨g3, g4⟩ := h5 g1 g2
      exact ⟨_, unemb_y K.hv x.1 g3 g4⟩) i t
  show matP (unemb c K.hv) (mic (addsB c)) i (lY t) = _
  rw [hf]
  have htg : ∀ t' s cf, Micro.add t' s cf ∈ micF (selY c.v (2 * c.v)) (addsB c) →
      ∃ τ : Fin c.v, unemb c K.hv t' = lY τ := by
    intro t' s cf hm
    obtain ⟨x, hx, rfl, rfl, hsel⟩ := mem_micF _ _ _ _ _ hm
    obtain ⟨_, _, _, h5⟩ := K.addB x hx
    obtain ⟨g1, g2⟩ := selY_spec.mp hsel
    obtain ⟨g3, g4⟩ := h5 g1 g2
    exact ⟨_, unemb_y K.hv x.1 g3 g4⟩
  rcases i with (τ | S) | q
  · exact matP_row _ _ _ (fun t' s cf hm hh => by
      obtain ⟨τ', hτ'⟩ := htg t' s cf hm
      rw [hτ'] at hh; cases hh) _
  · obtain ⟨lo, n, hlo, hhi, p, a0, a3, hp, hi, hr, hsm, fy⟩ := K.hyc t.val t.isLt
    have hokB : ∀ t s, okB c t s = true →
        emb c (unemb c K.hv t) = t ∧ emb c (unemb c K.hv s) = s :=
      fun t s ho => ⟨emb_unemb K.hv t (okB_spec ho).1, emb_unemb K.hv s (okB_spec ho).2.1⟩
    have hC := GRun_Cm p.sw n (U c p) (okB c) (selY c.v (2 * c.v)) (emb c) (unemb c K.hv)
      (unemb_emb K.hv) hokB (addsB c) a0 a3 hr
    have hus : p.uy < 2^p.sw :=
      lt_of_lt_of_le hp.hys (Nat.pow_le_pow_right (by norm_num) (by omega))
    have hT : t.val - lo < n := by omega
    have hC0 : ∀ j : Rl c, Cm p.sw n (U c p) (emb c) a0 j ⟨t.val - lo, hT⟩
        = if j = lY t then 1 else 0 := by
      intro j
      have h1 := cont_start p.sw n (U c p) a0 (c.v + lo) p.uy hp.hy hus hi (emb c j) (t.val - lo) hT
        (fun hr => U_y c p _ (by omega) (by have := hp.hn; omega))
      show gcont p.sw (U c p) a0 (emb c j) (t.val - lo) = _
      rw [h1]
      have e : c.v + lo + (t.val - lo) = c.v + t.val := by omega
      by_cases hj : j = lY t
      · rw [if_pos hj, hj, if_pos (by rw [e]; rfl)]
      · have hne : ¬ emb c j = c.v + lo + (t.val - lo) := by
          intro he
          apply hj
          rw [← unemb_emb K.hv j, he, e, unemb_y K.hv (c.v + t.val) (by omega)
            (by have := t.isLt; omega)]
          exact congrArg (fun x => (Sum.inl (Sum.inr x) : Rl c)) (Fin.ext (by simp))
        rw [if_neg hj, if_neg hne]
    have e1 := mul_unitCol (matP (unemb c K.hv) (micF (selY c.v (2 * c.v)) (addsB c)))
      (Cm p.sw n (U c p) (emb c) a0) (lY t) ⟨t.val - lo, hT⟩ hC0 (lY S)
    rw [← e1, ← hC]
    have h1 := cont_end p.sw n (U c p) a3 (c.v + S.val) p.uy (S.val - lo)
      (lo ≤ S.val ∧ S.val < lo + n) hp.hsw hp.hy hp.hys
      (U_y c p _ (by omega) (by have := S.isLt; omega)) (hsm (c.v + S.val)).2 (fy S.val S.isLt)
      (t.val - lo) hT
    show gcont p.sw (U c p) a3 (c.v + S.val) (t.val - lo) = _
    rw [h1]
    by_cases e : S = t
    · rw [e, if_pos ⟨⟨hlo, hhi⟩, rfl⟩, if_pos rfl]
    · have hne : ¬ ((lo ≤ S.val ∧ S.val < lo + n) ∧ t.val - lo = S.val - lo) := by
        intro hh
        exact e (Fin.ext (by omega))
      rw [if_neg hne, if_neg (fun hh => e (Sum.inr.inj (Sum.inl.inj hh)))]
  · exact matP_row _ _ _ (fun t' s cf hm hh => by
      obtain ⟨τ', hτ'⟩ := htg t' s cf hm
      rw [hτ'] at hh; cases hh) _

theorem hy (i : Rl c) (t : Fin c.v) :
    (MB c K.hv * scatM (Jrm c * Ccm c) * MA c K.hv) i (lY t) = if i = lY t then 1 else 0 := by
  have hA : ∀ i : Rl c, MA c K.hv i (lY t) = if i = lY t then 1 else 0 :=
    matP_col (unemb c K.hv) (lY t) (mic (addsA c)) (fun t' s cf hm hh => by
    obtain ⟨x, hx, rfl, rfl⟩ := mem_mic _ _ _ _ hm
    obtain ⟨_, h2, _⟩ := K.addA x hx
    have hny := K.hA_noY x hx
    have := unemb_of_y K.hv x.2.1 h2 t hh
    omega)
  have hS : ∀ i : Rl c, scatM (Jrm c * Ccm c) i (lY t) = if i = lY t then 1 else 0 := by
    intro i
    unfold scatM
    rw [Matrix.add_apply, Matrix.one_apply, embYS_colY, add_zero]
  have hcol := unitCol_mul _ _ (lY t) hS hA
  rw [Matrix.mul_assoc, mul_unitCol (MB c K.hv) _ (lY t) (lY t) hcol i]
  exact K.mb_ycol i t

theorem hx (t : Fin c.v) (j : Rl c) :
    (MB c K.hv * scatM (Jrm c * Ccm c) * MA c K.hv) (lX t) j = if lX t = j then 1 else 0 := by
  rcases j with (τ | S) | q
  · obtain ⟨lo, n, hlo, hhi, h⟩ := K.hs τ.val τ.isLt
    have h1 := (h.xcol K.hv τ hlo hhi).1 t
    show Mt c K.hv (lX t) (lX τ) = _
    rw [h1]
    by_cases e : t = τ
    · rw [if_pos e, e, if_pos rfl]
    · rw [if_neg e, if_neg (fun hh => e (Sum.inl.inj (Sum.inl.inj hh)))]
  · exact K.hy (lX t) S
  · obtain ⟨gl, ey, hq, h⟩ := K.hsl q.val q.isLt
    have h1 := h.xrow K.hv q hq t
    show Mt c K.hv (lX t) (lS q) = _
    rw [h1, if_neg (fun hh => by cases hh)]

/-- **the scalar half** (`GX.Scal`), through the unchanged `GXD.scalOf`. -/
noncomputable def scal : GX.Scal (Fin c.v) (Fin c.R) (Fin c.ret.length) :=
  scalOf c K.hv K.hAi K.hBi K.hx K.hy K.hid

/-- **the gauged scalar half** (`GX.GScal`): every gauged slot is replayed with `ey`. -/
noncomputable def gscal (g : Finset (Fin c.R))
    (hg : ∀ q ∈ g, ∃ gl, 2 * c.v + q.val ∈ gl ∧ SRunR c gl true) :
    GX.GScal (Fin c.v) (Fin c.R) (Fin c.ret.length) where
  toScal := K.scal
  gauged := g
  hE := fun q hq t => by
    obtain ⟨gl, hgl, h⟩ := hg q hq
    exact h.yrow K.hv q hgl t

end SourceOKR

/-- `SourceOKR` from lists of accepted kernel checks. -/
theorem SourceOKR.of_checks {c : Raw} (hv : 0 < c.v) (hk : kindsK c = true)
    (xs : List (SPar × Nat × Nat)) (hxs : ∀ e ∈ xs, xCheckR c e.1 e.2.1 e.2.2 = true)
    (hxc : ∀ t, t < c.v → ∃ e ∈ xs, e.2.1 ≤ t ∧ t < e.2.1 + e.2.2)
    (ys : List (SPar × Nat × Nat)) (hys : ∀ e ∈ ys, yCheck c e.1 e.2.1 e.2.2 = true)
    (hyc : ∀ t, t < c.v → ∃ e ∈ ys, e.2.1 ≤ t ∧ t < e.2.1 + e.2.2)
    (hA : aNoYK c = true)
    (ss : List (SPar × List Nat × Bool)) (hss : ∀ e ∈ ss, sCheckR c e.1 e.2.1 e.2.2 = true)
    (hsc : ∀ q, q < c.R → ∃ e ∈ ss, 2 * c.v + q ∈ e.2.1) : SourceOKR c where
  hv := hv
  hk := hk
  hs := fun t ht => by
    obtain ⟨e, he, h1, h2⟩ := hxc t ht
    exact ⟨e.2.1, e.2.2, h1, h2, xCheckR_sound (hxs e he)⟩
  hyc := fun t ht => by
    obtain ⟨e, he, h1, h2⟩ := hyc t ht
    exact ⟨e.2.1, e.2.2, h1, h2, YRun.of_check (hys e he)⟩
  hA_noY := aNoYK_sound hA
  hsl := fun q hq => by
    obtain ⟨e, he, h1⟩ := hsc q hq
    exact ⟨e.2.1, e.2.2, h1, sCheckR_sound (hss e he)⟩

end GS.ZC

#print axioms GS.ZC.renT_state
#print axioms GS.ZC.gItemsR_sound
#print axioms GS.ZC.runR_cm
#print axioms GS.ZC.xCheckR_sound
#print axioms GS.ZC.XRunR.xcol
#print axioms GS.ZC.sCheckR_sound
#print axioms GS.ZC.SRunR.xrow
#print axioms GS.ZC.SRunR.yrow
#print axioms GS.ZC.kindsK_sound
#print axioms GS.ZC.SourceOKR.hx
#print axioms GS.ZC.SourceOKR.hy
#print axioms GS.ZC.SourceOKR.scal
#print axioms GS.ZC.SourceOKR.gscal
#print axioms GS.ZC.SourceOKR.of_checks
