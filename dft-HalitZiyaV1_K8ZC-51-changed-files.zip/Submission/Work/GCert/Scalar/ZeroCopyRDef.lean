import Submission.Work.GCert.Scalar.ZeroCopyDef

/-!
# Zero-copy provider replay with renormalisation: kernel terms (core Lean only)

The packed replay keeps every content as a pair `(P, N)` of packed vectors (positive and negative parts) that
only grow; long programs with much cancellation (e.g. a native cleanup restoring the x roles through the
helpers) make the parts large although the contents stay small.  Here the replay RENORMALISES the state after
every item (chunk of gates or scatter): in every leaf, digit by digit, `min (P_T, N_T)` is removed from both
parts and the 16-bit tags are recomputed.  The contents (`P_T - N_T`) are unchanged.

* `renD`, `renLeaf`, `renT`: the renormalisation of the digits, of one leaf, of a whole trie;
* `gItemsR`: `GS.ZC.gItems` with a renormalisation after every item;
* `xCheckR`, `sCheckR`: `GS.ZC.xCheck`, `GS.ZC.sCheck` on `gItemsR`;
* `kindsK`: every add of phases A and B passes the relaxed kind test `okZK` and joins two registers.

Soundness: `ZeroCopyR.lean`.
-/

namespace GS.ZC
open SSC GXD

/-- renormalise `cnt` digits (lowest first) of the untagged pair `(P, N)`, digit index `T`:
accumulate the reduced digits at `sw * T` and their 16-bit tags -/
noncomputable def renD (sw : Nat) :
    Nat → Nat → Nat → Nat → Nat → Nat → Nat → Nat → (Nat → Nat → Nat → Nat → Bool) → Bool :=
  Nat.rec (motive := fun _ => Nat → Nat → Nat → Nat → Nat → Nat → Nat →
      (Nat → Nat → Nat → Nat → Bool) → Bool)
    (fun _ _ _ aP aN tP tN k => k aP aN tP tN)
    (fun _ ih T P N aP aN tP tN k =>
      forceN (Nat.mod P (Nat.pow 2 sw)) fun p => forceN (Nat.mod N (Nat.pow 2 sw)) fun q =>
      forceN (Bool.rec (motive := fun _ => Nat) q p (Nat.ble p q)) fun m =>
      forceN (Nat.sub p m) fun p' => forceN (Nat.sub q m) fun q' =>
      forceN (Nat.mod (Nat.mul 2654435761 (Nat.succ T)) 65536) fun w =>
      forceN (Nat.add aP (Nat.shiftLeft p' (Nat.mul sw T))) fun aP' =>
      forceN (Nat.add aN (Nat.shiftLeft q' (Nat.mul sw T))) fun aN' =>
      forceN (Nat.add tP (Nat.mul p' w)) fun tP' => forceN (Nat.add tN (Nat.mul q' w)) fun tN' =>
      ih (Nat.succ T) (Nat.div P (Nat.pow 2 sw)) (Nat.div N (Nat.pow 2 sw)) aP' aN' tP' tN' k)

/-- the renormalised leaf of `x` (tagged halves of `K` bits: `x = P + N * 2^K`, `n` digits of width `sw`);
a zero leaf stays zero -/
noncomputable def renLeaf (sw n K : Nat) (x : Nat) (k : Nat → Bool) : Bool :=
  Bool.rec (motive := fun _ => Bool)
    (renD sw n 0 (Nat.shiftRight (Nat.mod x (Nat.pow 2 K)) 64) (Nat.shiftRight (Nat.shiftRight x K) 64)
      0 0 0 0 fun aP aN tP tN =>
        guard (Nat.ble (Nat.succ tP) 9223372036854775808)
          (guard (Nat.ble (Nat.succ tN) 9223372036854775808)
            (forceN (Nat.add (Nat.add (Nat.shiftLeft aP 64) tP)
              (Nat.shiftLeft (Nat.add (Nat.shiftLeft aN 64) tN) K)) k)))
    (k 0) (Nat.beq x 0)

/-- the renormalised trie (every leaf) -/
noncomputable def renT (sw n K : Nat) : Trie → (Trie → Bool) → Bool :=
  Trie.rec (motive := fun _ => (Trie → Bool) → Bool)
    (fun x k => renLeaf sw n K x fun x' => k (.leaf x'))
    (fun _ _ fl fr k => fl fun l' => fr fun r' => k (.node l' r'))

section
variable (c : Raw) (p : SPar) (n v2 nr tm K m2 rl : Nat)

/-- the items with a renormalisation after every item -/
noncomputable def gItemsR : List Item → Trie → (Trie → Bool) → Bool :=
  List.rec (motive := fun _ => Trie → (Trie → Bool) → Bool)
    (fun tr k => k tr)
    (fun it _ ih tr k => gItem c p v2 nr tm K m2 rl it tr fun tr' =>
      renT p.sw n K tr' fun tr'' => ih tr'' k)

end

/-- **x columns** `lo .. lo+n-1` with renormalisation: replay of `sourceProg c` under `okZK`, the state
renormalised after every item; at the end `x_t` and `y_t` hold exactly source `t`. -/
noncomputable def xCheckR (c : Raw) (p : SPar) (lo n : Nat) : Bool :=
  gPre c p lo n fun v2 nr hi tm K m2 => forceN (List.length c.ret) fun rl =>
    Tag16.init p.sw p.ux lo n 0 (Trie.mk p.d) fun tr0 =>
      gItemsR c p n v2 nr tm K m2 rl (sourceProg c) tr0 fun tr3 =>
        guard (gFin p.sw K m2 p.ux 0 lo hi tr3 c.v 0) (gFin p.sw K m2 p.uy c.v lo hi tr3 c.v 0)

/-- **slot columns** (registers `gl`) with renormalisation: every x role ends holding nothing, and if `ey`
every y role holds nothing. -/
noncomputable def sCheckR (c : Raw) (p : SPar) (gl : List Nat) (ey : Bool) : Bool :=
  gPre c p 0 gl.length fun v2 nr _ tm K m2 =>
    guard (Tag16.incK nr gl v2) (guard (Nat.ble (Nat.succ p.us) (Nat.pow 2 (Nat.sub p.sw 1)))
      (guard (Nat.ble (Nat.succ p.us) 2147483648)
        (forceN (List.length c.ret) fun rl =>
          Tag16.initL p.sw p.us gl 0 (Trie.mk p.d) fun tr0 =>
            gItemsR c p gl.length v2 nr tm K m2 rl (sourceProg c) tr0 fun tr3 =>
              guard (gFin p.sw K m2 p.ux 0 0 0 tr3 c.v 0)
                (Bool.rec (motive := fun _ => Bool) true (gFin p.sw K m2 p.uy c.v 0 0 tr3 c.v 0) ey))))

/-- every add of phases A and B passes the relaxed kind test and joins two different registers -/
noncomputable def kindsK (c : Raw) : Bool :=
  ((c.gatesA.flatMap Gate.adds) ++ (c.gatesB.flatMap Gate.adds)).all fun x =>
    okZK c.v (2 * c.v) (2 * c.v + c.R) x.1 x.2.1 && !(Nat.beq x.1 x.2.1)

end GS.ZC
