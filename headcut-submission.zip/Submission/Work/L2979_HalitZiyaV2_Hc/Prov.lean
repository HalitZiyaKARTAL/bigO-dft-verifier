import Submission.Work.PWGen.S2979Pair
import Submission.Work.XHostT.HFW2979.Disp2979W
import Submission.Work.XHostT.Inst.S2979_HalitZiyaV2_Hc_Facts
import Submission.Work.Mixed.Hist2979_HalitZiyaV2_Hc
/-!
# afc-cut: the data of the #2979 warp network for A-fc (fill u1-2979sep, 7fc766c6; full cut, suffix L2979Fc)

* `I0W`, `I1W`: x-words' two #2979 provider packages (`PWG2979.ginvE` = extra, provider 0; `PWG2979.ginvB` = gauge44,
  provider 1; windowed `KLW.GInvEW .. GXD.S2979B.okW`) as p-a3's warp providers `XHostTW.GInvW` (the same seven
  fields);
* `Ic2979W`: the per-call providers by x-tables' dispatch table `D2979.disp` (x-inst's `D2979W.IcW`), with
  `hIc2979W` (one target-vector family, x-words' `PWG2979.tv_eq`);
* `hOk2979`: every window of the network (Shea's `win401N`, conjugation windows `gwinC`) has a warp meaning
  (x-words' `GXD.S2979B.okC`, by p-warpsem's `WLift.ofConj`);
* `resIcW2979Fc`: the entrance residual of every slot of every call is the host table's (x-words' `hent` against
  afc-data's residual table `DH2979Fc.resT` (= x-tables'), two kernel checks `resE_ok`, `resB_ok`, and afc-data's
  `dp_disp`); hence `hfit2979FcW` (afc-data's `sched2979Fc_fits`) and `hpos2979FcW`;
* `hU2979FcW`: the unit price of the network is `listCost φ MX.unit2979Fc` (666 calls of the local profile
  {1: 2445, 2: 706, 3: 232, 4: 108, 5: 18, 8: 8} plus the remaining climbs {1: 2269, 6: 5, 7: 3, 17: 8, 19: 1, 23: 25905, 48: 16576}).
aA-final's `Work/L2979H/Prov.lean` (x-final's `Work/L2979/Prov.lean` for design A) with the schedule, host table and
unit profile of A-fc (afc-data's `sched2979Fc`, `K.DH2979Fc`; afc-cut's `MX.unit2979Fc`: 16,576 heads and no other
rank-48 block; the providers, dispatch and residuals do not depend on the fill).  afc-cut (wht45/afc, 20 Oct 2026;
made by tools/mk_prov2979Fc.py); prepared with assistance from Claude.  No `sorry`.
-/
-- changed for the head-cut extension (1959540039/1000000000000); see Submission.lean

set_option linter.unusedSectionVars false
set_option maxRecDepth 100000
namespace OAI
namespace PowerSaving
namespace MX
namespace L2979_HalitZiyaV2_Hc
open Finset Binary Matrix RAM SS CB RF BR GF GX BC B401 XHost XHostR XHostD XHostT XHostTW

noncomputable section

/-- provider 0 of #2979's dispatch (the extra word) as a warp provider of p-a3's network. -/
def I0W : GInvW (Fin 9) (Fin 112) (Fin 408) (Fin 99) GXD.S2979B.okW :=
  ⟨PWG2979.ginvE.tv, PWG2979.ginvE.hunit, PWG2979.ginvE.hgap, PWG2979.ginvE.cost, PWG2979.ginvE.ent,
   PWG2979.ginvE.fwd, PWG2979.ginvE.bwd⟩

/-- provider 1 of #2979's dispatch (the gauge44 word) as a warp provider of p-a3's network. -/
def I1W : GInvW (Fin 9) (Fin 112) (Fin 408) (Fin 99) GXD.S2979B.okW :=
  ⟨PWG2979.ginvB.tv, PWG2979.ginvB.hunit, PWG2979.ginvB.hgap, PWG2979.ginvB.cost, PWG2979.ginvB.ent,
   PWG2979.ginvB.fwd, PWG2979.ginvB.bwd⟩

/-- the provider of every call of #2979 (x-tables' table: 416 extra, 250 gauge44). -/
def Ic2979W : Fin 74 → Fin 9 → GInvW (Fin 9) (Fin 112) (Fin 408) (Fin 99) GXD.S2979B.okW :=
  D2979W.IcW D2979.disp I0W I1W

theorem hIc2979W : ∀ ρ l, (Ic2979W ρ l).tv = I0W.tv :=
  D2979W.hIcW D2979.disp I0W I1W PWG2979.tv_eq

/-- **every window of the network has a warp meaning** (Shea's windows are conjugation windows `gwinC`). -/
theorem hOk2979 : ∀ (l : Fin 9) (n : ℕ) (d : Orth (BC.LC (Fin 8) (Fin 9) l)),
    GXD.S2979B.okW (win401N l (Fintype.card_fin 9) n d) := by
  intro l n d
  unfold win401N
  split <;> exact GXD.S2979B.okC _ _ _ _

/-- the residual list `L` agrees with provider `p` of a residual table on the slots `q < m`. -/
def resEqL (resT p : Nat) (L : List Nat) : Nat → Bool
  | 0 => true
  | m + 1 => resEqL resT p L m && Nat.beq (L.getD m 0) (K.resAt resT p m)

theorem resEqL_sound (resT p : Nat) (L : List Nat) :
    ∀ m, resEqL resT p L m = true → ∀ q < m, L.getD q 0 = K.resAt resT p q
  | 0, _, q, hq => absurd hq (Nat.not_lt_zero q)
  | m + 1, h, q, hq => by
    simp only [resEqL, Bool.and_eq_true] at h
    rcases Nat.lt_succ_iff_lt_or_eq.mp hq with hq | rfl
    · exact resEqL_sound resT p L m h.1 q hq
    · exact Nat.eq_of_beq_eq_true h.2

/-- the extra word's slot residuals (x-words) are provider 0's of x-tables' table. -/
theorem resE_ok : resEqL K.DH2979_HalitZiyaV2_Hc.resT 0 GXD.S2979E.schedRes 408 = true := by decide +kernel
/-- the gauge44 word's slot residuals (x-words) are provider 1's of x-tables' table. -/
theorem resB_ok : resEqL K.DH2979_HalitZiyaV2_Hc.resT 1 GXD.S2979B.schedRes 408 = true := by decide +kernel

/-- **the residual of every slot of every call is the host table's.** -/
theorem resIcW2979_HalitZiyaV2_Hc (ρ : Fin 74) (l : Fin 9) (q : Fin 408) :
    resIcW Ic2979W ρ l q = resK K.DH2979_HalitZiyaV2_Hc.ct K.DH2979_HalitZiyaV2_Hc.resT 74 408 ρ l q := by
  rw [Inst.resK2979_HalitZiyaV2_Hc_disp]
  have hp := (D2979.disp (ρ, l)).isLt
  unfold resIcW Ic2979W D2979W.IcW
  by_cases h0 : (D2979.disp (ρ, l)).val = 0
  · rw [if_pos h0, h0]
    show Fintype.card (Fin 9) - (GXD.S2979E.ginvW.ent q).dim = K.resAt K.DH2979_HalitZiyaV2_Hc.resT 0 q.val
    rw [GXD.S2979E.hent q]
    exact resEqL_sound _ _ _ 408 resE_ok q.val q.isLt
  · have h1 : (D2979.disp (ρ, l)).val = 1 := by omega
    rw [if_neg h0, h1]
    show Fintype.card (Fin 9) - (GXD.S2979B.ginvW.ent q).dim = K.resAt K.DH2979_HalitZiyaV2_Hc.resT 1 q.val
    rw [GXD.S2979B.hent q]
    exact resEqL_sound _ _ _ 408 resB_ok q.val q.isLt

/-- **the schedule fits the providers' residuals** (afc-data's `sched2979_HalitZiyaV2_Hc_fits`). -/
theorem hfit2979_HalitZiyaV2_Hc_W : Inst.sched2979_HalitZiyaV2_Hc.fits (resIcW Ic2979W) := by
  have e : resIcW Ic2979W = resK K.DH2979_HalitZiyaV2_Hc.ct K.DH2979_HalitZiyaV2_Hc.resT 74 408 := by
    funext ρ l q
    exact resIcW2979_HalitZiyaV2_Hc ρ l q
  rw [e]
  exact Inst.sched2979_HalitZiyaV2_Hc_fits

theorem hpos2979_HalitZiyaV2_Hc_W : ∀ ρ l q, 0 < resIcW Ic2979W ρ l q := fun ρ l q => by
  rw [resIcW2979_HalitZiyaV2_Hc]
  exact Inst.resK2979_HalitZiyaV2_Hc_pos ρ l q

/-- **the unit price of the #2979 warp network is its profile** `MX.unit2979_HalitZiyaV2_Hc`. -/
theorem hU2979_HalitZiyaV2_Hc_W (φ : ℕ → ℝ) : unitPriceTW Ic2979W Inst.sched2979_HalitZiyaV2_Hc φ = listCost φ MX.unit2979_HalitZiyaV2_Hc := by
  rw [D2979W.unitPriceTW_const Ic2979W Inst.sched2979_HalitZiyaV2_Hc I0W.cost
        (D2979W.IcW_cost D2979.disp I0W I1W (fun φ => (PWG2979.same_price φ).symm)) φ,
      Inst.sched2979_HalitZiyaV2_Hc_hcost]
  show ((9 * 74 : ℕ) : ℝ) * GXD.S2979E.ginvW.cost φ + (3893 * φ 1 + 3310 * φ 3 + 1 * φ 7 + 2 * φ 9 + 1 * φ 10 + 16572 * φ 16 + 16576 * φ 32 + 12177 * φ 48)
    = listCost φ MX.unit2979_HalitZiyaV2_Hc
  rw [GXD.S2979E.ginv_cost]
  unfold GXD.S2979E.invPrice
  simp only [listCost, MX.unit2979_HalitZiyaV2_Hc, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil]
  push_cast
  ring

end
end L2979_HalitZiyaV2_Hc
end MX
end PowerSaving
end OAI

#print axioms OAI.PowerSaving.MX.L2979_HalitZiyaV2_Hc.hIc2979W
#print axioms OAI.PowerSaving.MX.L2979_HalitZiyaV2_Hc.hOk2979
#print axioms OAI.PowerSaving.MX.L2979_HalitZiyaV2_Hc.resIcW2979_HalitZiyaV2_Hc
#print axioms OAI.PowerSaving.MX.L2979_HalitZiyaV2_Hc.hfit2979_HalitZiyaV2_Hc_W
#print axioms OAI.PowerSaving.MX.L2979_HalitZiyaV2_Hc.hpos2979_HalitZiyaV2_Hc_W
#print axioms OAI.PowerSaving.MX.L2979_HalitZiyaV2_Hc.hU2979_HalitZiyaV2_Hc_W
